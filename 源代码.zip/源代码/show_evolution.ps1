# PowerShell 脚本：实时显示 evolution.log 日志
# 用法：双击此脚本，或通过 PowerShell 执行 .\show_evolution.ps1
$logPath = "evolution.log"
$title = "天灵进化监视器 - 实时日志"
$host.UI.RawUI.WindowTitle = $title

if (-not (Test-Path $logPath)) {
    Write-Host "日志文件不存在，等待创建..." -ForegroundColor Yellow
    # 等待文件出现
    while (-not (Test-Path $logPath)) {
        Start-Sleep -Seconds 2
    }
}

Write-Host "=== 天灵进化监视器启动 ===" -ForegroundColor Green
Write-Host "日志文件: $logPath" -ForegroundColor Cyan
Write-Host "按 Ctrl+C 退出" -ForegroundColor Yellow
Write-Host "----------------------------------------" -ForegroundColor Gray

# 显示最后 50 行，然后进入跟踪模式
Get-Content $logPath -Tail 50
Write-Host "----------------------------------------" -ForegroundColor Gray
Write-Host "开始实时跟踪..." -ForegroundColor Green

# 实时跟踪新内容
Get-Content $logPath -Wait