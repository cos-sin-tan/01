#!/usr/bin/env python3
"""测试 Search_Node 功能"""
import sys
import os
sys.path.insert(0, '.')

from src.main_agent import search_node, AgentState

# 模拟状态
state: AgentState = {
    'task_description': '有机化学 SN1 SN2 反应对比',
    'blueprint': None,
    'deliverables': {},
    'audit_results': {},
    'error_message': None,
    'iteration': 0,
    'current_node': 'search',
    'relevant_knowledge': None,
    'system_spec': None,
    'hard_constraints': None,
    'diagnostic_vector': None,
    'lessons_learned': None,
    'current_consensus': None,
    'token_usage': {'total_tokens': 0, 'last_node_tokens': 0},
    'need_search': True,
    'search_performed': False,
}

print("开始测试 Search_Node...")
new_state = search_node(state)
print("Search_Node 执行完成")
print(f"error_message: {new_state.get('error_message')}")
print(f"relevant_knowledge 长度: {len(new_state.get('relevant_knowledge', '')) if new_state.get('relevant_knowledge') else 0}")
print(f"need_search: {new_state.get('need_search')}")
print(f"search_performed: {new_state.get('search_performed')}")
print(f"current_node: {new_state.get('current_node')}")