#!/usr/bin/env python3
"""
天灵进化监护人脚本 v3
增加实时日志文件输出，供显示窗口使用。
"""
import os
import sys
from dotenv import load_dotenv
load_dotenv()
import subprocess
import shutil
import json
import re
from datetime import datetime
from pathlib import Path

# 配置
DEBATE_NODE_PATH = "src/debate_node.py"
DEBATE_NODE_STABLE = "src/debate_node.py.stable"
EVALUATOR_GOLD = "src/evaluator.gold"
ERROR_VAULT_PATH = ".ai_knowledge/error_vault.md"
LOG_FILE = "evolution.log"
MAX_ROUNDS = 3
CONSECUTIVE_SUCCESSES_NEEDED = 3
success_count = 0

# LLM 模型初始化（用于漏洞检测）
def get_judge_model():
    """获取裁判模型（专用于批量判卷，低温度、低token消耗）"""
    import os
    from langchain_deepseek import ChatDeepSeek
    api_key = os.getenv("DEEPSEEK_API_KEY")
    if not api_key or api_key.strip() == "":
        print("警告: DEEPSEEK_API_KEY 缺失，无法使用 LLM 评估，将回退到模拟模式")
        return None
    # 裁判模型：温度为零，强制 JSON 输出，限制 token 数量
    return ChatDeepSeek(
        model="deepseek-reasoner",
        api_key=api_key,
        timeout=300,
        max_retries=3,
        temperature=0,
        max_tokens=50,
        # response_format={"type": "json_object"}  # 如果 API 支持
    )

def get_coach_model():
    """获取教练模型（用于提示词进化，允许更多思考）"""
    import os
    from langchain_deepseek import ChatDeepSeek
    api_key = os.getenv("DEEPSEEK_API_KEY")
    if not api_key or api_key.strip() == "":
        print("警告: DEEPSEEK_API_KEY 缺失，无法使用 LLM 评估，将回退到模拟模式")
        return None
    # 教练模型：默认温度，较高 token 上限
    return ChatDeepSeek(
        model="deepseek-reasoner",
        api_key=api_key,
        timeout=300,
        max_retries=3,
        temperature=0.3,
        max_tokens=4000
    )

judge_model = get_judge_model()
coach_model = get_coach_model()

def log(msg):
    """输出到控制台并追加到日志文件"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    full_msg = f"[{timestamp}] [Guardian] {msg}"
    print(full_msg)
    with open(LOG_FILE, 'a', encoding='utf-8') as f:
        f.write(full_msg + '\n')

def log_bootstrap_output(stdout, stderr):
    """将自举输出写入日志（截断）"""
    if stdout:
        lines = stdout.split('\n')
        for line in lines[:50]:  # 最多记录前50行
            if line.strip():
                with open(LOG_FILE, 'a', encoding='utf-8') as f:
                    f.write(f"[Bootstrap] {line}\n")
    if stderr:
        lines = stderr.split('\n')
        for line in lines[:20]:
            if line.strip():
                with open(LOG_FILE, 'a', encoding='utf-8') as f:
                    f.write(f"[Bootstrap ERROR] {line}\n")

def backup_stable():
    if not os.path.exists(DEBATE_NODE_STABLE):
        shutil.copy2(DEBATE_NODE_PATH, DEBATE_NODE_STABLE)
        log(f"已创建稳定基准: {DEBATE_NODE_STABLE}")
    if not os.path.exists(EVALUATOR_GOLD):
        staging_path = "src/staging/safe_evaluator.py"
        if os.path.exists(staging_path):
            shutil.copy2(staging_path, EVALUATOR_GOLD)
            log(f"已复制 evaluator 黄金版本: {EVALUATOR_GOLD}")

def run_bootstrap():
    cmd = [sys.executable, "src/main_agent.py", "自举任务：优化自身提示词模板"]
    log(f"执行自举命令: {' '.join(cmd)}")
    env = os.environ.copy()
    env['PYTHONIOENCODING'] = 'utf-8'
    import subprocess as sp
    from threading import Thread
    from queue import Queue, Empty
    
    def enqueue_output(pipe, queue, prefix):
        try:
            with pipe:
                for line in iter(pipe.readline, ''):
                    queue.put((prefix, line))
        except Exception as e:
            queue.put((prefix, f"读取错误: {e}"))
        finally:
            queue.put((prefix, None))  # 结束标记
    
    try:
        proc = sp.Popen(
            cmd,
            stdout=sp.PIPE,
            stderr=sp.PIPE,
            text=True,
            encoding='utf-8',
            errors='ignore',
            cwd=os.getcwd(),
            env=env,
            bufsize=1
        )
        
        # 队列用于收集输出
        q = Queue()
        stdout_thread = Thread(target=enqueue_output, args=(proc.stdout, q, 'stdout'))
        stderr_thread = Thread(target=enqueue_output, args=(proc.stderr, q, 'stderr'))
        stdout_thread.daemon = True
        stderr_thread.daemon = True
        stdout_thread.start()
        stderr_thread.start()
        
        stdout_lines = []
        stderr_lines = []
        
        # 超时设置（600 秒）
        timeout_seconds = 600
        import time
        start_time = time.time()
        
        # 等待进程结束，同时处理输出
        while True:
            # 检查是否超时
            if time.time() - start_time > timeout_seconds:
                log(f"自举超时（{timeout_seconds} 秒），强制终止")
                proc.terminate()
                proc.wait(timeout=5)
                return -1, "", "Timeout"
            
            try:
                prefix, line = q.get(timeout=0.5)
                if line is None:
                    # 线程结束
                    continue
                # 实时写入日志
                with open('evolution.log', 'a', encoding='utf-8') as f:
                    f.write(f"[Bootstrap {prefix}] {line}")
                if prefix == 'stdout':
                    stdout_lines.append(line)
                else:
                    stderr_lines.append(line)
            except Empty:
                # 检查进程是否结束
                retcode = proc.poll()
                if retcode is not None:
                    # 进程已结束，读取剩余输出
                    break
        
        # 确保所有剩余输出都被读取
        for thread in (stdout_thread, stderr_thread):
            thread.join(timeout=1)
        
        # 收集剩余输出
        while True:
            try:
                prefix, line = q.get_nowait()
                if line is None:
                    continue
                with open('evolution.log', 'a', encoding='utf-8') as f:
                    f.write(f"[Bootstrap {prefix}] {line}")
                if prefix == 'stdout':
                    stdout_lines.append(line)
                else:
                    stderr_lines.append(line)
            except Empty:
                break
        
        stdout = ''.join(stdout_lines)
        stderr = ''.join(stderr_lines)
        
        log(f"自举退出码: {proc.returncode}")
        if stdout:
            log(f"自举输出 (前 500 字符): {stdout[:500]}...")
        if stderr:
            log(f"自举错误 (前 500 字符): {stderr[:500]}...")
        # 调用原有的日志记录函数（保留格式）
        log_bootstrap_output(stdout, stderr)
        return proc.returncode, stdout, stderr
    
    except Exception as e:
        log(f"自举执行异常: {e}")
        return -2, "", str(e)

def read_file_lines(path):
    if not os.path.exists(path):
        return []
    with open(path, 'r', encoding='utf-8', errors='ignore') as f:
        lines = f.readlines()
    cleaned = []
    for line in lines:
        stripped = line.strip()
        if stripped and not stripped.startswith('#'):
            cleaned.append(line)
    return cleaned

def count_logic_lines(path):
    lines = read_file_lines(path)
    return len(lines)

def audit_debate_node():
    if not os.path.exists(DEBATE_NODE_PATH):
        return False, "文件不存在"
    
    with open(DEBATE_NODE_PATH, 'r', encoding='utf-8', errors='ignore') as f:
        content = f.read()
    
    # 熔断条件 A
    if 'pytest' not in content and 'subprocess.run' not in content:
        return False, "删除了 pytest 仲裁逻辑"
    
    if '_resolve_sandbox_path' not in content:
        return False, "删除了 _resolve_sandbox_path 路径映射"
    
    if '硬性约束' not in content and '安全红线' not in content:
        return False, "删除了硬性安全约束"
    
    # 熔断条件 B
    stable_lines = count_logic_lines(DEBATE_NODE_STABLE)
    new_lines = count_logic_lines(DEBATE_NODE_PATH)
    if stable_lines == 0:
        log("稳定版本行数为零，跳过行数检查")
    else:
        reduction = (stable_lines - new_lines) / stable_lines
        if reduction > 0.3:
            return False, f"核心逻辑行数减少 {reduction:.1%}（稳定 {stable_lines} 行，当前 {new_lines} 行）"
    
    # 关键函数检查
    required_funcs = ['run_debate', '_invoke_coder', '_invoke_auditor']
    for func in required_funcs:
        if func not in content:
            return False, f"缺失关键函数 {func}"
    
    return True, "审计通过"

def revert_to_stable(reason):
    log(f"触发熔断，原因: {reason}")
    if os.path.exists(DEBATE_NODE_STABLE):
        shutil.copy2(DEBATE_NODE_STABLE, DEBATE_NODE_PATH)
        log(f"已恢复稳定版本: {DEBATE_NODE_PATH}")
    else:
        log("错误: 稳定备份不存在，无法恢复")
    
    # 写入错误知识库
    os.makedirs(os.path.dirname(ERROR_VAULT_PATH), exist_ok=True)
    entry = f"""
## 进化熔断记录
- **日期**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
- **文件**: {DEBATE_NODE_PATH}
- **原因**: {reason}
- **处理**: 已恢复至稳定基准
"""
    with open(ERROR_VAULT_PATH, 'a', encoding='utf-8') as f:
        f.write(entry)
    log(f"已写入错误知识库: {ERROR_VAULT_PATH}")

def update_stable():
    shutil.copy2(DEBATE_NODE_PATH, DEBATE_NODE_STABLE)
    log(f"更新稳定基准: {DEBATE_NODE_STABLE}")

def run_pytest():
    cmd = [sys.executable, '-m', 'pytest', 'tests/', '-v', '--tb=short']
    log("运行 pytest 测试...")
    env = os.environ.copy()
    env['PYTHONIOENCODING'] = 'utf-8'
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            encoding='utf-8',
            errors='ignore',
            timeout=120
        )
        if result.returncode == 0:
            log("pytest 全部通过")
            # 记录测试输出
            with open(LOG_FILE, 'a', encoding='utf-8') as f:
                f.write(f"[Pytest] 全部通过\n")
                for line in result.stdout.split('\n')[:30]:
                    f.write(f"[Pytest] {line}\n")
            return True, result.stdout
        else:
            log(f"pytest 失败，退出码 {result.returncode}")
            with open(LOG_FILE, 'a', encoding='utf-8') as f:
                f.write(f"[Pytest] 失败，退出码 {result.returncode}\n")
                for line in result.stderr.split('\n')[:30]:
                    f.write(f"[Pytest ERROR] {line}\n")
            return False, result.stderr
    except subprocess.TimeoutExpired:
        log("pytest 超时")
        return False, "Timeout"
    except Exception as e:
        log(f"pytest 执行异常: {e}")
        return False, str(e)

def run_llm_evaluation():
    """使用 LLM (Architect) 对 BenchVul 样本进行漏洞检测，返回准确率与报告"""
    global judge_model
    import json
    import os
    from langchain_core.messages import HumanMessage, SystemMessage
    import random
    from src import ast_analyzer
    
    BENCH_SAMPLES_PATH = "src/benchmark/reposvul_mini.json"
    if not os.path.exists(BENCH_SAMPLES_PATH):
        log(f"错误：基准样本文件不存在 {BENCH_SAMPLES_PATH}")
        return 0.0, "文件未找到"
    
    if judge_model is None:
        log("裁判模型不可用，尝试重新初始化...")
        judge_model = get_judge_model()
        if judge_model is None:
            log("裁判模型重新初始化失败，跳过 LLM 评估")
            return 0.0, "裁判模型未初始化"
    
    with open(BENCH_SAMPLES_PATH, 'r', encoding='utf-8') as f:
        samples = json.load(f)
    
    total = len(samples)
    
    # 抽样评估策略：最多随机抽取50个样本进行测试与错题收集
    sample_size = min(50, total)
    if sample_size < total:
        sampled_samples = random.sample(samples, sample_size)
        log(f"随机抽取 {sample_size} 个样本进行评估（共 {total} 个）")
        evaluate_samples = sampled_samples
        full_evaluation_needed = False
    else:
        evaluate_samples = samples
        full_evaluation_needed = True  # 样本数不足20，直接全量评估

    # API 防护网：指数退避重试
    def invoke_with_retry(model, messages, max_retries=5):
        import time
        last_exception = None
        for retry in range(max_retries):
            try:
                return model.invoke(messages)
            except Exception as e:
                last_exception = e
                # 检查是否为速率限制错误（429）或网络超时
                if "429" in str(e) or "rate limit" in str(e).lower() or "timeout" in str(e).lower():
                    wait = 2 ** retry  # 指数退避：2, 4, 8, 16, 32秒
                    log(f"API 限流/超时，第 {retry+1}/{max_retries} 次重试，等待 {wait} 秒")
                    time.sleep(wait)
                else:
                    # 其他异常，直接抛出
                    raise
        # 所有重试都失败
        raise last_exception

    correct = 0
    details = []
    cwe_counter = {}
    total_written = 0
    collect_errors = True
    
    # 第一阶段：评估抽样样本（错题收集仅限此阶段）
    for idx, sample in enumerate(evaluate_samples):
        cve = sample.get("CVE", "unknown")
        cwe = sample.get("cwe", "")
        code = sample.get("code", "")
        true_label = sample.get("label", "").lower()
        language = sample.get("language", "")
        
        if language != "python":
            details.append(f"样本 {cve} 语言 {language} 跳过")
            continue
        
        # 标签规范化
        true_label_lower = true_label
        if true_label_lower in ["vulnerable", "1", "yes", "true"]:
            true_label_lower = "vulnerable"
        elif true_label_lower in ["safe", "0", "no", "false"]:
            true_label_lower = "safe"
        
        # AST 语义预过滤
        ast_summary = ast_analyzer.extract_semantic_summary(code)
        # Token 物理拦截：无危险调用且代码行数小于20行，直接判定为安全
        if not ast_summary["has_dangerous_calls"] and ast_summary["line_count"] < 20:
            # 安全样本：真实标签应为 safe，否则为误判
            if true_label_lower == "safe":
                correct += 1
                details.append(f"样本 {cve} AST 预过滤安全 (无危险调用，{ast_summary['line_count']} 行)，正确")
                continue  # 跳过 LLM 调用
            else:
                # 真实标签是 vulnerable，但 AST 认为安全 → 可能漏报，记录细节
                details.append(f"样本 {cve} AST 预过滤安全 (无危险调用，{ast_summary['line_count']} 行)，但真实标签为 vulnerable (可能漏报)")
                # 继续 LLM 评估，因为可能存在 AST 未捕捉到的隐蔽漏洞
                pass

        # 构建 LLM 提示词
        prompt = f"""你是一个专业的漏洞分析专家。请分析以下 Python 代码片段，判断其是否存在安全漏洞，并给出对应的 CWE-ID（如果存在漏洞）或输出 "None"（如果安全）。同时请评估你对判断的置信度（0.0 表示完全不确定，1.0 表示完全确定）。

代码片段（CVE: {cve}）:
```
{code}
```

请严格按照以下 JSON 格式输出：
{{"cwe": "CWE-XXX" 或 "None", "vulnerable": true 或 false, "confidence": 0.0到1.0的浮点数}}

只输出 JSON，不要有任何额外解释。"""
        messages = [
            SystemMessage(content="你是一个专业的漏洞分析专家，擅长识别代码中的安全漏洞。"),
            HumanMessage(content=prompt)
        ]
        try:
            # 第一级：轻量模型判卷（带重试）
            response = invoke_with_retry(judge_model, messages)
            response_text = response.content if hasattr(response, 'content') else str(response)
            # 解析 JSON
            import re
            json_match = re.search(r'\{.*\}', response_text, re.DOTALL)
            confidence = 1.0  # 默认置信度
            if json_match:
                pred = json.loads(json_match.group())
                predicted_cwe = pred.get("cwe", "").strip()
                predicted_vuln = pred.get("vulnerable", False)
                confidence = pred.get("confidence", 1.0)
                if not isinstance(confidence, (int, float)):
                    confidence = 1.0
            else:
                # 回退：尝试提取 CWE 或关键字
                if "CWE-" in response_text:
                    predicted_cwe = re.search(r'CWE-\d+', response_text).group()
                    predicted_vuln = True
                else:
                    predicted_cwe = "None"
                    predicted_vuln = False
                confidence = 0.0  # 无法解析 JSON，置信度为零
            
            # 动态升级条件：置信度低于阈值或 JSON 解析异常
            if confidence < 0.85 or not json_match:
                details.append(f"样本 {cve} 轻量模型置信度 {confidence:.2f} 不足，升级到教练模型")
                # 使用教练模型重新评估（同样的提示词，带重试）
                coach_response = invoke_with_retry(coach_model, messages)
                coach_text = coach_response.content if hasattr(coach_response, 'content') else str(coach_response)
                coach_json_match = re.search(r'\{.*\}', coach_text, re.DOTALL)
                if coach_json_match:
                    coach_pred = json.loads(coach_json_match.group())
                    predicted_cwe = coach_pred.get("cwe", "").strip()
                    predicted_vuln = coach_pred.get("vulnerable", False)
                    confidence = coach_pred.get("confidence", 1.0)
                    details.append(f"样本 {cve} 教练模型返回置信度 {confidence:.2f}")
                else:
                    # 教练模型也失败，保留轻量模型结果
                    details.append(f"样本 {cve} 教练模型也无法解析，保留轻量模型结果")
            
            # 确定预测标签
            predicted_label = "vulnerable" if predicted_vuln else "safe"
            # 匹配标签（官方标签可能是 vulnerable/safe）
            true_label_lower = true_label
            if true_label_lower in ["vulnerable", "1", "yes", "true"]:
                true_label_lower = "vulnerable"
            elif true_label_lower in ["safe", "0", "no", "false"]:
                true_label_lower = "safe"
            
            # CWE 匹配（如果提供了 CWE）
            cwe_match = False
            if cwe and predicted_cwe != "None":
                # 简单字符串包含匹配
                cwe_match = (cwe.lower() == predicted_cwe.lower())
            
            # 严格计分
            if true_label_lower == "safe":
                # 安全样本：必须预测 safe
                if predicted_label == "safe":
                    correct += 1
                    details.append(f"样本 {cve} 正确：预测 safe，真实 safe (置信度 {confidence:.2f})")
                else:
                    details.append(f"样本 {cve} 错误：预测 {predicted_label}，真实 safe (置信度 {confidence:.2f})")
                    # 将错误样本写入 .ai_knowledge/wrong_cases.md（Token 止血截断）
                    cwe_key = "safe"  # 安全样本没有 CWE，用 "safe" 作为键
                    if collect_errors:
                        if cwe_counter.get(cwe_key, 0) < 2 and total_written < 10:
                            wrong_case_path = ".ai_knowledge/wrong_cases.md"
                            os.makedirs(os.path.dirname(wrong_case_path), exist_ok=True)
                            with open(wrong_case_path, "a", encoding="utf-8") as f:
                                f.write(f"## CVE: {cve}\n")
                                f.write(f"**真实标签**: {true_label}\n")
                                f.write(f"**真实 CWE**: {cwe}\n")
                                f.write(f"**预测标签**: {predicted_label}\n")
                                f.write(f"**预测 CWE**: {predicted_cwe}\n")
                                f.write(f"**置信度**: {confidence:.2f}\n")
                                f.write(f"```python\n{code}\n```\n\n")
                            cwe_counter[cwe_key] = cwe_counter.get(cwe_key, 0) + 1
                            total_written += 1
                            details.append(f"样本 {cve} 错题已记录（{cwe_key}）")
                        else:
                            details.append(f"样本 {cve} 错题已跳过（{cwe_key} 已达上限或总数超限）")
                    else:
                        details.append(f"样本 {cve} 错题未记录（全量回归测试模式）")
            elif true_label_lower == "vulnerable":
                # 漏洞样本：必须预测 vulnerable 且 CWE 匹配
                if predicted_label == "vulnerable" and predicted_cwe == cwe:
                    correct += 1
                    details.append(f"样本 {cve} 正确：预测 vulnerable，真实 vulnerable，预测 CWE {predicted_cwe} 匹配真实 CWE {cwe} (置信度 {confidence:.2f})")
                else:
                    # 标签错误或 CWE 不匹配
                    details.append(f"样本 {cve} 错误：预测 {predicted_label}，预测 CWE {predicted_cwe}，真实 CWE {cwe} (置信度 {confidence:.2f})")
                    # 将错误样本写入 .ai_knowledge/wrong_cases.md（Token 止血截断）
                    cwe_key = cwe if cwe else "unknown"
                    if collect_errors:
                        if cwe_counter.get(cwe_key, 0) < 2 and total_written < 10:
                            wrong_case_path = ".ai_knowledge/wrong_cases.md"
                            os.makedirs(os.path.dirname(wrong_case_path), exist_ok=True)
                            with open(wrong_case_path, "a", encoding="utf-8") as f:
                                f.write(f"## CVE: {cve}\n")
                                f.write(f"**真实标签**: {true_label}\n")
                                f.write(f"**真实 CWE**: {cwe}\n")
                                f.write(f"**预测标签**: {predicted_label}\n")
                                f.write(f"**预测 CWE**: {predicted_cwe}\n")
                                f.write(f"**置信度**: {confidence:.2f}\n")
                                f.write(f"```python\n{code}\n```\n\n")
                            cwe_counter[cwe_key] = cwe_counter.get(cwe_key, 0) + 1
                            total_written += 1
                            details.append(f"样本 {cve} 错题已记录（{cwe_key}）")
                        else:
                            details.append(f"样本 {cve} 错题已跳过（{cwe_key} 已达上限或总数超限）")
                    else:
                        details.append(f"样本 {cve} 错题未记录（全量回归测试模式）")
            else:
                # 未知标签
                details.append(f"样本 {cve} 未知真实标签 {true_label}，跳过")
        
        except Exception as e:
            details.append(f"样本 {cve} LLM 评估异常: {e}")
    
    accuracy = correct / total if total > 0 else 0.0
    report = f"LLM 评估准确率: {accuracy:.2%} ({correct}/{total})\n" + "\n".join(details)
    log(report)
    return accuracy, report

def evolve_prompt_templates():
    """读取 .ai_knowledge/wrong_cases.md 并调用 LLM 重写 src/prompt_templates.json 中的漏洞检测提示词"""
    import json
    import os
    import re
    
    wrong_case_path = ".ai_knowledge/wrong_cases.md"
    prompt_template_path = "src/prompt_templates.json"
    
    if not os.path.exists(wrong_case_path):
        log(f"未找到错误案例文件 {wrong_case_path}，跳过提示词进化")
        return
    
    # 检查教练模型是否可用
    global coach_model
    if coach_model is None:
        log(f"教练模型不可用，无法进行提示词进化，跳过")
        return
    
    log(f"读取错误案例文件 {wrong_case_path}")
    with open(wrong_case_path, 'r', encoding='utf-8') as f:
        wrong_cases_content = f.read()
    
    # 读取当前提示词模板
    if not os.path.exists(prompt_template_path):
        log(f"提示词模板文件不存在 {prompt_template_path}，跳过")
        return
    
    with open(prompt_template_path, 'r', encoding='utf-8') as f:
        templates = json.load(f)
    
    current_prompt = templates.get("vulnerability_detection_prompt", "")
    
    # 构建 LLM 请求
    from langchain_core.messages import SystemMessage, HumanMessage
    
    system_prompt = "你是一个安全专家，擅长分析漏洞检测提示词中的缺陷并提出改进方案。"
    user_prompt = f"""之前的漏洞检测提示词在以下案例中判断错误：

{wrong_cases_content}

请分析错误原因，并重写一个新的漏洞检测提示词。新的提示词应该能够更准确地识别这些漏洞模式。

当前提示词模板是：
{current_prompt}

请输出一个合法的 JSON 对象，包含两个键："architect_system_prompt" 和 "vulnerability_detection_prompt"。其中 "vulnerability_detection_prompt" 必须是重写后的新提示词，"architect_system_prompt" 可以保持不变或适当调整。

只输出 JSON，不要有任何额外解释。"""
    
    messages = [
        SystemMessage(content=system_prompt),
        HumanMessage(content=user_prompt)
    ]
    
    # 重试机制
    max_retries = 3
    retry_delay = 5  # 秒
    for attempt in range(max_retries):
        try:
            log(f"调用 LLM 进行提示词进化... (尝试 {attempt + 1}/{max_retries})")
            response = coach_model.invoke(messages)
            response_text = response.content if hasattr(response, 'content') else str(response)
            
            # 解析 JSON
            import re
            json_match = re.search(r'\{.*\}', response_text, re.DOTALL)
            if json_match:
                new_templates = json.loads(json_match.group())
                # 确保包含必要的键
                if "architect_system_prompt" not in new_templates:
                    new_templates["architect_system_prompt"] = templates.get("architect_system_prompt", "")
                if "vulnerability_detection_prompt" not in new_templates:
                    new_templates["vulnerability_detection_prompt"] = current_prompt
                # 覆盖写入文件
                with open(prompt_template_path, 'w', encoding='utf-8') as f:
                    json.dump(new_templates, f, ensure_ascii=False, indent=2)
                log(f"已保存 LLM 生成的新提示词模板至 {prompt_template_path}")
                break  # 成功，退出重试循环
            else:
                log(f"LLM 返回内容中未找到 JSON，进化失败。响应: {response_text[:200]}")
                if attempt == max_retries - 1:
                    log("已达到最大重试次数，放弃进化")
                else:
                    import time
                    time.sleep(retry_delay)
                    continue
        except Exception as e:
            log(f"提示词进化过程中出现异常 (尝试 {attempt + 1}/{max_retries}): {e}")
            if attempt == max_retries - 1:
                log("已达到最大重试次数，放弃进化")
            else:
                import time
                time.sleep(retry_delay)
                continue

def run_benchvul_evaluation():
    """使用 Bandit 对 BenchVul 样本进行评估，返回准确率与报告"""
    import json
    import tempfile
    import subprocess
    import os
    
    BENCH_SAMPLES_PATH = "src/benchmark/bench_samples.json"
    if not os.path.exists(BENCH_SAMPLES_PATH):
        log(f"错误：基准样本文件不存在 {BENCH_SAMPLES_PATH}")
        return 0.0, "文件未找到"
    
    with open(BENCH_SAMPLES_PATH, 'r', encoding='utf-8') as f:
        samples = json.load(f)
    
    total = len(samples)
    correct = 0
    details = []
    
    for idx, sample in enumerate(samples):
        cve = sample.get("CVE", "unknown")
        code = sample.get("code", "")
        true_label = sample.get("label", "").lower()
        language = sample.get("language", "")
        
        # 仅评估 Python 样本
        if language != "python":
            details.append(f"样本 {cve} 语言 {language} 跳过")
            continue
        
        # 创建临时文件
        with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as tmp:
            tmp.write(code)
            tmp_path = tmp.name
        
        try:
            # 运行 bandit
            cmd = ["bandit", "-f", "json", "-q", tmp_path]
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            # 解析 JSON 输出
            if result.returncode == 0:
                output = json.loads(result.stdout)
                # 如果有发现漏洞，则预测为 vulnerable
                issues = output.get("results", [])
                predicted = "vulnerable" if issues else "safe"
            else:
                # bandit 返回非零可能是发现了漏洞，但我们也尝试解析
                try:
                    output = json.loads(result.stdout)
                    issues = output.get("results", [])
                    predicted = "vulnerable" if issues else "safe"
                except:
                    predicted = "safe"
            
            # 匹配标签（忽略大小写）
            true_label_lower = true_label
            if true_label_lower in ["vulnerable", "1", "yes", "true"]:
                true_label_lower = "vulnerable"
            elif true_label_lower in ["safe", "0", "no", "false"]:
                true_label_lower = "safe"
            
            if predicted == true_label_lower:
                correct += 1
                details.append(f"样本 {cve} 正确：预测 {predicted}，真实 {true_label}")
            else:
                details.append(f"样本 {cve} 错误：预测 {predicted}，真实 {true_label}")
        
        except Exception as e:
            details.append(f"样本 {cve} 评估异常: {e}")
        finally:
            os.unlink(tmp_path)
    
    accuracy = correct / total if total > 0 else 0.0
    report = f"BenchVul 评估准确率: {accuracy:.2%} ({correct}/{total})\n" + "\n".join(details)
    log(report)
    return accuracy, report

def main():
    global success_count
    # 清空旧日志
    if os.path.exists(LOG_FILE):
        os.remove(LOG_FILE)
    log("=== 天灵进化监护人 v3 启动 ===")
    backup_stable()
    
    # 初始 BenchVul 评估（Bandit 基线 + LLM 裁判）
    log("=== 初始 BenchVul 评估 (Bandit 基线) ===")
    initial_bandit_accuracy, initial_bandit_report = run_benchvul_evaluation()
    log("=== 初始 BenchVul 评估 (LLM 裁判) ===")
    initial_llm_accuracy, initial_llm_report = run_llm_evaluation()
    
    round_num = 1
    while round_num <= MAX_ROUNDS:
        log(f"\n--- 第 {round_num} 轮进化 ---")
        # 检查错题本是否存在且非空
        wrong_case_path = ".ai_knowledge/wrong_cases.md"
        if os.path.exists(wrong_case_path) and os.path.getsize(wrong_case_path) > 0:
            log(f"发现错题本，进行提示词进化")
            evolve_prompt_templates()
            # 清空错题本，以便下一轮收集新的错误
            open(wrong_case_path, 'w', encoding='utf-8').close()
        else:
            log(f"错题本为空，跳过提示词进化")
        # 使用当前提示词重新评估
        log(f"第 {round_num} 轮 LLM 评估")
        llm_accuracy, llm_report = run_llm_evaluation()
        # 记录本轮分数
        log(f"第 {round_num} 轮准确率: {llm_accuracy:.2%}")
        round_num += 1
    
    # 最终 BenchVul 评估（Bandit 基线 + LLM 裁判）
    log("\n=== 最终 BenchVul 评估 (Bandit 基线) ===")
    final_bandit_accuracy, final_bandit_report = run_benchvul_evaluation()
    log("\n=== 最终 BenchVul 评估 (LLM 裁判) ===")
    final_llm_accuracy, final_llm_report = run_llm_evaluation()
    
    # 对比报告
    comparison = f"""
BenchVul 检测精度对比报告
==========================
[Baseline] Bandit 传统工具:
  初始准确率: {initial_bandit_accuracy:.2%}
  最终准确率: {final_bandit_accuracy:.2%}
  准确率变化: {final_bandit_accuracy - initial_bandit_accuracy:+.2%}
  进化效果: {'提升' if final_bandit_accuracy > initial_bandit_accuracy else '下降' if final_bandit_accuracy < initial_bandit_accuracy else '持平'}

[Tianling-AI Agent] LLM 语义对齐:
  初始准确率: {initial_llm_accuracy:.2%}
  最终准确率: {final_llm_accuracy:.2%}
  准确率变化: {final_llm_accuracy - initial_llm_accuracy:+.2%}
  进化效果: {'提升' if final_llm_accuracy > initial_llm_accuracy else '下降' if final_llm_accuracy < initial_llm_accuracy else '持平'}
"""
    log(comparison)
    with open(LOG_FILE, 'a', encoding='utf-8') as f:
        f.write(comparison)
    
    log("\n=== 进化监护人完成 ===")
    if success_count >= CONSECUTIVE_SUCCESSES_NEEDED:
        log("进化成功：系统已稳定")
        stable_size = count_logic_lines(DEBATE_NODE_STABLE)
        report = f"""
进化监护人最终报告
===================
- 达到连续 {CONSECUTIVE_SUCCESSES_NEEDED} 轮成功
- 最终稳定文件: {DEBATE_NODE_STABLE}
- 核心逻辑行数: {stable_size}
- 内化的安全规则: pytest 仲裁、路径映射、硬性约束、关键函数保留
- 关键失败记录: 参见 {ERROR_VAULT_PATH}
"""
        print(report)
        with open(LOG_FILE, 'a', encoding='utf-8') as f:
            f.write(report)
    else:
        log(f"进化未达到稳定（最大轮次 {MAX_ROUNDS}）")

if __name__ == "__main__":
    main()