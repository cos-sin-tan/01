#!/usr/bin/env python3
"""
无人值守入口脚本
接收自然语言任务，启动 LangGraph 智能体循环，无需任何人工交互。
"""
import sys
import os

# 将项目根目录添加到 Python 路径，确保可以导入 src 模块
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from src.main_agent import main

if __name__ == "__main__":
    if len(sys.argv) < 2:
        # 如果没有提供任务，使用默认测试任务（仅用于演示）
        print("警告：未提供任务描述，使用默认测试任务。")
        task = "编写一个能扫描本项目中所有 Python 文件是否存在语法错误的脚本"
    else:
        task = sys.argv[1]
    
    # 将任务作为命令行参数传递给 main_agent.main
    # main_agent.main 期望 sys.argv[1] 是任务描述，因此我们临时修改 sys.argv
    sys.argv = [sys.argv[0], task]
    
    print(f"=== 无人值守智能体启动 ===")
    print(f"任务: {task}")
    print("开始执行...")
    
    # 调用主函数
    main()