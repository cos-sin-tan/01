# PowerShell script to create a desktop shortcut for LangGraph Agent
$DesktopPath = [Environment]::GetFolderPath("Desktop")
$ShortcutPath = Join-Path $DesktopPath "LangGraph Agent.lnk"
$TargetPath = Join-Path $PSScriptRoot "run_agent.bat"
$WScriptShell = New-Object -ComObject WScript.Shell
$Shortcut = $WScriptShell.CreateShortcut($ShortcutPath)
$Shortcut.TargetPath = $TargetPath
$Shortcut.WorkingDirectory = $PSScriptRoot
$Shortcut.IconLocation = "C:\Windows\System32\cmd.exe,0"
$Shortcut.Description = "Launch LangGraph Intelligent Agent"
$Shortcut.Save()
Write-Output "Shortcut created: $ShortcutPath"
Write-Output "You can now double-click the shortcut on your desktop to run the agent."