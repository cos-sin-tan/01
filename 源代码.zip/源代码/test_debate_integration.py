#!/usr/bin/env python3
"""集成测试 DebateNode 的沙盒路径读取修复"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from src.debate_node import DebateNode

def test_debate_path_resolution_with_files():
    """测试 DebateNode 在实际文件操作中的路径处理"""
    print("=== 测试 DebateNode 沙盒路径集成 ===")
    
    # 初始化 DebateNode
    debater = DebateNode(max_rounds=1)
    
    # 测试1: 读取不存在的文件（应该优雅处理）
    print("\n1. 测试读取不存在的文件...")
    resolved_path = debater._resolve_sandbox_path("src/nonexistent.py")
    print(f"   解析路径: src/nonexistent.py -> {resolved_path}")
    # 注意：在Windows上路径分隔符会被规范化，所以比较前也规范化预期路径
    expected = os.path.normpath("src/staging/nonexistent.py")
    assert os.path.normpath(resolved_path) == expected, f"{resolved_path} != {expected}"
    
    # 测试2: 读取 staging 目录中已存在的文件
    print("\n2. 测试读取 staging 中的现有文件...")
    test_file = "src/staging/existing.py"
    resolved_path = debater._resolve_sandbox_path(test_file)
    print(f"   解析路径: {test_file} -> {resolved_path}")
    # 应该直接返回原路径（已经是 staging 路径）
    assert os.path.normpath(resolved_path) == os.path.normpath(test_file)
    
    # 测试3: 测试写入文件的路径转换
    print("\n3. 测试写入文件的路径转换...")
    test_files = [
        {"path": "src/new_module.py", "content": "print('hello')"},
        {"path": "tests/test_module.py", "content": "import unittest"},
        {"path": "config.json", "content": "{}"}
    ]
    
    for file_info in test_files:
        original = file_info["path"]
        staged = debater._resolve_sandbox_path(original)
        print(f"   {original:30} -> {staged}")
        
        # 验证转换规则
        if original.startswith("src/"):
            assert staged.replace('\\', '/').startswith("src/staging/")
        elif original.startswith("tests/"):
            assert staged.replace('\\', '/').startswith("staging/tests/")
        else:
            assert staged.replace('\\', '/').startswith("staging/")
    
    # 测试4: 测试重复转换（已经是 staging 路径）
    print("\n4. 测试重复转换保护...")
    staging_paths = [
        "src/staging/already.py",
        "staging/tests/already.py",
        "staging/config.yaml"
    ]
    for path in staging_paths:
        result = debater._resolve_sandbox_path(path)
        print(f"   {path:30} -> {result}")
        assert os.path.normpath(result) == os.path.normpath(path), f"重复转换失败: {path} -> {result}"
    
    print("\n[PASS] 所有集成测试通过！")
    return True

if __name__ == "__main__":
    try:
        test_debate_path_resolution_with_files()
        print("\n=== 测试总结 ===")
        print("DebateNode 沙盒路径读取 Bug 修复验证成功。")
        print("路径转换逻辑现在统一且健壮。")
    except Exception as e:
        print(f"\n[FAIL] 测试失败: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)