#!/usr/bin/env python3
"""
快速测试 architect_node 是否能够调用 LLM 并生成 System_Spec.json。
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from src.main_agent import architect_node

# 模拟初始状态
state = {
    'task_description': '自举任务：优化自身提示词模板',
    'current_node': 'architect',
    'error_message': None,
    'audit_results': {},
    'need_search': False,
    'relevant_knowledge': '',
    'system_spec': None,
    'blueprint': None,
    'lessons_learned': [],
    'current_consensus': '',
    'diagnostic_vector': {},
    'token_usage': {}
}

print("=== 测试 architect_node ===")
try:
    new_state = architect_node(state)
    print("architect_node 执行成功")
    print(f"new_state keys: {list(new_state.keys())}")
    if 'system_spec' in new_state:
        print("生成 system_spec:", new_state['system_spec'])
    else:
        print("未生成 system_spec，错误信息:", new_state.get('error_message', '无'))
except Exception as e:
    print(f"architect_node 执行异常: {e}")
    import traceback
    traceback.print_exc()