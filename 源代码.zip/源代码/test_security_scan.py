#!/usr/bin/env python3
"""
测试“天灵”架构的神经符号验证闸门与反思学习能力。
模拟一个包含命令注入漏洞的代码文件，运行 Auditor 节点进行 Bandit 扫描，
并验证 Reflection 节点是否记录教训。
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# 设置环境变量，确保 Auditor 进入真实扫描模式（非模拟）
os.environ['DEEPSEEK_API_KEY'] = ''  # 非 'test' 值

from src.main_agent import auditor_node, AgentState
from src.context_manager import get_context_manager

def test_vulnerability_detection():
    """测试 Bandit 扫描能否检测到命令注入漏洞"""
    print("=== 天灵安全测试：命令注入漏洞检测 ===")
    
    # 1. 准备状态，模拟 Coder 刚编写了漏洞脚本
    state: AgentState = {
        "task_description": "安全测试",
        "blueprint": None,
        "deliverables": {
            "code": "src/test_vulnerability.py"  # 漏洞脚本路径
        },
        "audit_results": {},
        "error_message": None,
        "iteration": 0,
        "current_node": "coder",  # 表示刚来自 Coder 节点
        "relevant_knowledge": None,
        # 协议字段
        "system_spec": None,
        "hard_constraints": None,
        "diagnostic_vector": None,
        "lessons_learned": None,
        "current_consensus": None,
        "token_usage": {},
    }
    
    # 2. 运行 Auditor 节点（非模拟模式）
    print("[测试] 调用 Auditor 节点（神经符号验证闸门）...")
    try:
        new_state = auditor_node(state)
    except Exception as e:
        print(f"[测试] Auditor 执行异常: {e}")
        # 可能是 Bandit 未安装等，但我们已经安装了
        import traceback
        traceback.print_exc()
        return
    
    # 3. 检查诊断向量
    diagnostic = new_state.get('diagnostic_vector')
    if diagnostic:
        print(f"[测试] 诊断向量: {diagnostic.get('verdict')}")
        errors = diagnostic.get('errors', [])
        if errors:
            print(f"[测试] Bandit 发现 {len(errors)} 个安全问题:")
            for err in errors:
                print(f"  - {err.get('file')}:{err.get('line')} {err.get('severity')} {err.get('message')}")
        else:
            print("[测试] Bandit 未发现安全问题（不符合预期）")
    else:
        print("[测试] 无诊断向量（不符合预期）")
    
    # 4. 检查审计结果
    audit_results = new_state.get('audit_results', {})
    print(f"[测试] 审计结果: {audit_results}")
    
    # 5. 检查错误知识库是否更新
    cm = get_context_manager()
    error_vault_path = cm.error_vault_path
    if os.path.exists(error_vault_path):
        with open(error_vault_path, 'r', encoding='utf-8') as f:
            content = f.read()
            if 'command injection' in content.lower() or 'B605' in content:
                print("[测试] ✅ 错误知识库已记录命令注入教训")
            else:
                print("[测试] ⚠ 错误知识库未找到相关教训，可能未触发 Reflection 节点")
    else:
        print("[测试] 错误知识库文件不存在")
    
    # 6. 输出总结
    if diagnostic and diagnostic.get('verdict') == 'fail':
        print("\n✅ 安全测试通过：Bandit 成功拦截命令注入漏洞，诊断向量标记为失败。")
    else:
        print("\n❌ 安全测试未通过：Bandit 未正确检测到漏洞或诊断向量未标记失败。")

if __name__ == "__main__":
    test_vulnerability_detection()