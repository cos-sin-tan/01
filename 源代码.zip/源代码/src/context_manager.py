#!/usr/bin/env python3
"""
Context_Manager 类：负责动态上下文蒸馏、Token 计数与错误知识库管理。
"""

import os
import json
import re
from typing import Dict, List, Any, Optional
from pathlib import Path
from datetime import datetime

class ContextManager:
    """上下文管理器，实现蒸馏、Token 计数与 error_vault 管理"""
    
    def __init__(self, token_budget_multiplier: float = 1000.0):
        """
        初始化上下文管理器。
        
        Args:
            token_budget_multiplier: Token 预算乘数，默认 1000.0 (即允许 1000 倍的初始 Token 量，避免过早触发任务拆解)
        """
        self.token_budget_multiplier = token_budget_multiplier
        self.total_tokens = 0
        self.state_history = []          # 保留最近 2 个状态（蒸馏后）
        self.error_vault_path = Path(".ai_knowledge/error_vault.md")
        self._ensure_error_vault()
        
    def _ensure_error_vault(self):
        """确保 error_vault.md 文件存在"""
        self.error_vault_path.parent.mkdir(parents=True, exist_ok=True)
        if not self.error_vault_path.exists():
            with open(self.error_vault_path, 'w', encoding='utf-8') as f:
                f.write("# 错误知识库 (Error Vault)\n\n")
                f.write("本文件记录多智能体协作过程中产生的经验教训，供后续迭代检索学习。\n\n")
                f.write("---\n\n")
    
    def distill(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """
        从当前状态提取共识，丢弃 80% 的冗余中间对话。
        
        返回 Current_Consensus.json 格式的字典。
        """
        # 提取关键事实
        agreed_facts = []
        open_issues = []
        
        # 1. 任务概述
        task_desc = state.get('task_description', '未知任务')
        agreed_facts.append(f"任务目标：{task_desc[:100]}...")
        
        # 2. 系统规范
        system_spec = state.get('system_spec')
        if system_spec:
            summary = system_spec.get('task_summary', '')
            if summary:
                agreed_facts.append(f"系统规范：{summary}")
            # 提取约束
            constraints = system_spec.get('constraints', [])
            if isinstance(constraints, list):
                for c in constraints[:3]:  # 最多三条
                    c_type = c.get('type', 'unknown')
                    c_desc = c.get('description', '')
                    agreed_facts.append(f"约束 {c_type}：{c_desc[:50]}")
            elif isinstance(constraints, dict):
                for key, val in constraints.items():
                    if isinstance(val, list):
                        agreed_facts.append(f"约束 {key}：{', '.join(val[:3])}")
        
        # 3. 交付物进展
        deliverables = state.get('deliverables', {})
        for key, path in deliverables.items():
            if path and os.path.exists(path):
                agreed_facts.append(f"已生成 {key} 交付物：{path}")
            else:
                open_issues.append(f"缺失 {key} 交付物")
        
        # 4. 诊断向量
        diagnostic = state.get('diagnostic_vector')
        if diagnostic:
            overall_pass = diagnostic.get('overall_pass', True)
            if not overall_pass:
                diags = diagnostic.get('diagnostics', [])
                for d in diags[:2]:  # 取前两个诊断
                    open_issues.append(f"{d.get('type')}：{d.get('message')}")
        
        # 5. 当前节点
        current_node = state.get('current_node', 'unknown')
        next_step = self._suggest_next_step(state)
        
        # 构建共识字典
        consensus = {
            "iteration": state.get('iteration', 0),
            "agreed_facts": agreed_facts,
            "open_issues": open_issues,
            "next_step": next_step,
            "token_usage": {
                "total_tokens": self.total_tokens,
                "budget_remaining": self._calculate_budget_remaining(state)
            },
            "timestamp": datetime.now().isoformat()
        }
        
        # 保留最近两个状态（用于可能的回滚）
        self.state_history.append(consensus)
        if len(self.state_history) > 2:
            self.state_history.pop(0)
        
        return consensus
    
    def _suggest_next_step(self, state: Dict[str, Any]) -> str:
        """根据当前状态建议下一个节点"""
        current = state.get('current_node', '')
        error = state.get('error_message')
        diagnostic = state.get('diagnostic_vector')
        
        if error:
            # 有错误，根据错误类型决定折返目标
            if current in ('auditor_code', 'auditor_report', 'auditor_ppt'):
                # 审计失败，折返给对应生产节点
                return current.replace('auditor_', '')
            else:
                return 'coder'  # 默认折返给 Coder
        else:
            # 无错误，按流程前进
            if current == 'architect':
                return 'coder'
            elif current == 'coder':
                return 'auditor_code'
            elif current == 'auditor_code':
                return 'reporter'
            elif current == 'reporter':
                return 'auditor_report'
            elif current == 'auditor_report':
                return 'presenter'
            elif current == 'presenter':
                return 'auditor_ppt'
            elif current == 'auditor_ppt':
                return 'end'
            else:
                return 'end'
    
    def _calculate_budget_remaining(self, state: Dict[str, Any]) -> int:
        """计算剩余 Token 预算（假设初始基线为 5000 token）"""
        initial_baseline = 5000   # 可以改为从状态中读取
        budget = int(initial_baseline * self.token_budget_multiplier)
        remaining = budget - self.total_tokens
        return max(remaining, 0)
    
    def update_token_usage(self, node_name: str, input_tokens: int, output_tokens: int):
        """
        更新 Token 计数。
        
        Args:
            node_name: 节点名称（用于日志）
            input_tokens: 输入 Token 数
            output_tokens: 输出 Token 数
        """
        node_total = input_tokens + output_tokens
        self.total_tokens += node_total
        print(f"[ContextManager] {node_name} 消耗 {node_total} token，累计 {self.total_tokens}")
    
    def is_within_budget(self, initial_tokens: int) -> bool:
        """
        检查总 Token 是否在预算内。
        
        Args:
            initial_tokens: 初始基线 Token 数
        
        Returns:
            布尔值，True 表示在预算内
        """
        budget = int(initial_tokens * self.token_budget_multiplier)
        return self.total_tokens <= budget
    
    def get_error_vault(self, keywords: List[str]) -> List[str]:
        """
        从 error_vault.md 中检索包含关键词的经验教训。
        
        Args:
            keywords: 关键词列表
        
        Returns:
            匹配的行列表（每行是一个教训片段）
        """
        if not self.error_vault_path.exists():
            return []
        
        with open(self.error_vault_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        
        # 简单关键词匹配（不区分大小写）
        matched = []
        for line in lines:
            line_lower = line.lower()
            for kw in keywords:
                if kw.lower() in line_lower:
                    matched.append(line.strip())
                    break
        
        return matched[:5]  # 最多返回 5 条
    
    def append_error_vault(self, lesson: Dict[str, Any]):
        """
        向 error_vault.md 追加新教训。
        
        Args:
            lesson: 教训字典，应包含以下字段：
                - error_id: 错误 ID
                - timestamp: 时间戳
                - trigger_node: 触发节点
                - error_type: 错误类型
                - code_snippet: 错误代码片段（可选）
                - fix_suggestion: 修复建议
                - root_cause: 根本原因
                - prevention: 预防措施
        """
        # 确保文件存在
        self._ensure_error_vault()
        
        # 格式化教训
        entry = f"""
## 错误 ID: {lesson.get('error_id', 'UNKNOWN')}
- **时间**: {lesson.get('timestamp', datetime.now().isoformat())}
- **触发节点**: {lesson.get('trigger_node', 'unknown')}
- **错误类型**: {lesson.get('error_type', '未知')}
- **错误代码片段**: 
  ```python
  {lesson.get('code_snippet', '无')}
  ```
- **修复方案**: {lesson.get('fix_suggestion', '无')}
- **根本原因**: {lesson.get('root_cause', '无')}
- **预防措施**: {lesson.get('prevention', '无')}

---
"""
        with open(self.error_vault_path, 'a', encoding='utf-8') as f:
            f.write(entry)
        
        print(f"[ContextManager] 已向 error_vault.md 追加教训 {lesson.get('error_id')}")
    
    def get_current_consensus(self) -> Optional[Dict[str, Any]]:
        """获取最新的共识（如果存在）"""
        if self.state_history:
            return self.state_history[-1]
        return None

# 全局单例实例（供其他模块导入）
_context_manager_instance = None

def get_context_manager() -> ContextManager:
    """获取全局 ContextManager 单例"""
    global _context_manager_instance
    if _context_manager_instance is None:
        _context_manager_instance = ContextManager()
    return _context_manager_instance