#!/usr/bin/env python3
"""Bandit 集成演示脚本"""
import subprocess
import sys

def run_bandit(target: str = '.'):
    """运行 Bandit 扫描"""
    cmd = ['bandit', '-r', target, '-f', 'json']
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode == 0:
        print('Bandit 扫描完成，未发现高危漏洞')
    else:
        print(f'Bandit 扫描发现漏洞:\n{result.stdout}')
    return result.returncode

if __name__ == '__main__':
    sys.exit(run_bandit())
