#!/usr/bin/env python3
"""
MemoryGate 节点：动态上下文压缩

将长对话历史压缩为精炼的 JSON 摘要，减少 Token 浪费。
"""
import json
from typing import Dict, Any, List
import re

class MemoryGate:
    def __init__(self, max_summary_length: int = 500):
        self.max_summary_length = max_summary_length
    
    def compress(self, long_text: str) -> Dict[str, Any]:
        """
        压缩长文本为 JSON 摘要。
        简化实现：提取前几句作为摘要，并生成关键词列表。
        """
        sentences = re.split(r'[。！？!?.]', long_text)
        sentences = [s.strip() for s in sentences if s.strip()]
        summary = '。'.join(sentences[:3]) + '。'
        if len(summary) > self.max_summary_length:
            summary = summary[:self.max_summary_length] + '…'
        
        # 简单关键词提取（按空格分割）
        words = re.findall(r'\w+', long_text)
        from collections import Counter
        top_words = [word for word, _ in Counter(words).most_common(5)]
        
        return {
            "summary": summary,
            "key_points": top_words,
            "original_length": len(long_text),
            "compressed_length": len(summary)
        }

if __name__ == '__main__':
    mg = MemoryGate()
    test_text = "这是一段测试文本。" * 50
    result = mg.compress(test_text)
    print(json.dumps(result, ensure_ascii=False, indent=2))