import pytest
from src.safe_evaluator import SafeEvaluator


def test_safe_evaluation_valid_expressions():
    evaluator = SafeEvaluator()
    assert evaluator.evaluate("2 + 3") == 5
    assert evaluator.evaluate("10 - 4") == 6
    assert evaluator.evaluate("6 * 7") == 42
    assert evaluator.evaluate("15 / 3") == 5.0
    assert evaluator.evaluate("(2 + 3) * 4") == 20


def test_safe_evaluation_invalid_characters():
    evaluator = SafeEvaluator()
    with pytest.raises(ValueError, match="Invalid characters"):
        evaluator.evaluate("__import__('os').system('ls')")
    with pytest.raises(ValueError, match="Invalid characters"):
        evaluator.evaluate("import os")
    with pytest.raises(ValueError, match="Invalid characters"):
        evaluator.evaluate("eval('2+2')")


def test_safe_evaluation_empty_input():
    evaluator = SafeEvaluator()
    with pytest.raises(ValueError, match="Input cannot be empty"):
        evaluator.evaluate("")
    with pytest.raises(ValueError, match="Input cannot be empty"):
        evaluator.evaluate("   ")


def test_safe_evaluation_syntax_error():
    evaluator = SafeEvaluator()
    with pytest.raises(ValueError, match="Invalid expression"):
        evaluator.evaluate("2 + + 3")
    with pytest.raises(ValueError, match="Invalid expression"):
        evaluator.evaluate("2 / 0")


def test_safe_evaluation_with_spaces():
    evaluator = SafeEvaluator()
    assert evaluator.evaluate("  2 + 3  ") == 5
    assert evaluator.evaluate("\t10 - 4\n") == 6
