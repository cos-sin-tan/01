#!/usr/bin/env python3
"""
Unit tests for the safe expression evaluator.
"""

import pytest
from src.evaluator import safe_eval, evaluate_expression


def test_safe_eval_valid_expressions() -> None:
    """Test safe_eval with valid mathematical expressions."""
    # Basic arithmetic
    assert safe_eval("1 + 2") == 3
    assert safe_eval("5 - 3") == 2
    assert safe_eval("4 * 3") == 12
    assert safe_eval("10 / 2") == 5.0
    
    # Parentheses and precedence
    assert safe_eval("(1 + 2) * 3") == 9
    assert safe_eval("2 ** 3") == 8
    
    # Floating point
    assert safe_eval("3.14 * 2") == 6.28
    
    # Negative numbers
    assert safe_eval("-5 + 8") == 3
    
    # Complex expression
    assert safe_eval("2 * (3 + 4) - 5 / 2") == 11.5


def test_safe_eval_invalid_expressions() -> None:
    """Test safe_eval with invalid or dangerous expressions."""
    # Dangerous function calls
    with pytest.raises(ValueError, match="Invalid expression"):
        safe_eval("__import__('os').system('ls')")
    
    with pytest.raises(ValueError, match="Invalid expression"):
        safe_eval("open('test.txt', 'r')")
    
    # Attribute access
    with pytest.raises(ValueError, match="Invalid expression"):
        safe_eval("().__class__.__base__")
    
    # Invalid syntax
    with pytest.raises(ValueError, match="Invalid expression"):
        safe_eval("1 + ")
    
    # Empty expression
    with pytest.raises(ValueError, match="Expression cannot be empty"):
        safe_eval("")
    
    # Whitespace only
    with pytest.raises(ValueError, match="Expression cannot be empty"):
        safe_eval("   ")


def test_safe_eval_edge_cases() -> None:
    """Test edge cases and boundary conditions."""
    # Zero division
    with pytest.raises(ZeroDivisionError):
        safe_eval("1 / 0")
    
    # Large numbers
    assert safe_eval("1e6 + 2e6") == 3000000.0
    
    # Scientific notation
    assert safe_eval("1.23e4") == 12300.0


def test_evaluate_expression_valid_input() -> None:
    """Test the main evaluate_expression function with valid input."""
    # Test with valid expressions
    assert evaluate_expression("2 + 3") == 5
    assert evaluate_expression("10 * (2 + 3)") == 50
    
    # Test with spaces
    assert evaluate_expression("   5   +   3   ") == 8


def test_evaluate_expression_invalid_input() -> None:
    """Test the main evaluate_expression function with invalid input."""
    # Test with dangerous expression
    result = evaluate_expression("__import__('os').system('rm -rf /')")
    assert "Error" in result
    
    # Test with syntax error
    result = evaluate_expression("1 + * 2")
    assert "Error" in result
    
    # Test with empty input
    result = evaluate_expression("")
    assert "Error" in result


def test_evaluate_expression_error_handling() -> None:
    """Test error handling in evaluate_expression."""
    # Test division by zero
    result = evaluate_expression("1 / 0")
    assert "Error" in result
    assert "division" in result.lower()
    
    # Test invalid characters
    result = evaluate_expression("import os")
    assert "Error" in result


if __name__ == "__main__":
    pytest.main(["-v", "--tb=short"])