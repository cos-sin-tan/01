import pytest
import math
from src.safe_eval_expression import safe_eval_expression


def test_valid_basic_expressions() -> None:
    """测试基本的合法数学表达式"""
    assert safe_eval_expression("2 + 3") == 5
    assert safe_eval_expression("10 - 4") == 6
    assert safe_eval_expression("3 * 5") == 15
    assert safe_eval_expression("10 / 2") == 5.0
    assert safe_eval_expression("2 + 3 * 5") == 17
    assert safe_eval_expression("(2 + 3) * 5") == 25
    assert safe_eval_expression("2 ** 3") == 8
    assert safe_eval_expression("10 % 3") == 1


def test_valid_complex_expressions() -> None:
    """测试复杂的合法数学表达式"""
    assert safe_eval_expression("2 + 3 * (4 - 1)") == 11
    assert safe_eval_expression("(1 + 2) * (3 + 4)") == 21
    assert safe_eval_expression("2 ** 3 + 4 * 5") == 28
    assert safe_eval_expression("10 / (2 + 3)") == 2.0


def test_valid_decimal_expressions() -> None:
    """测试包含小数的表达式"""
    assert safe_eval_expression("3.14 * 2") == 6.28
    assert safe_eval_expression("0.5 + 0.25") == 0.75
    assert safe_eval_expression("10.0 / 4.0") == 2.5


def test_valid_spaces_in_expressions() -> None:
    """测试包含空格的表达式"""
    assert safe_eval_expression("  2 + 3  ") == 5
    assert safe_eval_expression("2+3") == 5  # 无空格
    assert safe_eval_expression("  ( 2 + 3 ) * 4  ") == 20


def test_invalid_characters() -> None:
    """测试包含非法字符的表达式"""
    with pytest.raises(ValueError, match="包含非法字符"):
        safe_eval_expression("import os")
    
    with pytest.raises(ValueError, match="包含非法字符"):
        safe_eval_expression("__import__('os').system('ls')")
    
    with pytest.raises(ValueError, match="包含非法字符"):
        safe_eval_expression("print('hello')")
    
    with pytest.raises(ValueError, match="包含非法字符"):
        safe_eval_expression("2 + x")  # 变量名
    
    with pytest.raises(ValueError, match="包含非法字符"):
        safe_eval_expression("abs(-5)")  # 函数调用


def test_empty_or_whitespace_only() -> None:
    """测试空字符串或仅包含空格的字符串"""
    with pytest.raises(ValueError, match="表达式不能为空"):
        safe_eval_expression("")
    
    with pytest.raises(ValueError, match="表达式不能为空"):
        safe_eval_expression("   ")
    
    with pytest.raises(ValueError, match="表达式不能为空"):
        safe_eval_expression("\t\n")


def test_invalid_syntax() -> None:
    """测试语法无效的表达式"""
    with pytest.raises(ValueError, match="语法错误"):
        safe_eval_expression("2 + * 3")
    
    with pytest.raises(ValueError, match="语法错误"):
        safe_eval_expression("())")
    
    with pytest.raises(ValueError, match="语法错误"):
        safe_eval_expression("2 + (3")


def test_division_by_zero() -> None:
    """测试除零错误"""
    with pytest.raises(ZeroDivisionError):
        safe_eval_expression("10 / 0")
    
    with pytest.raises(ZeroDivisionError):
        safe_eval_expression("5 % 0")


def test_performance() -> None:
    """测试性能要求（亚秒级完成）"""
    import time
    
    # 测试复杂但合法的表达式
    start_time = time.time()
    result = safe_eval_expression("((2 + 3) * (4 - 1) / 2) ** 2 + 100")
    end_time = time.time()
    
    execution_time = end_time - start_time
    assert execution_time < 1.0, f"执行时间 {execution_time} 秒超过亚秒级要求"
    
    # 验证结果正确性
    expected = ((2 + 3) * (4 - 1) / 2) ** 2 + 100
    assert result == expected


def test_edge_cases() -> None:
    """测试边界情况"""
    # 单个数字
    assert safe_eval_expression("42") == 42
    assert safe_eval_expression("3.14159") == 3.14159
    
    # 负数
    assert safe_eval_expression("-5 + 3") == -2
    assert safe_eval_expression("2 * -3") == -6
    
    # 多层括号
    assert safe_eval_expression("((((2 + 3))))") == 5
    
    # 大数字
    assert safe_eval_expression("1000000 * 1000000") == 1000000000000


def test_security_attempts() -> None:
    """测试安全攻击尝试"""
    # 尝试访问内置函数
    with pytest.raises(ValueError, match="包含非法字符"):
        safe_eval_expression("__builtins__")
    
    # 尝试访问属性
    with pytest.raises(ValueError, match="包含非法字符"):
        safe_eval_expression("().__class__")
    
    # 尝试执行代码
    with pytest.raises(ValueError, match="包含非法字符"):
        safe_eval_expression("exec('import os')")
    
    # 尝试使用 lambda
    with pytest.raises(ValueError, match="包含非法字符"):
        safe_eval_expression("lambda x: x + 1")


def test_return_type() -> None:
    """测试返回类型"""
    # 整数运算返回整数
    result = safe_eval_expression("2 + 3")
    assert isinstance(result, (int, float))
    
    # 浮点数运算返回浮点数
    result = safe_eval_expression("2.5 + 3.5")
    assert isinstance(result, float)
    
    # 除法返回浮点数
    result = safe_eval_expression("10 / 2")
    assert isinstance(result, float)


if __name__ == "__main__":
    pytest.main(["-v", "--tb=short"])
