import json
import re
from datetime import datetime
from dataclasses import dataclass, asdict
from typing import Dict, Any

@dataclass
class PromptTemplate:
    """提示词模板类"""
    name: str
    role: str
    task_logic: str
    output_format: str
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典格式"""
        return {
            "name": self.name,
            "role": self.role,
            "task_logic": self.task_logic,
            "output_format": self.output_format,
            "version": "1.0",
            "timestamp": datetime.now().isoformat()
        }

class PromptTemplateManager:
    """提示词模板管理器"""
    
    def __init__(self):
        pass
    
    def create_template_v1(self) -> PromptTemplate:
        """
        创建第一版优化提示词模板
        特点：结构化任务拆解，强调TDD
        """
        role = """
        ## 角色定义
        你是一个资深软件工程师，严格遵循测试驱动开发(TDD)原则。
        你的核心职责是：根据需求编写高质量、安全、可维护的代码。
        """
        
        task_logic = """
        ## 任务拆解逻辑
        
        ### 1. 需求分析
        - 仔细阅读所有需求描述
        - 识别硬性约束和安全要求
        - 分析历史错误教训，避免重复
        
        ### 2. 测试先行（TDD）
        - **首先**编写测试用例
        - 测试应覆盖主要功能和边界情况
        - 测试文件放在 /tests 目录
        
        ### 3. 代码实现
        - 实现满足测试的代码
        - 代码应简洁、可读，符合PEP 8
        - 严格遵守安全约束
        
        ### 4. 验证与输出
        - 运行测试确保通过
        - 按指定格式输出结果
        """
        
        output_format = """
        ## 输出格式规范
        
        ### 必须使用JSON格式：
        {
          "test_files": [
            {"path": "tests/test_xxx.py", "content": "..."}
          ],
          "src_files": [
            {"path": "src/xxx.py", "content": "..."}
          ]
        }
        
        ### 注意事项：
        - 禁止写任何解释性文字
        - 代码必须尽可能精简
        - 确保安全约束得到满足
        """
        
        # 应用匿名化处理
        role = self._anonymize_text(role)
        task_logic = self._anonymize_text(task_logic)
        output_format = self._anonymize_text(output_format)
        
        return PromptTemplate(
            name="optimized_prompt_v1",
            role=role.strip(),
            task_logic=task_logic.strip(),
            output_format=output_format.strip()
        )
    
    def create_template_v2(self) -> PromptTemplate:
        """
        创建第二版优化提示词模板
        特点：安全优先，结构化输出，性能敏感
        """
        role = """
        ## 角色定义：安全优先的软件工程师
        
        你是一个注重安全性与约束遵守的软件工程师。
        核心原则：
        1. 安全第一 - 所有代码必须通过安全检查
        2. 约束驱动 - 严格遵守所有硬性约束
        3. 性能敏感 - 关注响应时间和资源使用
        """
        
        task_logic = """
        ## 结构化任务拆解
        
        **阶段一：约束验证**
        - 验证所有硬性约束是否明确
        - 检查安全要求是否可执行
        - 确认性能指标可测量
        
        **阶段二：防御性设计**
        - 设计时考虑边界情况
        - 实现输入验证和错误处理
        - 避免硬编码敏感信息
        
        **阶段三：高效实现**
        - 使用高效算法和数据结构
        - 避免不必要的复杂度
        - 确保单轮响应时间不受影响
        
        **阶段四：安全验证**
        - 验证PII已匿名化处理
        - 检查无敏感信息泄露
        - 确认符合安全最佳实践
        """
        
        output_format = """
        ## 输出格式规范（Markdown增强）
        
        ```json
        {
          "test_files": [
            {
              "path": "string",  // 测试文件路径
              "content": "string" // 测试代码内容
            }
          ],
          "src_files": [
            {
              "path": "string",  // 源代码文件路径
              "content": "string" // 源代码内容
            }
          ],
          "metadata": {
            "constraints_met": ["constraint1", "constraint2"],
            "security_checks": ["pii_removed", "no_hardcoded_secrets"]
          }
        }
        ```
        
        **关键要求：**
        - 输出必须为纯JSON，无额外文本
        - 代码结构清晰，便于阅读
        - 关键指令使用##或**标记突出
        """
        
        # 应用匿名化处理
        role = self._anonymize_text(role)
        task_logic = self._anonymize_text(task_logic)
        output_format = self._anonymize_text(output_format)
        
        return PromptTemplate(
            name="optimized_prompt_v2",
            role=role.strip(),
            task_logic=task_logic.strip(),
            output_format=output_format.strip()
        )
    
    def _anonymize_text(self, text: str) -> str:
        """
        匿名化处理文本，移除PII
        
        安全约束：所有用于分析的历史对话数据需进行匿名化处理，
        移除任何可能的个人身份信息(PII)
        """
        # 移除电子邮件
        text = re.sub(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', 
                     '[ANONYMIZED_EMAIL]', text)
        
        # 移除电话号码（中国格式）
        text = re.sub(r'\b1[3-9]\d{9}\b', '[ANONYMIZED_PHONE]', text)
        
        # 移除身份证号
        text = re.sub(r'\b[1-9]\d{5}(18|19|20)\d{2}(0[1-9]|1[0-2])(0[1-9]|[12]\d|3[01])\d{3}[0-9Xx]\b',
                     '[ANONYMIZED_ID]', text)
        
        # 移除常见中文姓名（简单模式）
        text = re.sub(r'[张李王刘陈杨赵黄周吴徐孙胡朱高林何郭马罗梁宋郑谢韩唐冯于董萧程曹袁邓许傅沈曾彭吕苏卢蒋蔡贾丁魏薛叶阎余潘杜戴夏钟汪田任姜范方石姚谭廖邹熊金陆郝孔白崔康毛邱秦江史顾侯邵孟龙万段雷钱汤尹黎易常武乔贺赖龚文]\s*[\u4e00-\u9fa5]{1,2}',
                     '[ANONYMIZED_NAME]', text)
        
        return text
    
    def save_template(self, template: PromptTemplate, filepath: str):
        """保存模板到文件"""
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(template.to_dict(), f, ensure_ascii=False, indent=2)
    
    def load_template(self, filepath: str) -> PromptTemplate:
        """从文件加载模板"""
        with open(filepath, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        return PromptTemplate(
            name=data["name"],
            role=data["role"],
            task_logic=data["task_logic"],
            output_format=data["output_format"]
        )

# 安全约束：最终模板不应包含任何硬编码的敏感信息或密钥
# 性能约束：新模板不应显著增加AI助手的单轮响应时间
# 代码红线原则：结构清晰，便于阅读和维护