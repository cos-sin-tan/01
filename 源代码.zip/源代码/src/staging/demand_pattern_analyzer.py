import json
from typing import List, Dict, Any, Optional
from collections import defaultdict
import re

class DemandPatternAnalyzer:
    """需求模式分析器"""
    
    def __init__(self):
        self.security_keywords = ['安全', '漏洞', '认证', '授权', '加密', '防护', 'sanitize', 'validate', 'sanitization', 'injection', 'xss', 'csrf', 'sqli']
        self.privacy_keywords = ['隐私', 'PII', 'GDPR', '匿名化', '脱敏', 'anonymize', 'mask', 'privacy', 'personal data', 'confidential']
        self.performance_keywords = ['性能', '优化', '效率', '响应时间', 'performance', 'optimize', 'latency', 'throughput', 'scalability']
        
    def analyze(self, data: List[Dict[str, Any]]) -> Dict[str, Any]:
        """分析需求数据，提取模式"""
        
        # 输入验证
        self._validate_input(data)
        
        if not data:
            return {
                "patterns": [],
                "semantic_groups": {},
                "security_patterns": []
            }
        
        # 提取模式
        patterns = self._extract_patterns(data)
        
        # 语义分析
        semantic_groups = self._group_by_semantics(data)
        
        # 安全分析
        security_patterns = self._analyze_security_patterns(data)
        
        return {
            "patterns": patterns,
            "semantic_groups": semantic_groups,
            "security_patterns": security_patterns
        }
    
    def _validate_input(self, data: Any) -> None:
        """验证输入数据"""
        if data is None:
            raise ValueError("输入数据不能为None")
        
        if not isinstance(data, list):
            raise ValueError("输入数据必须是列表")
        
        for item in data:
            if not isinstance(item, dict):
                raise ValueError("每个数据项必须是字典")
            
            # 检查必需字段
            required_fields = ['task', 'constraints', 'keywords']
            for field in required_fields:
                if field not in item:
                    raise ValueError(f"数据项缺少必需字段: {field}")
                
            # 检查字段类型
            if not isinstance(item['constraints'], list):
                raise ValueError("constraints字段必须是列表")
            if not isinstance(item['keywords'], list):
                raise ValueError("keywords字段必须是列表")
    
    def _extract_patterns(self, data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """从数据中提取模式"""
        patterns = []
        
        # 按约束分组
        constraint_groups = defaultdict(list)
        for item in data:
            for constraint in item['constraints']:
                constraint_groups[constraint].append(item)
        
        # 创建模式
        for constraint, items in constraint_groups.items():
            pattern = {
                "name": f"{constraint}_pattern",
                "frequency": len(items),
                "characteristics": self._extract_characteristics(items),
                "constraint": constraint,
                "example_tasks": [item['task'] for item in items[:3]]  # 最多3个示例
            }
            patterns.append(pattern)
        
        return patterns
    
    def _extract_characteristics(self, items: List[Dict[str, Any]]) -> List[str]:
        """从项目列表中提取特征"""
        characteristics = []
        
        # 收集所有关键词
        all_keywords = []
        for item in items:
            all_keywords.extend(item['keywords'])
        
        # 分析关键词特征
        keyword_counts = defaultdict(int)
        for keyword in all_keywords:
            keyword_counts[keyword] += 1
        
        # 添加高频关键词作为特征
        for keyword, count in keyword_counts.items():
            if count >= 2:  # 至少出现2次
                characteristics.append(f"高频关键词: {keyword} ({count}次)")
        
        # 添加安全特征
        if any(self._contains_security_keywords(item) for item in items):
            characteristics.append("安全相关")
            
        # 添加隐私特征
        if any(self._contains_privacy_keywords(item) for item in items):
            characteristics.append("隐私保护")
            
        # 添加性能特征
        if any(self._contains_performance_keywords(item) for item in items):
            characteristics.append("性能优化")
        
        return characteristics
    
    def _group_by_semantics(self, data: List[Dict[str, Any]]) -> Dict[str, List[str]]:
        """按语义分组"""
        groups = {
            "security": [],
            "performance": [],
            "privacy": [],
            "other": []
        }
        
        for item in data:
            task = item['task']
            
            # 使用更精确的语义检测，避免重复分组
            is_security = self._contains_security_keywords(item)
            is_performance = self._contains_performance_keywords(item)
            is_privacy = self._contains_privacy_keywords(item)
            
            # 修复：优先顺序调整为安全 > 隐私 > 性能 > 其他，避免语义重叠
            if is_security:
                groups["security"].append(task)
            elif is_privacy:
                groups["privacy"].append(task)
            elif is_performance:
                groups["performance"].append(task)
            else:
                groups["other"].append(task)
        
        return groups
    
    def _analyze_security_patterns(self, data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """分析安全模式"""
        security_patterns = []
        
        for item in data:
            if self._contains_security_keywords(item):
                pattern = {
                    "task": item['task'],
                    "risk_level": self._assess_risk_level(item),
                    "recommendations": self._generate_security_recommendations(item),
                    "keywords": item['keywords']
                }
                security_patterns.append(pattern)
        
        return security_patterns
    
    def _contains_security_keywords(self, item: Dict[str, Any]) -> bool:
        """检查是否包含安全关键词"""
        text = ' '.join([item['task']] + item['constraints'] + item['keywords']).lower()
        return self._contains_keywords(text, self.security_keywords)
    
    def _contains_privacy_keywords(self, item: Dict[str, Any]) -> bool:
        """检查是否包含隐私关键词"""
        text = ' '.join([item['task']] + item['constraints'] + item['keywords']).lower()
        return self._contains_keywords(text, self.privacy_keywords)
    
    def _contains_performance_keywords(self, item: Dict[str, Any]) -> bool:
        """检查是否包含性能关键词"""
        text = ' '.join([item['task']] + item['constraints'] + item['keywords']).lower()
        return self._contains_keywords(text, self.performance_keywords)
    
    def _contains_keywords(self, text: str, keywords: List[str]) -> bool:
        """通用的关键词匹配方法，支持中英文混合文本"""
        text_lower = text.lower()
        
        for keyword in keywords:
            keyword_lower = keyword.lower()
            
            # 对于英文单词，使用单词边界匹配
            if keyword_lower.isascii():
                if re.search(rf'\b{re.escape(keyword_lower)}\b', text_lower):
                    return True
            # 对于中文词汇，使用子字符串匹配
            else:
                if keyword_lower in text_lower:
                    return True
        
        return False
    
    def _assess_risk_level(self, item: Dict[str, Any]) -> str:
        """评估风险等级"""
        high_risk_keywords = ['eval', 'exec', '注入', '漏洞', '高危', 'remote code', 'arbitrary code', 'buffer overflow']
        
        text = ' '.join([item['task']] + item['constraints'] + item['keywords']).lower()
        
        # 使用改进的关键词匹配方法
        for keyword in high_risk_keywords:
            if self._contains_keywords(text, [keyword]):
                return "high"
        
        if self._contains_security_keywords(item):
            return "medium"
        else:
            return "low"
    
    def _generate_security_recommendations(self, item: Dict[str, Any]) -> List[str]:
        """生成安全建议"""
        recommendations = []
        
        text = ' '.join([item['task']] + item['constraints'] + item['keywords']).lower()
        
        # 使用改进的关键词匹配方法
        if self._contains_keywords(text, ['eval', 'exec', 'dynamic code', 'remote code']):
            recommendations.append("避免使用动态代码执行，或进行严格的输入验证和沙箱隔离")
            
        if self._contains_keywords(text, ['injection', 'sql', 'nosql', 'xss', 'csrf']):
            recommendations.append("使用参数化查询、输出编码和CSRF令牌防止注入攻击")
            
        if self._contains_privacy_keywords(item):
            recommendations.append("实施数据脱敏、访问控制和加密存储")
            
        if not recommendations:
            recommendations.append("实施标准安全实践：输入验证、输出编码、访问控制、日志记录")
            
        return recommendations
    
    def to_json(self) -> str:
        """转换为JSON字符串"""
        return json.dumps(self.__dict__, ensure_ascii=False, indent=2)