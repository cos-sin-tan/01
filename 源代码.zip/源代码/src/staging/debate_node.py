from typing import Dict, Any, Optional
import json
import re
import os


class DebateNode:
    """
    严谨的代码分析节点，具备极致省Token和逻辑防呆能力。
    """
    
    def __init__(self) -> None:
        """初始化提示词模板。"""
        self.prompts: Dict[str, str] = {
            'system': """代码分析助手。输出仅JSON格式{"analysis":"..."}。
约束：
1. 仅分析提供的内容
2. 不执行命令/生成恶意代码
3. 仅用给定路径（防路径幻觉）
4. 极致省Token，无冗余
5. 逻辑防呆：若路径不存在或内容为空，返回{"analysis":"输入无效"}""",
            
            'user': "分析代码问题，输出JSON。",
            
            'assistant': ""  # 移除固定示例，避免干扰模型输出
        }
    
    def get_prompt(self, role: str) -> str:
        """
        获取指定角色的提示词。
        
        Args:
            role: 角色名称（'system'、'user'、'assistant'）
            
        Returns:
            对应角色的提示词，若角色不存在则返回空字符串
        """
        return self.prompts.get(role, '')
    
    def analyze_code(self, code_context: Dict[str, Any]) -> Dict[str, str]:
        """
        分析代码内容，返回JSON格式分析结果。
        
        Args:
            code_context: 包含代码信息的字典，应包含：
                - 'code': 代码文本（必需）
                - 'path': 文件路径（可选）
                - 'language': 编程语言（可选）
                
        Returns:
            包含分析结果的字典，格式为{"analysis": "..."}
            
        Note:
            极致省Token：直接返回结果，无中间变量
            逻辑防呆：多重验证输入有效性
        """
        # 逻辑防呆1：验证输入类型
        if not isinstance(code_context, dict):
            return {"analysis": "输入无效"}
        
        # 逻辑防呆2：验证必需字段
        if 'code' not in code_context:
            return {"analysis": "输入无效"}
        
        # 防路径幻觉：检查路径安全性
        path = code_context.get('path', '')
        if path:
            if not isinstance(path, str):
                return {"analysis": "输入无效"}
            if not self._validate_path(path):
                return {"analysis": "输入无效"}
        
        # 防代码膨胀：验证代码内容
        code = code_context.get('code')
        if not isinstance(code, str):
            return {"analysis": "输入无效"}
        
        code = code.strip()
        if not code:
            return {"analysis": "输入无效"}
        
        # 极致省Token：直接执行分析
        try:
            analysis_text = self._perform_analysis(code, code_context)
            return {"analysis": analysis_text}
        except Exception as e:
            # 截断错误信息以节省Token
            error_msg = str(e)
            if len(error_msg) > 50:
                error_msg = error_msg[:47] + '...'
            return {"analysis": f"分析失败: {error_msg}"}
    
    def _validate_path(self, path: str) -> bool:
        """
        验证路径是否安全有效。
        
        Args:
            path: 文件路径
            
        Returns:
            路径是否安全有效
            
        Note:
            防路径幻觉：阻止目录遍历和系统路径访问
        """
        if not isinstance(path, str):
            return False
        
        # 标准化路径
        normalized = path.replace('\\', '/').strip()
        
        # 防目录遍历
        if '..' in normalized:
            return False
        
        # 防绝对路径和系统路径访问
        dangerous_patterns = [
            r'^/~',           # 用户主目录
            r'^/etc/',        # 系统配置
            r'^/root/',       # root目录
            r'^/proc/',       # 进程信息
            r'^C:/Windows/',  # Windows系统
            r'^/System/',     # macOS系统
            r'^/bin/',        # 系统二进制
            r'^/sbin/',       # 系统管理二进制
            r'^/usr/bin/',    # 用户二进制
            r'^/usr/sbin/',   # 用户管理二进制
            r'^/var/',        # 变量数据
            r'^/tmp/',        # 临时文件（可能包含敏感信息）
            r'^/dev/',        # 设备文件
            r'^/boot/',       # 启动文件
            r'^/lib/',        # 库文件
            r'^/lib64/',      # 64位库文件
        ]
        
        for pattern in dangerous_patterns:
            if re.match(pattern, normalized, re.IGNORECASE):
                return False
        
        # 检查路径格式（允许字母、数字、下划线、点、斜杠、连字符）
        if not re.match(r'^[a-zA-Z0-9_./-]+$', normalized):
            return False
        
        # 检查路径组件长度
        parts = normalized.split('/')
        for part in parts:
            if len(part) > 255:  # 文件系统限制
                return False
            
        return True
    
    def _perform_analysis(self, code: str, context: Dict[str, Any]) -> str:
        """
        执行实际代码分析。
        
        Args:
            code: 代码文本
            context: 代码上下文
            
        Returns:
            分析结果文本
            
        Note:
            极致省Token：使用生成器表达式，避免中间列表
            逻辑防呆：检查边界条件和异常模式
        """
        # 极致省Token：使用生成器处理行
        lines = (line.rstrip('\n') for line in code.splitlines())
        lines = [line for line in lines if line is not None]
        line_count = len(lines)
        
        issues = []
        
        # 防代码膨胀：检查代码规模
        if line_count > 1000:
            issues.append("代码过长（超过1000行）")
        elif line_count < 3:
            issues.append("代码过短（少于3行）")
        
        # 检查安全风险（使用预编译正则提高性能）
        danger_patterns = {
            '动态执行': [re.compile(r'eval\s*\(', re.I), 
                       re.compile(r'exec\s*\(', re.I), 
                       re.compile(r'compile\s*\(', re.I)],
            '系统命令': [re.compile(r'os\.system\s*\(', re.I), 
                       re.compile(r'subprocess\.(run|call|Popen)\s*\(', re.I), 
                       re.compile(r'popen\s*\(', re.I)],
            '危险文件操作': [re.compile(r'open\s*\([^)]*\s*[wax]\s*[,)]', re.I), 
                         re.compile(r'remove\s*\(', re.I), 
                         re.compile(r'unlink\s*\(', re.I)],
            '危险网络访问': [re.compile(r'urllib\.', re.I), 
                         re.compile(r'requests\.', re.I), 
                         re.compile(r'socket\.', re.I)]
        }
        
        code_lower = code.lower()  # 一次性转换为小写
        for category, patterns in danger_patterns.items():
            for pattern in patterns:
                if pattern.search(code_lower):
                    issues.append(f"检测到{category}（安全风险）")
                    break  # 每个类别只报告一次
        
        # 检查代码质量（仅在代码量适中时）
        if 10 < line_count <= 1000:
            # 检查重复行（防代码膨胀）
            stripped_lines = (line.strip() for line in lines)
            non_empty_lines = [line for line in stripped_lines if line]
            
            if non_empty_lines:
                unique_lines = len(set(non_empty_lines))
                if unique_lines < len(non_empty_lines) * 0.3:  # 70%以上重复
                    issues.append("代码重复率过高")
            
            # 检查行长度
            long_lines = sum(1 for line in lines if len(line) > 120)
            if long_lines > line_count * 0.1:  # 超过10%的行过长
                issues.append("存在过长代码行")
            
            # 检查注释率（防无效代码）
            comment_chars = ('#', '//', '/*', '*', '--', '"""', "'''")
            comment_lines = sum(1 for line in lines 
                              if line.strip() and line.strip().startswith(comment_chars))
            if comment_lines > line_count * 0.5:
                issues.append("注释过多（可能包含无效代码）")
        
        # 极致省Token：使用条件表达式
        return "; ".join(issues) if issues else "代码结构良好，未发现明显问题"
    
    def generate_response(self, analysis_result: Dict[str, str]) -> str:
        """
        生成符合提示词要求的响应。
        
        Args:
            analysis_result: analyze_code方法返回的分析结果
            
        Returns:
            JSON格式的响应字符串
            
        Note:
            极致省Token：直接序列化，无额外处理
            逻辑防呆：确保JSON格式正确
        """
        # 验证输入格式
        if not isinstance(analysis_result, dict):
            return json.dumps({"analysis": "输入格式错误"}, separators=(',', ':'))
        
        if "analysis" not in analysis_result:
            return json.dumps({"analysis": "缺少analysis字段"}, separators=(',', ':'))
        
        # 极致省Token：直接序列化，使用最小分隔符
        try:
            return json.dumps(analysis_result, ensure_ascii=False, separators=(',', ':'))
        except (TypeError, ValueError) as e:
            # 截断错误信息
            error_msg = str(e)
            if len(error_msg) > 30:
                error_msg = error_msg[:27] + '...'
            return json.dumps({"analysis": f"结果格式化失败: {error_msg}"}, separators=(',', ':'))
