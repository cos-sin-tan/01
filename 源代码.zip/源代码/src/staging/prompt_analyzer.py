"""
提示词模板缺陷分析器
分析系统规范生成提示词在清晰度、完整性和结构化方面的缺陷
"""

import re
from typing import List, Dict, Any


class PromptAnalyzer:
    """分析提示词模板缺陷的主类"""
    
    def __init__(self):
        self.defect_patterns = [
            {
                "category": "clarity",
                "patterns": [
                    r"\b(?:好|不错|合适)\b",
                    r"\b(?:确保|保证)\b",
                    r"\b(?:相关|有关)\b"
                ],
                "description": "模糊表述缺乏具体标准"
            },
            {
                "category": "structure",
                "patterns": [
                    r"^[^\n]{100,}",  # 超长单行
                    r"(?:功能|安全|性能).*(?:功能|安全|性能)",  # 混合描述
                ],
                "description": "缺乏明确的结构化分段"
            },
            {
                "category": "completeness",
                "patterns": [
                    r"(?i)(?:功能|需求)(?!.*(?:约束|要求|验收))",
                    r"(?i)(?:安全)(?!.*(?:机制|控制|防护))"
                ],
                "description": "关键要素描述不完整"
            },
            {
                "category": "redundancy",
                "patterns": [
                    r"(.{10,}?)\1+",  # 重复内容
                    r"\b(?:系统|需要|要求)\b.*\b(?:系统|需要|要求)\b"
                ],
                "description": "存在不必要的重复描述"
            },
            {
                "category": "ambiguity",
                "patterns": [
                    r"\b(?:可能|或许|大概)\b",
                    r"\b(?:一些|某些|部分)\b",
                    r"\b(?:尽快|及时)\b"
                ],
                "description": "歧义表述导致理解偏差"
            }
        ]
    
    def analyze_prompt_defects(self, prompt_text: str) -> List[Dict[str, str]]:
        """
        分析提示词模板缺陷
        
        Args:
            prompt_text: 待分析的提示词文本
            
        Returns:
            缺陷分析列表，每个元素包含problem和example字段
        """
        if not prompt_text or not prompt_text.strip():
            return self._generate_default_defects()
        
        defects = []
        lines = prompt_text.strip().split('\n')
        
        for pattern_info in self.defect_patterns[:5]:  # 限制检查数量
            for pattern in pattern_info["patterns"]:
                matches = re.finditer(pattern, prompt_text, re.IGNORECASE)
                for match in matches:
                    if self._is_valid_match(match, prompt_text):
                        defect = self._create_defect_entry(
                            pattern_info["category"],
                            pattern_info["description"],
                            match.group(),
                            prompt_text
                        )
                        if defect and defect not in defects:
                            defects.append(defect)
                        if len(defects) >= 5:  # 限制返回数量
                            break
                if len(defects) >= 5:
                    break
            if len(defects) >= 5:
                break
        
        # 确保至少返回3个缺陷分析
        while len(defects) < 3:
            defects.extend(self._generate_default_defects()[:3 - len(defects)])
        
        return defects[:5]  # 返回最多5个缺陷
    
    def _is_valid_match(self, match: re.Match, text: str) -> bool:
        """验证匹配是否有效，避免匹配到示例中的敏感信息"""
        matched_text = match.group().lower()
        
        # 安全过滤：避免匹配敏感词汇
        sensitive_terms = ["eval", "exec", "password", "token", "key"]
        for term in sensitive_terms:
            if term in matched_text:
                return False
        
        # 避免匹配过短的通用词汇
        if len(matched_text.strip()) < 2:
            return False
            
        return True
    
    def _create_defect_entry(self, category: str, description: str, 
                            matched_text: str, full_text: str) -> Dict[str, str]:
        """创建缺陷分析条目"""
        # 清理匹配文本，移除可能敏感的内容
        safe_example = self._sanitize_example(matched_text)
        
        # 根据缺陷类别生成具体问题描述
        problem_descriptions = {
            "clarity": "表述模糊缺乏具体标准",
            "structure": "内容组织缺乏清晰结构",
            "completeness": "关键要素描述不完整",
            "redundancy": "存在不必要的重复描述",
            "ambiguity": "歧义表述导致理解偏差"
        }
        
        problem = problem_descriptions.get(category, "模板设计存在缺陷")
        
        return {
            "problem": problem,
            "example": safe_example
        }
    
    def _sanitize_example(self, example_text: str) -> str:
        """清理示例文本，确保安全"""
        # 移除可能包含敏感信息的模式
        sanitized = example_text.strip()
        
        # 替换可能的安全敏感词汇
        replacements = {
            r"\beval\b": "执行函数",
            r"\bexec\b": "执行命令",
            r"\bpassword\b": "认证信息",
            r"\d{6,}": "***"  # 隐藏长数字
        }
        
        for pattern, replacement in replacements.items():
            sanitized = re.sub(pattern, replacement, sanitized, flags=re.IGNORECASE)
        
        # 截断过长的示例
        if len(sanitized) > 50:
            sanitized = sanitized[:47] + "..."
            
        return sanitized
    
    def _generate_default_defects(self) -> List[Dict[str, str]]:
        """生成默认缺陷分析（当输入为空或无效时）"""
        return [
            {
                "problem": "缺乏明确的功能需求描述",
                "example": "示例：'实现必要功能'"
            },
            {
                "problem": "安全约束定义不清晰",
                "example": "示例：'注意系统安全'"
            },
            {
                "problem": "性能要求表述模糊",
                "example": "示例：'响应要快'"
            },
            {
                "problem": "验收标准不够具体",
                "example": "示例：'完成开发任务'"
            },
            {
                "problem": "缺乏结构化组织",
                "example": "示例：'功能安全性能一起描述'"
            }
        ]
