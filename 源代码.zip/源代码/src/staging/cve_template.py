import json
import re
from typing import Dict, List, Any, Optional
from datetime import datetime


class CVETemplateError(Exception):
    pass


class CVETemplate:
    def __init__(self):
        self.template = {
            "cve_id": "",
            "description": "",
            "cvss_score": 0.0,
            "cvss_vector": "",
            "affected_products": [],
            "vulnerability_type": "",
            "severity": "",
            "references": [],
            "published_date": "",
            "last_modified_date": "",
            "analysis_summary": "",
            "mitigation_recommendations": [],
            "exploitation_likelihood": "",
            "impact_assessment": ""
        }
        
        self.required_fields = [
            "cve_id", "description", "cvss_score", "cvss_vector",
            "affected_products", "vulnerability_type", "severity",
            "references", "published_date", "last_modified_date"
        ]
        
        self.allowed_vulnerability_types = [
            "buffer_overflow", "sql_injection", "xss", "csrf",
            "privilege_escalation", "information_disclosure",
            "denial_of_service", "code_execution", "other"
        ]
        
        self.allowed_severities = ["LOW", "MEDIUM", "HIGH", "CRITICAL"]
    
    def _sanitize_input(self, value: Any) -> Any:
        if isinstance(value, str):
            value = re.sub(r'<[^>]*>', '', value)
            value = re.sub(r'javascript:', '', value, flags=re.IGNORECASE)
            value = re.sub(r'data:', '', value, flags=re.IGNORECASE)
            value = value.strip()
        elif isinstance(value, list):
            return [self._sanitize_input(item) for item in value]
        return value
    
    def _validate_input(self, data: Dict[str, Any]) -> None:
        for field in self.required_fields:
            if field not in data:
                raise CVETemplateError(f"Missing required field: {field}")
        
        if not isinstance(data["cve_id"], str) or not data["cve_id"].startswith("CVE-"):
            raise CVETemplateError("Invalid CVE ID format")
        
        cvss_score = data["cvss_score"]
        if not isinstance(cvss_score, (int, float)) or not (0.0 <= cvss_score <= 10.0):
            raise CVETemplateError("CVSS score must be between 0.0 and 10.0")
        
        if data["vulnerability_type"] not in self.allowed_vulnerability_types:
            raise CVETemplateError(f"Invalid vulnerability type. Allowed: {self.allowed_vulnerability_types}")
        
        if data["severity"] not in self.allowed_severities:
            raise CVETemplateError(f"Invalid severity. Allowed: {self.allowed_severities}")
        
        if not isinstance(data["affected_products"], list):
            raise CVETemplateError("affected_products must be a list")
        
        if not isinstance(data["references"], list):
            raise CVETemplateError("references must be a list")
        
        try:
            datetime.strptime(data["published_date"], "%Y-%m-%d")
            datetime.strptime(data["last_modified_date"], "%Y-%m-%d")
        except ValueError:
            raise CVETemplateError("Dates must be in YYYY-MM-DD format")
    
    def _calculate_additional_fields(self, data: Dict[str, Any]) -> Dict[str, Any]:
        result = data.copy()
        
        cvss_score = data["cvss_score"]
        vuln_type = data["vulnerability_type"]
        
        if cvss_score >= 9.0:
            exploitation_likelihood = "HIGH"
        elif cvss_score >= 7.0:
            exploitation_likelihood = "MEDIUM_HIGH"
        elif cvss_score >= 4.0:
            exploitation_likelihood = "MEDIUM"
        else:
            exploitation_likelihood = "LOW"
        
        result["exploitation_likelihood"] = exploitation_likelihood
        
        impact_map = {
            "buffer_overflow": "Potential remote code execution",
            "sql_injection": "Data breach and unauthorized access",
            "xss": "Session hijacking and client-side attacks",
            "csrf": "Unauthorized state-changing operations",
            "privilege_escalation": "Unauthorized privilege elevation",
            "information_disclosure": "Sensitive data exposure",
            "denial_of_service": "Service disruption and downtime",
            "code_execution": "Complete system compromise",
            "other": "Varies based on specific vulnerability"
        }
        
        result["impact_assessment"] = impact_map.get(vuln_type, "To be assessed")
        
        mitigation_map = {
            "buffer_overflow": ["Implement bounds checking", "Use safe string functions"],
            "sql_injection": ["Use parameterized queries", "Implement input validation"],
            "xss": ["Implement output encoding", "Use Content Security Policy"],
            "csrf": ["Implement CSRF tokens", "Use SameSite cookies"],
            "privilege_escalation": ["Implement proper access controls", "Regular privilege audits"],
            "information_disclosure": ["Encrypt sensitive data", "Implement proper error handling"],
            "denial_of_service": ["Implement rate limiting", "Use load balancing"],
            "code_execution": ["Sandbox untrusted code", "Implement strict input validation"],
            "other": ["Apply security patches", "Follow secure coding practices"]
        }
        
        result["mitigation_recommendations"] = mitigation_map.get(vuln_type, ["Apply security updates", "Consult vendor advisories"])
        
        summary = f"{data['cve_id']} is a {data['severity'].lower()} severity {vuln_type.replace('_', ' ')} vulnerability "
        summary += f"with CVSS score {cvss_score}. Affects {len(data['affected_products'])} product(s)."
        result["analysis_summary"] = summary
        
        return result
    
    def generate(self, data: Dict[str, Any]) -> str:
        try:
            sanitized_data = {k: self._sanitize_input(v) for k, v in data.items()}
            
            self._validate_input(sanitized_data)
            
            complete_data = self._calculate_additional_fields(sanitized_data)
            
            result = self.template.copy()
            result.update(complete_data)
            
            return json.dumps(result, indent=2, ensure_ascii=False)
        
        except (ValueError, TypeError, KeyError) as e:
            raise CVETemplateError(f"Template generation failed: {str(e)}")


def create_cve_template() -> CVETemplate:
    return CVETemplate()