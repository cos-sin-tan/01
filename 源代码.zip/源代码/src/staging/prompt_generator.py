"""
提示词模板生成器
用于生成优化后的提示词模板，确保结构清晰、指令明确
"""

import json
from typing import List, Dict, Any
import re


class PromptGenerator:
    """提示词生成器类"""
    
    def __init__(self):
        self.dangerous_patterns = [
            r'eval\s*\(',
            r'exec\s*\(',
            r'__import__\s*\(',
            r'os\.system\s*\(',
            r'subprocess\.run\s*\(',
            r'rm\s+-rf',
            r'delete\s+from',
            r'drop\s+table'
        ]
    
    def generate_prompt(self, 
                       role: str, 
                       requirements: List[str], 
                       constraints: List[Dict[str, Any]],
                       error_lessons: List[str] = None) -> str:
        """
        生成优化后的提示词模板
        
        Args:
            role: 角色定义
            requirements: 需求列表
            constraints: 约束条件列表
            error_lessons: 历史错误教训列表
            
        Returns:
            格式化后的提示词模板
        """
        if not requirements:
            raise ValueError("需求列表不能为空")
        
        if not all(isinstance(req, str) for req in requirements):
            raise ValueError("需求必须是字符串类型")
        
        self._validate_constraints(constraints)
        
        sanitized_role = self._sanitize_content(role)
        sanitized_reqs = [self._sanitize_content(req) for req in requirements]
        
        prompt_parts = []
        
        prompt_parts.append(f"# 角色定义\n**角色**: {sanitized_role}\n")
        
        prompt_parts.append("# 核心职责\n")
        for i, req in enumerate(sanitized_reqs, 1):
            prompt_parts.append(f"{i}. {req}")
        prompt_parts.append("")
        
        if constraints:
            prompt_parts.append("# 硬性约束\n")
            prompt_parts.append(self._format_constraints(constraints))
            prompt_parts.append("")
        
        if error_lessons:
            prompt_parts.append("# 历史错误教训（请避免重复）\n")
            for lesson in error_lessons:
                sanitized_lesson = self._sanitize_content(lesson)
                prompt_parts.append(f"- {sanitized_lesson}")
            prompt_parts.append("")
        
        prompt_parts.append("# 输出格式\n")
        prompt_parts.append("1. 首先确认理解所有需求和约束")
        prompt_parts.append("2. 按TDD原则编写代码（先测试后实现）")
        prompt_parts.append("3. 代码必须简洁、可读、符合规范")
        prompt_parts.append("4. 严格遵守所有安全约束")
        prompt_parts.append("5. 输出只包含要求的JSON格式")
        prompt_parts.append("")
        
        prompt_parts.append("# 错误处理\n")
        prompt_parts.append("1. 遇到模糊需求时主动澄清")
        prompt_parts.append("2. 发现约束冲突时报告并建议解决方案")
        prompt_parts.append("3. 确保输出符合所有验收标准")
        prompt_parts.append("4. 如无法满足约束，说明原因并提出替代方案")
        
        prompt = "\n".join(prompt_parts)
        
        if len(prompt) > 4000:
            prompt = self._truncate_prompt(prompt)
        
        return prompt
    
    def _validate_constraints(self, constraints: List[Dict[str, Any]]) -> None:
        """验证约束条件格式"""
        if not constraints:
            return
            
        required_keys = {"type", "rule", "severity"}
        for constraint in constraints:
            if not isinstance(constraint, dict):
                raise ValueError("约束必须是字典类型")
            
            missing_keys = required_keys - set(constraint.keys())
            if missing_keys:
                raise ValueError(f"约束缺少必要字段: {missing_keys}")
            
            severity = constraint.get("severity", "").lower()
            if severity not in ["high", "medium", "low"]:
                raise ValueError(f"无效的严重级别: {severity}")
    
    def _format_constraints(self, constraints: List[Dict[str, Any]]) -> str:
        """格式化约束条件"""
        lines = []
        
        severity_order = {"high": 1, "medium": 2, "low": 3}
        sorted_constraints = sorted(
            constraints, 
            key=lambda x: severity_order.get(x["severity"].lower(), 4)
        )
        
        for constraint in sorted_constraints:
            constraint_type = constraint["type"]
            rule = self._sanitize_content(constraint["rule"])
            severity = constraint["severity"].upper()
            
            lines.append(f"**{constraint_type}约束** ({severity}): {rule}")
        
        return "\n".join(lines)
    
    def _sanitize_content(self, content: str) -> str:
        """安全过滤内容"""
        if not content:
            return ""
            
        sanitized = content
        for pattern in self.dangerous_patterns:
            if re.search(pattern, content, re.IGNORECASE):
                sanitized = re.sub(pattern, "[已过滤危险指令]", sanitized, flags=re.IGNORECASE)
        
        return sanitized
    
    def _truncate_prompt(self, prompt: str, max_length: int = 4000) -> str:
        """截断提示词以控制长度"""
        if len(prompt) <= max_length:
            return prompt
            
        parts = prompt.split("\n")
        truncated = []
        current_length = 0
        
        for part in parts:
            if current_length + len(part) + 1 <= max_length - 100:
                truncated.append(part)
                current_length += len(part) + 1
            else:
                truncated.append("...（内容已截断以确保合理长度）")
                break
        
        return "\n".join(truncated)
    
    def save_to_file(self, prompt: str, filepath: str) -> None:
        """保存提示词到文件"""
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(prompt)


def create_optimized_template() -> str:
    """创建优化后的提示词模板"""
    generator = PromptGenerator()
    
    requirements = [
        "基于需求分析，设计和编码实现指定功能",
        "遵循TDD原则，先编写测试用例再实现代码",
        "确保代码符合编码规范和安全要求",
        "处理复杂需求拆解与规范生成"
    ]
    
    constraints = [
        {
            "type": "coding_standards",
            "rule": "模板文本结构清晰，使用Markdown或类似格式增强可读性",
            "severity": "medium"
        },
        {
            "type": "security_requirements",
            "rule": "优化后的提示词模板不得包含可能导致系统执行危险指令或泄露内部机制的内容",
            "severity": "medium"
        },
        {
            "type": "performance_requirements",
            "rule": "优化后的模板应能在合理的token长度内，保证任务处理的核心逻辑完备",
            "severity": "medium"
        }
    ]
    
    error_lessons = [
        "Coder节点：未找到系统规范或蓝图",
        "Coder节点：没有找到coding需求",
        "加强前置验证，优化约束条件"
    ]
    
    return generator.generate_prompt(
        role="资深软件工程师",
        requirements=requirements,
        constraints=constraints,
        error_lessons=error_lessons
    )


if __name__ == "__main__":
    template = create_optimized_template()
    print(template)
    
    generator = PromptGenerator()
    generator.save_to_file(template, "optimized_prompt_v1.txt")
    print("模板已保存到 optimized_prompt_v1.txt")
