#!/usr/bin/env python3
"""
辩论节点的单元测试。
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from debate_node import DebateNode, debate_node

def test_debate_node_initialization():
    """测试 DebateNode 初始化"""
    dn = DebateNode(max_rounds=5)
    assert dn.max_rounds == 5
    print("[PASS] DebateNode 初始化")

def test_debate_node_run_debate_success():
    """测试辩论成功场景（模拟第二轮通过）"""
    dn = DebateNode(max_rounds=3)
    initial_state = {
        "error_message": "审计失败",
        "diagnostic_vector": {"verdict": "fail"}
    }
    result = dn.run_debate(initial_state)
    # 应包含 debate_log 字段
    assert "debate_log" in result
    # 应包含 debate_result 字段
    assert "debate_result" in result
    # 由于模拟逻辑，第二轮应通过，debate_result 应为 "success"
    # 但我们的模拟逻辑是第二轮通过，实际上会成功
    # 我们只检查结构
    print("[PASS] run_debate 返回正确结构")

def test_debate_node_langgraph():
    """测试 LangGraph 节点函数"""
    state = {
        "error_message": "测试错误",
        "current_node": "auditor"
    }
    new_state = debate_node(state)
    assert "current_node" in new_state
    assert new_state["current_node"] == "debate"
    print("[PASS] debate_node 更新状态")

if __name__ == "__main__":
    test_debate_node_initialization()
    test_debate_node_run_debate_success()
    test_debate_node_langgraph()
    print("所有辩论节点测试通过")