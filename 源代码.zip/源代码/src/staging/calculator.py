import ast
import operator
import sys
from typing import Union


def safe_eval_calculator(expression: str) -> Union[int, float, complex]:
    """
    Safely evaluate a mathematical expression string using eval() with restricted namespace.
    Only allows basic arithmetic operators and numbers.
    
    Args:
        expression: Mathematical expression as a string
        
    Returns:
        The result of the evaluation as int, float, or complex
        
    Raises:
        ValueError: For invalid input or characters
        SyntaxError: For syntax errors in the expression
        ZeroDivisionError: For division by zero
        TypeError, OverflowError, etc.: For native exceptions from operators
    """
    # Handle None and empty input robustly
    if expression is None:
        raise ValueError("Expression cannot be None")
    
    if not isinstance(expression, str):
        raise ValueError("Expression must be a string")
    
    if expression.strip() == "":
        raise ValueError("Expression cannot be empty")
    
    # Character-level whitelist for additional security
    # Allow whitespace characters (space, newline, tab) for better expression formatting
    # Allow 'e' and 'E' for scientific notation, 'j' and 'J' for complex literals
    allowed_chars = set("0123456789+-*/.%()EejJ \n\t")
    if not all(c in allowed_chars for c in expression):
        raise ValueError("Invalid characters in expression")
    
    # Define allowed AST node types for validation
    allowed_nodes = {
        ast.Expression,
        ast.BinOp,
        ast.UnaryOp,
    }
    
    # Add version-specific constant node types
    if sys.version_info >= (3, 8):
        allowed_nodes.add(ast.Constant)
    else:
        allowed_nodes.add(ast.Num)
    
    # Parse the expression to validate syntax
    try:
        tree = ast.parse(expression, mode='eval')
    except SyntaxError as e:
        raise SyntaxError(e.msg) from e
    
    # Validate AST nodes
    for node in ast.walk(tree):
        node_type = type(node)
        
        # Check if node type is allowed
        if node_type not in allowed_nodes:
            raise ValueError("Invalid AST node type")
        
        # Check constant nodes for numeric values only
        if sys.version_info >= (3, 8):
            if isinstance(node, ast.Constant):
                value = node.value
                # isinstance(value, bool) must be checked first since bool is subclass of int
                if isinstance(value, bool) or value is None:
                    raise ValueError("Only numbers are allowed")
                if not isinstance(value, (int, float, complex)):
                    raise ValueError("Only numbers are allowed")
        else:
            if isinstance(node, ast.Num):
                value = node.n
                if not isinstance(value, (int, float, complex)):
                    raise ValueError("Only numbers are allowed")
        
        # Additional check for BinOp operator
        if isinstance(node, ast.BinOp):
            allowed_op_types = {ast.Add, ast.Sub, ast.Mult, ast.Div, ast.Pow, ast.Mod, ast.FloorDiv}
            if type(node.op) not in allowed_op_types:
                raise ValueError("Unsupported operator")
        
        # Additional check for UnaryOp operator
        if isinstance(node, ast.UnaryOp):
            allowed_unary_op_types = {ast.USub, ast.UAdd}
            if type(node.op) not in allowed_unary_op_types:
                raise ValueError("Unsupported unary operator")
    
    # Create a minimal safe namespace with only mathematical operations
    # IMPORTANT: We are NOT including any built-in functions to prevent security issues
    safe_namespace = {
        '__builtins__': {},
    }
    
    # Use eval() with restricted namespace
    try:
        result = eval(expression, {"__builtins__": {}}, safe_namespace)
    except ZeroDivisionError:
        raise
    except SyntaxError:
        raise
    except Exception as e:
        # Re-raise with proper exception type
        if isinstance(e, (ValueError, TypeError, OverflowError, ArithmeticError)):
            raise
        raise ValueError(f"Evaluation failed: {str(e)}")
    
    # Additional validation for the result
    if not isinstance(result, (int, float, complex)):
        raise ValueError("Only numbers are allowed")
    
    return result


# Alternative implementation using ast.literal_eval for simple cases
# and eval() with restricted namespace for expressions with operators
def safe_eval_calculator_alternative(expression: str) -> Union[int, float, complex]:
    """
    Alternative implementation that uses ast.literal_eval for simple literals
    and safe_eval_calculator for expressions with operators.
    """
    # Input validation (same as above)
    if expression is None:
        raise ValueError("Expression cannot be None")
    
    if not isinstance(expression, str):
        raise ValueError("Expression must be a string")
    
    if expression.strip() == "":
        raise ValueError("Expression cannot be empty")
    
    # Character-level whitelist check
    allowed_chars = set("0123456789+-*/.%()EejJ \n\t")
    if not all(c in allowed_chars for c in expression):
        raise ValueError("Invalid characters in expression")
    
    # Try ast.literal_eval first for simple literals
    try:
        result = ast.literal_eval(expression)
        if isinstance(result, (int, float, complex)):
            return result
        else:
            raise ValueError("Only numbers are allowed")
    except (SyntaxError, ValueError):
        # Not a simple literal, continue with expression parsing
        pass
    
    # For expressions with operators, use the safe_eval_calculator
    return safe_eval_calculator(expression)
