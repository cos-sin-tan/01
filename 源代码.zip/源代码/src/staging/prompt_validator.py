import asyncio
import json
import re
import time
from dataclasses import dataclass
from typing import List, Dict, Any, Optional, Tuple
from abc import ABC, abstractmethod


class SecurityError(Exception):
    """安全异常"""
    pass


@dataclass
class Template:
    """提示词模板"""
    name: str
    content: str
    
    def __post_init__(self) -> None:
        """初始化后验证"""
        self._validate_security()
    
    def _validate_security(self) -> None:
        """验证模板安全性"""
        dangerous_patterns = [
            r'__import__\s*\(',
            r'eval\s*\(',
            r'exec\s*\(',
            r'compile\s*\(',
            r'open\s*\(',
            r'os\.system',
            r'subprocess\.'
        ]
        
        for pattern in dangerous_patterns:
            if re.search(pattern, self.content):
                raise SecurityError(f"模板包含危险内容: {pattern}")
    
    def format(self, input_data: str) -> str:
        """格式化模板"""
        return self.content.replace("{input}", input_data)


@dataclass
class TestCase:
    """测试用例"""
    id: str
    input_data: str
    expected_output: str
    
    def __post_init__(self) -> None:
        """初始化后清洗输入"""
        self.input_data = self._sanitize_input(self.input_data)
    
    @staticmethod
    def _sanitize_input(input_str: str) -> str:
        """清洗输入数据"""
        # 移除危险字符和标签
        sanitized = re.sub(r'<[^>]*>', '', input_str)  # 移除HTML标签
        sanitized = re.sub(r'[;|&$`]', '', sanitized)  # 移除命令分隔符
        sanitized = sanitized.strip()
        return sanitized


@dataclass
class ValidationResult:
    """验证结果"""
    template_name: str
    testcase_id: str
    success: bool
    output: str
    execution_time: float


class LLMClient(ABC):
    """LLM客户端接口"""
    
    @abstractmethod
    async def generate(self, prompt: str) -> str:
        """生成响应"""
        pass


class MockLLMClient(LLMClient):
    """模拟LLM客户端"""
    
    async def generate(self, prompt: str) -> str:
        """模拟生成响应"""
        await asyncio.sleep(0.01)  # 模拟网络延迟
        return f"Mock response for: {prompt[:50]}..."


class PromptValidator:
    """提示词验证器"""
    
    def __init__(self, llm_client: Optional[LLMClient] = None):
        """初始化验证器"""
        self.llm_client = llm_client or MockLLMClient()
        
    async def execute_single_test(
        self,
        template: Template,
        testcase: TestCase,
        timeout: float = 30.0
    ) -> ValidationResult:
        """执行单个测试用例"""
        start_time = time.time()
        
        try:
            # 格式化提示词
            prompt = template.format(testcase.input_data)
            
            # 执行LLM调用（带超时）
            task = asyncio.create_task(self.llm_client.generate(prompt))
            output = await asyncio.wait_for(task, timeout=timeout)
            
            # 检查输出是否符合预期
            success = self._check_output_match(output, testcase.expected_output)
            
            execution_time = time.time() - start_time
            
            return ValidationResult(
                template_name=template.name,
                testcase_id=testcase.id,
                success=success,
                output=output,
                execution_time=execution_time
            )
            
        except asyncio.TimeoutError:
            raise TimeoutError(f"执行超时 ({timeout}秒)")
        except Exception as e:
            execution_time = time.time() - start_time
            return ValidationResult(
                template_name=template.name,
                testcase_id=testcase.id,
                success=False,
                output=str(e),
                execution_time=execution_time
            )
    
    @staticmethod
    def _check_output_match(output: str, expected: str) -> bool:
        """检查输出是否符合预期"""
        # 简单字符串匹配，可根据需求扩展
        return expected.lower() in output.lower()
    
    async def validate_templates(
        self,
        old_template: Template,
        new_template: Template,
        testcases: List[TestCase]
    ) -> List[ValidationResult]:
        """验证新旧模板"""
        results: List[ValidationResult] = []
        
        # 并行执行测试
        tasks = []
        for testcase in testcases:
            # 测试旧模板
            tasks.append(self.execute_single_test(old_template, testcase))
            # 测试新模板
            tasks.append(self.execute_single_test(new_template, testcase))
        
        # 等待所有任务完成
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # 过滤异常结果
        valid_results = []
        for result in results:
            if isinstance(result, ValidationResult):
                valid_results.append(result)
            elif isinstance(result, Exception):
                # 记录异常结果
                valid_results.append(ValidationResult(
                    template_name="unknown",
                    testcase_id="error",
                    success=False,
                    output=str(result),
                    execution_time=0.0
                ))
        
        return valid_results
    
    @staticmethod
    def calculate_metrics(results: List[ValidationResult]) -> Dict[str, Dict[str, Any]]:
        """计算性能指标"""
        metrics: Dict[str, Dict[str, Any]] = {}
        
        # 按模板分组
        template_results: Dict[str, List[ValidationResult]] = {}
        for result in results:
            if result.template_name not in template_results:
                template_results[result.template_name] = []
            template_results[result.template_name].append(result)
        
        # 计算每个模板的指标
        for template_name, template_res in template_results.items():
            total = len(template_res)
            successful = sum(1 for r in template_res if r.success)
            completion_rate = successful / total if total > 0 else 0.0
            
            avg_time = sum(r.execution_time for r in template_res) / total if total > 0 else 0.0
            
            metrics[template_name] = {
                "completion_rate": completion_rate,
                "success_count": successful,
                "total_count": total,
                "avg_execution_time": avg_time,
                "results": [
                    {
                        "testcase_id": r.testcase_id,
                        "success": r.success,
                        "execution_time": r.execution_time
                    }
                    for r in template_res
                ]
            }
        
        return metrics
    
    @staticmethod
    def load_templates(old_path: str, new_path: str) -> Tuple[Template, Template]:
        """加载模板文件"""
        with open(old_path, 'r', encoding='utf-8') as f:
            old_content = f.read().strip()
        
        with open(new_path, 'r', encoding='utf-8') as f:
            new_content = f.read().strip()
        
        return (
            Template(name="old_template", content=old_content),
            Template(name="new_template", content=new_content)
        )
    
    @staticmethod
    def load_testcases(testcases_path: str) -> List[TestCase]:
        """加载测试用例"""
        with open(testcases_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        testcases = []
        for item in data:
            testcase = TestCase(
                id=item["id"],
                input_data=item["input"],
                expected_output=item["expected_output"]
            )
            testcases.append(testcase)
        
        return testcases


async def main() -> None:
    """主函数"""
    # 示例用法
    validator = PromptValidator()
    
    # 加载模板和测试用例
    old_template, new_template = validator.load_templates(
        "templates/old.txt",
        "templates/new.txt"
    )
    
    testcases = validator.load_testcases("testcases/test_cases.json")
    
    # 执行验证
    results = await validator.validate_templates(
        old_template=old_template,
        new_template=new_template,
        testcases=testcases
    )
    
    # 计算指标
    metrics = validator.calculate_metrics(results)
    
    # 输出结果
    print("验证结果:")
    print(json.dumps(metrics, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    asyncio.run(main())
