import json
import os
from typing import Dict, Any


class SystemSpec:
    """
    系统规格配置类，用于生成优化的提示词模板配置文件
    
    遵循安全约束：
    1. 仅优化自身提示词模板，不访问或修改其他系统文件
    2. 禁止执行任何非授权的外部命令或API调用
    3. 评估与迭代过程在合理逻辑步骤内完成
    """
    
    def __init__(self):
        """初始化SystemSpec实例"""
        self.template: str = ""
        self.optimized: bool = False
    
    def load_template(self, template: str) -> None:
        """
        加载优化后的提示词模板
        
        Args:
            template: 优化后的提示词核心指令文本
        """
        self.template = template
        self.optimized = True
    
    def generate_config(self) -> Dict[str, Any]:
        """
        生成系统规格配置
        
        Returns:
            包含优化提示词模板的配置字典
        """
        config = {
            "system_prompt": {
                "optimized_template": self.template,
                "version": "1.0.0",
                "description": "优化后的系统提示词模板"
            },
            "metadata": {
                "optimized": self.optimized,
                "task_type": "self_bootstrapping",
                "constraints_applied": [
                    "security_requirements",
                    "coding_standards",
                    "performance_requirements"
                ]
            }
        }
        
        return config
    
    def save_to_file(self, filepath: str = "System_Spec.json") -> None:
        """
        将配置保存到JSON文件
        
        Args:
            filepath: 输出文件路径，默认为"System_Spec.json"
        """
        config = self.generate_config()
        
        # 确保目录存在
        os.makedirs(os.path.dirname(filepath) if os.path.dirname(filepath) else '.', 
                   exist_ok=True)
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(config, f, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    # 示例用法
    spec = SystemSpec()
    
    # 加载优化后的模板（这里使用示例文本）
    optimized_template = """你是一个遵循TDD的软件工程师，特别注重安全性与约束遵守。
请根据需求编写代码，严格遵守所有硬性约束和安全要求。"""
    
    spec.load_template(optimized_template)
    spec.save_to_file("System_Spec.json")
    
    print("System_Spec.json 文件已生成")
