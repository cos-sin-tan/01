"""
自定义异常模块

定义模板系统相关的异常类型。
"""


class TemplateError(Exception):
    """模板相关异常基类"""
    pass


class SecurityError(Exception):
    """安全相关异常"""
    pass


class ConfigurationError(Exception):
    """配置相关异常"""
    pass
