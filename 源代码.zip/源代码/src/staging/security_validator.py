"""
安全验证器
验证提示词模板的安全性，防止注入和偏见
"""

from typing import List


class SecurityValidator:
    """安全验证器类"""
    
    def __init__(self):
        """初始化安全规则"""
        self.dangerous_patterns = [
            # 命令注入
            r"exec\s*\(", r"eval\s*\(", r"system\s*\(",
            r"subprocess\.", r"os\.system",
            # 文件操作
            r"rm\s+-rf", r"del\s+", r"format\s+",
            # 网络攻击
            r"inject", r"bypass", r"exploit",
            # 偏见性语言
            r"所有.*都", r"总是", r"从不",
            r"歧视", r"偏见", r"不公平"
        ]
        
        self.bias_keywords = [
            "性别", "种族", "宗教", "年龄",
            "地域", "政治", "歧视", "偏见"
        ]
    
    def validate(self, template: str) -> bool:
        """
        验证模板安全性
        
        Args:
            template: 待验证的模板
            
        Returns:
            bool: 是否通过安全检查
        """
        if not template:
            return True
        
        # 检查危险模式
        for pattern in self.dangerous_patterns:
            if self._contains_pattern(template, pattern):
                return False
        
        # 检查偏见性语言
        if self._contains_bias(template):
            return False
        
        # 检查信息准确性标记
        if self._contains_false_claims(template):
            return False
        
        return True
    
    def _contains_pattern(self, text: str, pattern: str) -> bool:
        """检查是否包含危险模式"""
        import re
        return bool(re.search(pattern, text, re.IGNORECASE))
    
    def _contains_bias(self, text: str) -> bool:
        """检查是否包含偏见性语言"""
        # 检查绝对化表述
        absolute_terms = ["所有", "总是", "从不", "绝对"]
        for term in absolute_terms:
            if term in text:
                # 检查上下文，避免误判
                context = self._get_context(text, term)
                if self._is_biased_context(context):
                    return True
        
        # 检查偏见关键词
        for keyword in self.bias_keywords:
            if keyword in text:
                return True
        
        return False
    
    def _get_context(self, text: str, term: str, window: int = 20) -> str:
        """获取关键词上下文"""
        try:
            index = text.index(term)
            start = max(0, index - window)
            end = min(len(text), index + len(term) + window)
            return text[start:end]
        except ValueError:
            return ""
    
    def _is_biased_context(self, context: str) -> bool:
        """判断上下文是否包含偏见"""
        bias_indicators = ["人", "群体", "国家", "地区"]
        for indicator in bias_indicators:
            if indicator in context:
                return True
        return False
    
    def _contains_false_claims(self, text: str) -> bool:
        """检查是否包含虚假声明"""
        false_claims = [
            "100%准确", "绝对正确", "保证成功",
            "无风险", "零错误"
        ]
        
        for claim in false_claims:
            if claim in text:
                return True
        
        return False