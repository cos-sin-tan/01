import ast
import operator
import math

class SafeEvalError(Exception):
    """安全eval自定义异常"""
    pass

class SafeEval:
    """安全的表达式求值器"""
    
    # 允许的操作符
    _safe_operators = {
        ast.Add: operator.add,
        ast.Sub: operator.sub,
        ast.Mult: operator.mul,
        ast.Div: operator.truediv,
        ast.Pow: operator.pow,
        ast.Mod: operator.mod,
        ast.FloorDiv: operator.floordiv,
        ast.UAdd: operator.pos,
        ast.USub: operator.neg,
        ast.Eq: operator.eq,
        ast.NotEq: operator.ne,
        ast.Lt: operator.lt,
        ast.LtE: operator.le,
        ast.Gt: operator.gt,
        ast.GtE: operator.ge,
        ast.And: lambda a, b: a and b,
        ast.Or: lambda a, b: a or b,
    }
    
    # 允许的函数
    _safe_functions = {
        'abs': abs,
        'max': max,
        'min': min,
        'len': len,
        'round': round,
        'sum': sum,
        'int': int,
        'float': float,
        'str': str,
        'bool': bool,
        'list': list,
        'tuple': tuple,
        'dict': dict,
        'set': set,
        'sorted': sorted,
        'range': range,
        'enumerate': enumerate,
        'zip': zip,
        # 数学函数
        'sqrt': math.sqrt,
        'sin': math.sin,
        'cos': math.cos,
        'tan': math.tan,
        'log': math.log,
        'log10': math.log10,
        'exp': math.exp,
        'pi': math.pi,
        'e': math.e,
    }
    
    # 安全常量
    _safe_constants = {
        'True': True,
        'False': False,
        'None': None,
    }
    
    def __init__(self):
        """初始化安全求值器"""
        self._allowed_names = {}
        self._allowed_names.update(self._safe_functions)
        self._allowed_names.update(self._safe_constants)
    
    def eval(self, expr, variables=None):
        """
        安全地求值表达式
        
        Args:
            expr: 要求值的表达式字符串
            variables: 可选的变量字典
            
        Returns:
            表达式的结果
            
        Raises:
            SafeEvalError: 如果表达式不安全或无效
            SyntaxError: 如果语法无效
        """
        if not expr or not expr.strip():
            raise ValueError("表达式不能为空")
        
        # 清理表达式
        expr = expr.strip()
        
        # 创建命名空间
        namespace = self._allowed_names.copy()
        if variables:
            namespace.update(variables)
        
        try:
            # 解析AST
            tree = ast.parse(expr, mode='eval')
        except SyntaxError as e:
            raise SyntaxError(f"无效的表达式语法: {e}")
        
        # 安全检查
        self._check_node(tree.body)
        
        # 编译和执行
        try:
            code = compile(tree, '<string>', 'eval')
            result = eval(code, {"__builtins__": {}}, namespace)
            return result
        except Exception as e:
            raise SafeEvalError(f"求值错误: {e}")
    
    def _check_node(self, node):
        """递归检查AST节点是否安全"""
        if isinstance(node, ast.Expression):
            return self._check_node(node.body)
        
        # 检查函数调用
        if isinstance(node, ast.Call):
            # 检查函数名
            if isinstance(node.func, ast.Name):
                func_name = node.func.id
                if func_name not in self._safe_functions:
                    raise SafeEvalError(f"不允许的函数: {func_name}")
            elif isinstance(node.func, ast.Attribute):
                # 不允许属性访问（防止链式调用）
                raise SafeEvalError("不允许的属性访问")
            
            # 检查参数
            for arg in node.args:
                self._check_node(arg)
            for kwarg in node.keywords:
                self._check_node(kwarg.value)
            return
        
        # 检查名称（变量/函数名）
        if isinstance(node, ast.Name):
            # 检查双下划线（防止访问特殊属性）
            if node.id.startswith('__') and node.id.endswith('__'):
                raise SafeEvalError(f"不允许访问特殊名称: {node.id}")
            return
        
        # 检查属性访问（禁止）
        if isinstance(node, ast.Attribute):
            raise SafeEvalError("不允许的属性访问")
        
        # 检查比较操作
        if isinstance(node, ast.Compare):
            self._check_node(node.left)
            for comparator in node.comparators:
                self._check_node(comparator)
            return
        
        # 检查二元操作
        if isinstance(node, ast.BinOp):
            self._check_node(node.left)
            self._check_node(node.right)
            if type(node.op) not in self._safe_operators:
                raise SafeEvalError(f"不允许的操作符: {type(node.op).__name__}")
            return
        
        # 检查一元操作
        if isinstance(node, ast.UnaryOp):
            self._check_node(node.operand)
            if type(node.op) not in self._safe_operators:
                raise SafeEvalError(f"不允许的操作符: {type(node.op).__name__}")
            return
        
        # 检查布尔操作
        if isinstance(node, ast.BoolOp):
            for value in node.values:
                self._check_node(value)
            return
        
        # 检查常量（允许）
        if isinstance(node, ast.Constant):
            return
        
        # 检查列表、元组、字典、集合
        if isinstance(node, (ast.List, ast.Tuple, ast.Dict, ast.Set)):
            if isinstance(node, ast.List) or isinstance(node, ast.Tuple):
                for elt in node.elts:
                    self._check_node(elt)
            elif isinstance(node, ast.Dict):
                for key in node.keys:
                    if key:
                        self._check_node(key)
                for value in node.values:
                    self._check_node(value)
            elif isinstance(node, ast.Set):
                for elt in node.elts:
                    self._check_node(elt)
            return
        
        # 检查下标
        if isinstance(node, ast.Subscript):
            self._check_node(node.value)
            self._check_node(node.slice)
            return
        
        # 检查切片
        if isinstance(node, ast.Slice):
            if node.lower:
                self._check_node(node.lower)
            if node.upper:
                self._check_node(node.upper)
            if node.step:
                self._check_node(node.step)
            return
        
        # 默认：不允许其他节点类型
        raise SafeEvalError(f"不允许的表达式类型: {type(node).__name__}")

# 创建全局实例
_safe_evaluator = SafeEval()

def safe_eval(expr, variables=None):
    """
    安全求值表达式的便捷函数
    
    Args:
        expr: 要求值的表达式字符串
        variables: 可选的变量字典
        
    Returns:
        表达式的结果
    """
    return _safe_evaluator.eval(expr, variables)

if __name__ == "__main__":
    # 示例用法
    print("安全表达式求值器")
    print("基本算术:", safe_eval("1 + 2 * 3"))
    print("使用变量:", safe_eval("x + y", {"x": 5, "y": 3}))
    print("数学函数:", safe_eval("sqrt(16) + sin(0)"))
    
    # 测试不安全表达式
    try:
        safe_eval("__import__('os').system('ls')")
    except Exception as e:
        print(f"成功阻止不安全表达式: {e}")