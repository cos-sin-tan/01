"""
优化后的提示词模板库
遵循TDD原则，注重安全性与约束遵守
"""

import re
from typing import Dict, Any, List
from abc import ABC, abstractmethod


class BasePromptTemplate(ABC):
    """基础提示词模板抽象类"""
    
    # 安全关键词黑名单
    SAFETY_BLACKLIST = [
        'harmful', 'dangerous', 'illegal', 'unethical',
        'biased', 'discriminatory', 'offensive', 'hate',
        'violence', 'exploit', 'hack', 'cheat', 'bypass',
        'eval()', 'exec()', 'compile()', '__import__'
    ]
    
    # 偏见相关关键词
    BIAS_KEYWORDS = [
        'race', 'gender', 'religion', 'nationality',
        'age', 'disability', 'sexual orientation',
        'only men', 'only women', '特定种族', '特定性别'
    ]
    
    def __init__(self):
        self.role_definition = ""
        self.core_capabilities = []
        self.task_process = []
        self.output_format = ""
    
    @abstractmethod
    def generate(self, **kwargs) -> str:
        """生成提示词"""
        pass
    
    def _validate_inputs(self, **kwargs) -> None:
        """验证输入参数"""
        for key, value in kwargs.items():
            if not value or not str(value).strip():
                raise ValueError(f"参数 '{key}' 不能为空")
            
            # 安全检查
            self._check_safety(str(value))
    
    def _check_safety(self, text: str) -> None:
        """安全检查"""
        text_lower = text.lower()
        
        # 检查黑名单关键词
        for keyword in self.SAFETY_BLACKLIST:
            if keyword in text_lower:
                raise SecurityError(f"检测到不安全关键词: {keyword}")
        
        # 检查偏见内容
        for bias_word in self.BIAS_KEYWORDS:
            if bias_word in text_lower:
                # 检查上下文，避免误报
                context = self._get_context(text_lower, bias_word)
                if self._contains_bias_instruction(context):
                    raise SecurityError(f"检测到可能包含偏见的内容: {bias_word}")
    
    def _get_context(self, text: str, keyword: str, window: int = 50) -> str:
        """获取关键词上下文"""
        idx = text.find(keyword)
        if idx == -1:
            return ""
        
        start = max(0, idx - window)
        end = min(len(text), idx + len(keyword) + window)
        return text[start:end]
    
    def _contains_bias_instruction(self, context: str) -> bool:
        """检查是否包含偏见指令"""
        bias_indicators = [
            'only', 'exclude', 'prefer', 'avoid',
            '必须', '只能', '排除', '优先'
        ]
        
        for indicator in bias_indicators:
            if indicator in context.lower():
                return True
        return False
    
    def _build_template(self) -> str:
        """构建模板结构"""
        template_parts = []
        
        # 角色定义
        if self.role_definition:
            template_parts.append(f"## 角色定义\n{self.role_definition}")
        
        # 核心能力
        if self.core_capabilities:
            capabilities = "\n".join([f"- {cap}" for cap in self.core_capabilities])
            template_parts.append(f"## 核心能力\n{capabilities}")
        
        # 任务处理流程
        if self.task_process:
            process = "\n".join([f"{i+1}. {step}" for i, step in enumerate(self.task_process)])
            template_parts.append(f"## 任务处理流程\n{process}")
        
        # 输出格式
        if self.output_format:
            template_parts.append(f"## 输出格式\n{self.output_format}")
        
        return "\n\n".join(template_parts)


class AnalysisPromptTemplate(BasePromptTemplate):
    """分析型任务提示词模板"""
    
    def __init__(self):
        super().__init__()
        self.role_definition = "资深数据分析师，擅长从复杂信息中提取关键洞察"
        self.core_capabilities = [
            "数据解读与模式识别",
            "逻辑推理与因果分析",
            "风险评估与机会识别",
            "结构化报告撰写"
        ]
        self.task_process = [
            "理解分析目标和背景",
            "识别关键数据和信息点",
            "应用分析方法论",
            "提炼核心发现",
            "验证结论可靠性"
        ]
        self.output_format = """
1. 执行摘要（2-3句话概括核心发现）
2. 详细分析（分点阐述，支持数据引用）
3. 关键洞察（突出最重要发现）
4. 建议与后续步骤（如适用）
        """
    
    def generate(self, task_description: str, input_data: str, analysis_focus: str) -> str:
        """生成分析型提示词"""
        # 输入验证
        self._validate_inputs(
            task_description=task_description,
            input_data=input_data,
            analysis_focus=analysis_focus
        )
        
        # 构建基础模板
        base_template = self._build_template()
        
        # 添加任务特定信息
        task_section = f"""
## 任务描述
{task_description}

## 输入数据/信息
{input_data}

## 分析重点
{analysis_focus}
        """
        
        return base_template + task_section


class GenerationPromptTemplate(BasePromptTemplate):
    """生成型任务提示词模板"""
    
    def __init__(self):
        super().__init__()
        self.role_definition = "创意内容专家，擅长根据要求生成高质量文本内容"
        self.core_capabilities = [
            "创意构思与头脑风暴",
            "文体适配与风格控制",
            "信息结构化呈现",
            "质量自检与优化"
        ]
        self.task_process = [
            "理解创作目标与受众",
            "构思内容框架与要点",
            "生成初版内容",
            "优化语言表达与逻辑",
            "进行最终质量检查"
        ]
        self.output_format = """
1. 标题/主题
2. 主体内容（结构清晰，段落分明）
3. 关键要点总结（如适用）
4. 后续行动建议（如适用）
        """
    
    def generate(self, task_description: str, target_audience: str, content_requirements: str) -> str:
        """生成生成型提示词"""
        self._validate_inputs(
            task_description=task_description,
            target_audience=target_audience,
            content_requirements=content_requirements
        )
        
        base_template = self._build_template()
        
        task_section = f"""
## 任务描述
{task_description}

## 目标受众
{target_audience}

## 内容要求
{content_requirements}
        """
        
        return base_template + task_section


class PlanningPromptTemplate(BasePromptTemplate):
    """规划型任务提示词模板"""
    
    def __init__(self):
        super().__init__()
        self.role_definition = "战略规划专家，擅长制定可执行的项目计划与路线图"
        self.core_capabilities = [
            "目标分解与任务拆解",
            "资源评估与分配规划",
            "风险评估与应对策略",
            "时间线与里程碑设计"
        ]
        self.task_process = [
            "明确规划目标与范围",
            "识别关键约束与依赖",
            "制定主要阶段与里程碑",
            "分配资源与时间估算",
            "设计监控与调整机制"
        ]
        self.output_format = """
1. 规划概述（目标、范围、价值）
2. 阶段划分与时间线
3. 关键里程碑与交付物
4. 资源需求与分配
5. 风险矩阵与应对措施
        """
    
    def generate(self, task_description: str, project_scope: str, constraints: str) -> str:
        """生成规划型提示词"""
        self._validate_inputs(
            task_description=task_description,
            project_scope=project_scope,
            constraints=constraints
        )
        
        base_template = self._build_template()
        
        task_section = f"""
## 任务描述
{task_description}

## 项目范围
{project_scope}

## 约束条件
{constraints}
        """
        
        return base_template + task_section


def validate_template_safety(template: str) -> bool:
    """验证模板安全性"""
    try:
        # 创建临时模板实例进行检查
        checker = BasePromptTemplate()
        checker._check_safety(template)
        return True
    except SecurityError:
        return False
    except Exception:
        return False


class SecurityError(Exception):
    """安全性错误异常"""
    pass


# 模板注册表
TEMPLATE_REGISTRY = {
    "analysis": AnalysisPromptTemplate,
    "generation": GenerationPromptTemplate,
    "planning": PlanningPromptTemplate
}


def get_template(template_type: str) -> BasePromptTemplate:
    """获取指定类型的模板"""
    if template_type not in TEMPLATE_REGISTRY:
        raise ValueError(f"未知模板类型: {template_type}")
    return TEMPLATE_REGISTRY[template_type]()
