"""
自举任务：优化自身提示词模板的核心模块。
此模块负责生成、评估和迭代优化提示词模板。
"""

import json
import logging
import re
from typing import Dict, List, Any, Optional, Tuple

# 配置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class PromptOptimizer:
    """
    提示词优化器类。
    核心功能：基于反馈和评估结果，迭代优化提示词模板。
    """

    def __init__(self, initial_template: str, constraints: Dict[str, Any]):
        """
        初始化优化器。
        :param initial_template: 初始提示词模板字符串。
        :param constraints: 优化约束，例如禁用函数、最大长度等。
        """
        self.current_template = initial_template
        self.constraints = constraints
        self.version_history: List[Dict[str, Any]] = []
        self.evaluation_history: List[Dict[str, Any]] = []
        self._validate_constraints()

    def _validate_constraints(self) -> None:
        """验证约束字典的完整性。"""
        required_keys = ["forbidden_functions", "max_length", "required_sections"]
        for key in required_keys:
            if key not in self.constraints:
                raise ValueError(f"约束中缺少必需的键: {key}")
        logger.info("约束验证通过。")

    def evaluate_template(self, template: str, test_cases: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        评估当前提示词模板的性能。
        :param template: 要评估的模板字符串。
        :param test_cases: 测试用例列表，每个用例包含输入和期望输出。
        :return: 包含评分和详细结果的字典。
        """
        logger.info(f"开始评估模板，长度: {len(template)}")
        scores = {
            "safety_score": self._calculate_safety_score(template),
            "clarity_score": self._calculate_clarity_score(template),
            "effectiveness_score": self._calculate_effectiveness_score(template, test_cases),
        }
        overall_score = sum(scores.values()) / len(scores)
        result = {
            "template": template,
            "scores": scores,
            "overall_score": overall_score,
            "violations": self._check_violations(template),
        }
        self.evaluation_history.append(result)
        logger.info(f"评估完成，综合得分: {overall_score:.2f}")
        return result

    def _calculate_safety_score(self, template: str) -> float:
        """计算安全性得分。检查是否包含高危函数。"""
        forbidden_patterns = self.constraints["forbidden_functions"]
        score = 10.0  # 满分10分
        for pattern in forbidden_patterns:
            if re.search(pattern, template, re.IGNORECASE):
                score -= 2.5  # 每发现一个违规扣2.5分
        return max(score, 0.0)

    def _calculate_clarity_score(self, template: str) -> float:
        """计算清晰度得分。基于结构、长度和可读性。"""
        score = 0.0
        # 检查长度
        max_len = self.constraints["max_length"]
        if len(template) <= max_len:
            score += 4.0
        elif len(template) <= max_len * 1.2:
            score += 2.0
        # 检查必要部分
        required_sections = self.constraints["required_sections"]
        for section in required_sections:
            if section in template:
                score += 2.0
        # 结构检查（简单示例）
        if "\n\n" in template:  # 粗略判断是否有段落分隔
            score += 2.0
        return min(score, 10.0)

    def _calculate_effectiveness_score(self, template: str, test_cases: List[Dict[str, Any]]) -> float:
        """计算有效性得分。基于模拟测试用例的匹配度。"""
        if not test_cases:
            return 5.0  # 若无测试用例，返回中性分
        total_score = 0.0
        for case in test_cases:
            # 模拟生成输出（此处为简化逻辑，实际应调用LLM或模拟器）
            simulated_output = self._simulate_execution(template, case["input"])
            expected_output = case.get("expected_output", "")
            # 使用更复杂的相似度评估，而非简单字符串相等
            similarity = self._calculate_similarity(simulated_output, expected_output)
            total_score += similarity
        return (total_score / len(test_cases)) * 10.0

    def _simulate_execution(self, template: str, input_data: Any) -> str:
        """
        模拟模板执行。
        此版本使用简单的规则模拟LLM行为，实际应用中应替换为真实的LLM API调用。
        """
        # 替换输入数据中的占位符
        if isinstance(input_data, dict):
            for key, value in input_data.items():
                placeholder = f"{{{key}}}"
                if placeholder in template:
                    template = template.replace(placeholder, str(value))
        
        # 模拟LLM响应：根据模板内容生成代码片段
        # 这是一个简化的模拟，实际应使用更复杂的逻辑或真实API
        if "代码" in template and "函数" in template:
            # 模拟生成函数代码
            if "Hello World" in template:
                return "def hello_world():\n    print('Hello World')"
            elif "计算两个数的和" in template:
                return "def add(a, b):\n    return a + b"
            else:
                return "def example_function():\n    # 示例代码"
        else:
            # 对于非代码生成任务，返回处理后的模板
            return template[:500]  # 限制长度，避免过长输出

    def _calculate_similarity(self, output1: str, output2: str) -> float:
        """计算两个输出字符串的相似度得分（0-1）。"""
        # 简单实现：基于共同字符的比例
        set1 = set(output1.lower().split())
        set2 = set(output2.lower().split())
        if not set1 and not set2:
            return 0.0
        intersection = len(set1.intersection(set2))
        union = len(set1.union(set2))
        return intersection / union if union > 0 else 0.0

    def _check_violations(self, template: str) -> List[str]:
        """检查模板是否违反安全约束。"""
        violations = []
        # 检查高危函数
        forbidden_patterns = self.constraints["forbidden_functions"]
        for pattern in forbidden_patterns:
            if re.search(pattern, template, re.IGNORECASE):
                violations.append(f"检测到高危函数模式: {pattern}")
        # 检查长度
        max_len = self.constraints["max_length"]
        if len(template) > max_len:
            violations.append(f"模板长度 {len(template)} 超过最大限制 {max_len}")
        # 检查必要部分
        required_sections = self.constraints["required_sections"]
        for section in required_sections:
            if section not in template:
                violations.append(f"缺少必要部分: {section}")
        return violations

    def optimize(self, feedback: Dict[str, Any], test_cases: List[Dict[str, Any]]) -> Tuple[str, Dict[str, Any]]:
        """
        基于反馈优化当前模板。
        :param feedback: 外部反馈，包含问题描述和建议。
        :param test_cases: 用于评估的测试用例。
        :return: 优化后的模板和评估结果。
        """
        logger.info(f"开始优化迭代，反馈: {feedback.get('issue', 'N/A')}")
        # 记录当前版本
        self.version_history.append({
            "template": self.current_template,
            "feedback": feedback,
        })
        # 生成优化候选（此处为简化逻辑，实际可使用更复杂的策略）
        candidate = self._generate_candidate(feedback)
        # 评估候选模板
        evaluation = self.evaluate_template(candidate, test_cases)
        # 修复：安全地比较分数，避免IndexError
        if len(self.evaluation_history) > 1:
            previous_score = self.evaluation_history[-2]["overall_score"]
        else:
            previous_score = 0.0
        
        # 如果候选更好，则替换当前模板
        if evaluation["overall_score"] > previous_score:
            self.current_template = candidate
            logger.info(f"模板已更新，新得分: {evaluation['overall_score']:.2f}")
        else:
            logger.info(f"候选模板未优于当前版本，保持原模板。")
        return self.current_template, evaluation

    def _generate_candidate(self, feedback: Dict[str, Any]) -> str:
        """基于反馈生成优化候选模板。"""
        candidate = self.current_template
        issue = feedback.get("issue", "")
        suggestion = feedback.get("suggestion", "")
        
        # 改进的优化规则：基于语义而非简单关键词匹配
        
        # 处理长度问题
        if any(keyword in issue.lower() for keyword in ["长度", "过长", "太长"]):
            # 智能简化：移除冗余空格和空行
            lines = [line.strip() for line in candidate.split('\n') if line.strip()]
            candidate = '\n'.join(lines)
            # 如果仍然超长，截断但保留关键部分
            max_len = self.constraints["max_length"]
            if len(candidate) > max_len:
                # 尝试保留开头和关键部分
                required_sections = self.constraints["required_sections"]
                important_parts = []
                for section in required_sections:
                    if section in candidate:
                        start = candidate.find(section)
                        end = min(start + 200, len(candidate))
                        important_parts.append(candidate[start:end])
                if important_parts:
                    candidate = '\n'.join(important_parts)[:max_len]
                else:
                    candidate = candidate[:max_len]
        
        # 处理缺少部分的问题
        if any(keyword in issue.lower() for keyword in ["缺少", "部分", "缺失"]):
            required_sections = self.constraints["required_sections"]
            for section in required_sections:
                if section not in candidate:
                    # 智能插入到合适位置
                    if "要求" in candidate:
                        # 插入到要求部分之后
                        candidate = candidate.replace("要求", f"要求\n{section}: [请在此处补充内容]")
                    else:
                        candidate += f"\n\n{section}: [请在此处补充内容]"
        
        # 处理安全问题
        if any(keyword in issue.lower() for keyword in ["高危", "安全", "危险"]):
            forbidden_patterns = self.constraints["forbidden_functions"]
            for pattern in forbidden_patterns:
                candidate = re.sub(pattern, "[已移除高危函数]", candidate, flags=re.IGNORECASE)
            # 添加安全警告
            if "要求" in candidate:
                candidate = candidate.replace("要求", "要求\n安全警告: 禁止使用eval, exec, os.system等危险函数")
        
        # 应用具体建议
        if suggestion:
            # 智能插入建议到合适位置
            if "# 优化建议" not in candidate:
                candidate += f"\n\n# 优化建议: {suggestion}"
            else:
                # 更新现有建议
                candidate = re.sub(r'# 优化建议:.*', f'# 优化建议: {suggestion}', candidate)
        
        return candidate

    def get_status(self) -> Dict[str, Any]:
        """返回当前优化器状态。"""
        return {
            "current_template": self.current_template,
            "template_length": len(self.current_template),
            "version_count": len(self.version_history),
            "latest_evaluation": self.evaluation_history[-1] if self.evaluation_history else None,
            "constraints": self.constraints,
        }


# 示例使用和约束定义
if __name__ == "__main__":
    # 初始模板示例
    INITIAL_TEMPLATE = """
    你是一位资深软件工程师。请根据用户请求生成代码。
    要求：
    1. 代码必须安全，避免使用高危函数。
    2. 代码应简洁清晰。
    3. 提供必要的注释。
    
    用户请求：
    {user_request}
    """
    
    # 约束定义
    CONSTRAINTS = {
        "forbidden_functions": [r"eval\s*\(", r"exec\s*\(", r"os\.system\s*\(", r"subprocess\.run\s*\("],
        "max_length": 2000,
        "required_sections": ["要求", "用户请求"],
    }
    
    # 测试用例
    TEST_CASES = [
        {"input": {"user_request": "写一个Hello World函数。"}, "expected_output": "def hello_world():\n    print('Hello World')"},
        {"input": {"user_request": "计算两个数的和。"}, "expected_output": "def add(a, b):\n    return a + b"},
    ]
    
    # 初始化优化器
    optimizer = PromptOptimizer(INITIAL_TEMPLATE, CONSTRAINTS)
    
    # 初始评估
    initial_eval = optimizer.evaluate_template(INITIAL_TEMPLATE, TEST_CASES)
    print(f"初始评估: {json.dumps(initial_eval, indent=2, ensure_ascii=False)}")
    
    # 模拟反馈并优化
    feedback = {
        "issue": "模板长度可能过长，且缺少对安全性的明确强调。",
        "suggestion": "在要求部分明确列出禁止的高危函数。"
    }
    optimized_template, new_eval = optimizer.optimize(feedback, TEST_CASES)
    print(f"优化后模板: {optimized_template}")
    print(f"新评估结果: {json.dumps(new_eval, indent=2, ensure_ascii=False)}")
    
    # 输出状态
    status = optimizer.get_status()
    print(f"优化器状态: {json.dumps(status, indent=2, ensure_ascii=False)}")
