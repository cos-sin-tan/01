#!/usr/bin/env python3
"""
提示词模板优化模块
实现自举任务：优化自身提示词模板的核心功能
"""

import re
from typing import Dict, List, Tuple, Optional

class PromptOptimizer:
    """提示词优化器类，负责分析和优化提示词模板"""
    
    def __init__(self):
        """初始化优化器"""
        self.improvement_patterns = [
            (r'写一个', '请编写一个清晰、具体的'),
            (r'帮我', '请协助我'),
            (r'简单', '简洁明了'),
            (r'函数', '可复用的函数'),
            (r'代码', '符合PEP8规范的Python代码'),
        ]
        
        # 危险关键词列表（安全审计要求）
        self.dangerous_keywords = [
            'eval', 'exec', 'pickle', 'os.system',
            'subprocess', '__import__', 'compile',
            'execfile', 'input', 'open',
        ]
    
    def optimize(self, original_prompt: str) -> str:
        """
        优化原始提示词
        
        Args:
            original_prompt: 原始提示词
            
        Returns:
            str: 优化后的提示词
            
        Raises:
            ValueError: 如果提示词为空或仅包含空白字符
        """
        # 输入验证
        if not original_prompt or not original_prompt.strip():
            raise ValueError("提示词不能为空")
        
        # 安全验证
        if not self.validate_security(original_prompt):
            raise ValueError("提示词包含不安全内容")
        
        # 分析提示词质量
        quality_scores = self.analyze_quality(original_prompt)
        
        # 生成改进建议
        suggestions = self.generate_suggestions(original_prompt)
        
        # 应用优化规则
        optimized = original_prompt
        for pattern, replacement in self.improvement_patterns:
            optimized = re.sub(pattern, replacement, optimized, flags=re.IGNORECASE)
        
        # 添加结构化改进
        if quality_scores['structure_score'] < 70:
            optimized = self._add_structure(optimized)
        
        # 添加清晰度改进
        if quality_scores['clarity_score'] < 70:
            optimized = self._improve_clarity(optimized)
        
        return optimized
    
    def analyze_quality(self, prompt: str) -> Dict[str, int]:
        """
        分析提示词质量
        
        Args:
            prompt: 待分析的提示词
            
        Returns:
            Dict[str, int]: 包含各项质量分数的字典
        """
        scores = {
            'clarity_score': 0,
            'specificity_score': 0,
            'structure_score': 0,
            'completeness_score': 0
        }
        
        # 清晰度评分
        clarity_indicators = ['请', '明确', '清晰', '详细']
        clarity_count = sum(1 for indicator in clarity_indicators 
                          if indicator in prompt)
        scores['clarity_score'] = min(100, clarity_count * 25)
        
        # 具体性评分
        word_count = len(prompt.split())
        scores['specificity_score'] = min(100, word_count * 5)
        
        # 结构性评分
        structure_indicators = ['步骤', '要求', '格式', '示例']
        structure_count = sum(1 for indicator in structure_indicators 
                            if indicator in prompt)
        scores['structure_score'] = min(100, structure_count * 25)
        
        # 完整性评分
        completeness_indicators = ['输入', '输出', '功能', '约束']
        completeness_count = sum(1 for indicator in completeness_indicators 
                               if indicator in prompt)
        scores['completeness_score'] = min(100, completeness_count * 25)
        
        return scores
    
    def generate_suggestions(self, prompt: str) -> List[str]:
        """
        生成改进建议
        
        Args:
            prompt: 原始提示词
            
        Returns:
            List[str]: 改进建议列表
        """
        suggestions = []
        quality_scores = self.analyze_quality(prompt)
        
        # 根据质量分数生成建议
        if quality_scores['clarity_score'] < 60:
            suggestions.append("建议使用更清晰的语言，明确表达需求")
            
        if quality_scores['specificity_score'] < 60:
            suggestions.append("建议提供更具体的细节和要求")
            
        if quality_scores['structure_score'] < 60:
            suggestions.append("建议添加结构化的要求，如步骤或格式")
            
        if quality_scores['completeness_score'] < 60:
            suggestions.append("建议明确输入、输出、功能和约束条件")
        
        # 通用建议
        suggestions.append("考虑添加示例输入和期望输出")
        suggestions.append("明确性能要求或约束条件")
        suggestions.append("指定代码风格和规范要求")
        
        return suggestions
    
    def validate_security(self, prompt: str) -> bool:
        """
        验证提示词安全性
        
        Args:
            prompt: 待验证的提示词
            
        Returns:
            bool: 是否安全
        """
        # 检查是否包含危险关键词
        for keyword in self.dangerous_keywords:
            if re.search(rf'\b{keyword}\b', prompt, re.IGNORECASE):
                return False
        
        # 检查是否包含潜在的危险模式
        dangerous_patterns = [
            r'删除.*文件',
            r'格式化.*磁盘',
            r'执行.*命令',
            r'系统.*调用',
        ]
        
        for pattern in dangerous_patterns:
            if re.search(pattern, prompt, re.IGNORECASE):
                return False
        
        return True
    
    def _add_structure(self, prompt: str) -> str:
        """为提示词添加结构"""
        structured_prompt = prompt
        
        if '步骤' not in prompt:
            structured_prompt += "\n\n请按照以下步骤实现："
            
        if '要求' not in prompt:
            structured_prompt += "\n\n具体要求："
            
        return structured_prompt
    
    def _improve_clarity(self, prompt: str) -> str:
        """提高提示词清晰度"""
        clarity_improvements = [
            (r'^', '请'),
            (r'(\.|\!)$', '。具体要求如下：'),
        ]
        
        improved = prompt
        for pattern, replacement in clarity_improvements:
            improved = re.sub(pattern, replacement, improved)
            
        return improved


def main():
    """主函数：演示提示词优化功能"""
    optimizer = PromptOptimizer()
    
    # 示例提示词
    example_prompts = [
        "写一个Python函数计算阶乘",
        "帮我处理数据",
        "创建一个用户注册系统",
    ]
    
    print("提示词优化演示：")
    print("=" * 50)
    
    for i, original in enumerate(example_prompts, 1):
        print(f"\n示例 {i}:")
        print(f"原始提示词: {original}")
        
        try:
            # 分析质量
            quality = optimizer.analyze_quality(original)
            print(f"质量分析: {quality}")
            
            # 生成建议
            suggestions = optimizer.generate_suggestions(original)
            print(f"改进建议: {suggestions[:2]}")  # 只显示前两个建议
            
            # 优化提示词
            optimized = optimizer.optimize(original)
            print(f"优化后提示词: {optimized}")
            
        except ValueError as e:
            print(f"错误: {e}")
        
        print("-" * 50)
    
    print("\n演示完成！")


if __name__ == "__main__":
    main()