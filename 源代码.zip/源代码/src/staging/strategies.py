"""
优化策略模块
定义不同的提示词优化策略
"""

from abc import ABC, abstractmethod
from typing import List


class OptimizationStrategy(ABC):
    """优化策略抽象基类"""
    
    @abstractmethod
    def apply(self, prompt: str) -> str:
        """应用优化策略到提示词"""
        pass
    
    @abstractmethod
    def get_description(self) -> str:
        """获取策略描述"""
        pass


class StructuredReorganizationStrategy(OptimizationStrategy):
    """结构化重组策略：重新组织提示词结构"""
    
    def apply(self, prompt: str) -> str:
        """
        应用结构化重组
        - 添加明确的章节标题
        - 使用项目符号列表
        - 优化段落结构
        """
        # 安全处理：仅进行字符串操作，不执行任何代码
        sections = [
            "# 角色定义\n",
            "你是一个专业的人工智能助手。\n\n",
            "# 核心任务\n",
            f"{prompt}\n\n",
            "# 响应要求\n",
            "1. 提供准确、有用的信息\n",
            "2. 保持专业、礼貌的语气\n",
            "3. 如果信息不足，请明确说明\n",
            "4. 优先考虑安全性和准确性"
        ]
        
        return "".join(sections)
    
    def get_description(self) -> str:
        return "结构化重组：添加明确章节标题和项目符号列表"


class ExampleEnhancementStrategy(OptimizationStrategy):
    """示例强化策略：添加具体示例"""
    
    def apply(self, prompt: str) -> str:
        """
        应用示例强化
        - 添加通用示例
        - 说明期望的响应格式
        """
        example_template = (
            "{original_prompt}\n\n"
            "# 示例说明\n"
            "为了更好地理解任务，请参考以下示例：\n\n"
            "**用户输入示例**：\n"
            "'请解释机器学习的基本概念'\n\n"
            "**理想响应示例**：\n"
            "'机器学习是人工智能的一个分支，它使计算机能够从数据中学习而无需显式编程。主要类型包括监督学习、无监督学习和强化学习。'\n\n"
            "请根据以上示例的风格和格式来响应。"
        )
        
        return example_template.format(original_prompt=prompt)
    
    def get_description(self) -> str:
        return "示例强化：添加具体输入输出示例"


class InstructionClarificationStrategy(OptimizationStrategy):
    """指令明确化策略：使指令更具体明确"""
    
    def apply(self, prompt: str) -> str:
        """
        应用指令明确化
        - 添加具体约束条件
        - 明确响应格式要求
        - 指定思考过程
        """
        clarification_template = (
            "请严格按照以下要求执行任务：\n\n"
            "**核心指令**：\n"
            "{original_prompt}\n\n"
            "**具体约束**：\n"
            "1. 必须验证所有信息的准确性\n"
            "2. 如果涉及不确定的内容，请明确标注'可能存在不确定性'\n"
            "3. 优先使用中文响应，专业术语可保留英文\n"
            "4. 保持响应简洁，避免冗余信息\n\n"
            "**响应格式**：\n"
            "- 以清晰、有条理的方式组织内容\n"
            "- 使用适当的标题和段落分隔\n"
            "- 关键点使用项目符号突出显示"
        )
        
        return clarification_template.format(original_prompt=prompt)
    
    def get_description(self) -> str:
        return "指令明确化：添加具体约束和格式要求"
