#!/usr/bin/env python3
"""
知识遗忘机制的单元测试。
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from vector_service import VectorErrorService

def test_forget_stale_lessons():
    """测试 forget_stale_lessons 方法（模拟）"""
    service = VectorErrorService(persist_directory=".chroma_db_test", collection_name="test_forget")
    # 确保集合存在（如果不存在则创建）
    try:
        service.collection.count()
    except:
        # 空集合
        pass
    
    # 调用遗忘方法（目前仅打印日志）
    deleted = service.forget_stale_lessons(days_old=7, min_score=0.2)
    # 应返回整数
    assert isinstance(deleted, int)
    # 当前实现返回 0（未实际删除）
    assert deleted == 0
    print("[PASS] forget_stale_lessons 返回预期值")
    
    # 清理测试集合
    service.clear_collection()

if __name__ == "__main__":
    test_forget_stale_lessons()
    print("知识遗忘测试通过")