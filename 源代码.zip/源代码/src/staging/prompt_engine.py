import json
import re
from typing import Dict, List, Any, Optional, Callable
from dataclasses import dataclass, asdict, field


@dataclass
class Template:
    """提示词模板类"""
    name: str
    system_prompt: str
    user_prompt: str
    examples: List[Dict[str, str]]
    constraints: List[str]
    
    def __post_init__(self) -> None:
        """验证模板数据"""
        if not self.name or not isinstance(self.name, str):
            raise ValueError("Template name cannot be empty")
        
        # 确保字段类型正确
        self.system_prompt = str(self.system_prompt) if self.system_prompt else ""
        self.user_prompt = str(self.user_prompt) if self.user_prompt else ""
        self.examples = self.examples if isinstance(self.examples, list) else []
        self.constraints = self.constraints if isinstance(self.constraints, list) else []
    
    def to_json(self) -> str:
        """将模板转换为JSON字符串"""
        data = asdict(self)
        data["version"] = "1.0"
        return json.dumps(data, ensure_ascii=False, indent=2)


@dataclass
class Rule:
    """优化规则类"""
    rule_type: str
    description: str
    action: Callable[[Template], Dict[str, Any]]
    
    def __post_init__(self) -> None:
        """验证规则数据"""
        if not self.rule_type or not isinstance(self.rule_type, str):
            raise ValueError("Rule type cannot be empty")
        if not self.description or not isinstance(self.description, str):
            raise ValueError("Rule description cannot be empty")
        if self.action is None:
            raise ValueError("Rule action cannot be None")


class PromptEngine:
    """提示词模板生成与修改引擎"""
    
    def __init__(self, config: Optional[Dict[str, Any]] = None) -> None:
        """初始化引擎"""
        self.config = config or {
            "default_constraints": [],
            "auto_version": True,
            "sanitize_input": True
        }
    
    def parse_template(self, template_json: str) -> Template:
        """解析JSON格式的提示词模板"""
        # 输入验证
        if not template_json or not isinstance(template_json, str):
            raise ValueError("Template JSON must be a non-empty string")
        
        try:
            data = json.loads(template_json)
        except json.JSONDecodeError:
            raise ValueError("Invalid JSON format")
        
        # 清理输入以防止注入
        if self.config.get("sanitize_input", True):
            data = self._sanitize_data(data)
        
        # 提取模板字段，提供默认值
        name = str(data.get("name", "unnamed_template")).strip()
        system_prompt = str(data.get("system_prompt", "")).strip()
        user_prompt = str(data.get("user_prompt", "")).strip()
        examples = data.get("examples", [])
        constraints = data.get("constraints", [])
        
        # 验证字段类型
        if not isinstance(examples, list):
            examples = []
        if not isinstance(constraints, list):
            constraints = []
        
        return Template(
            name=name,
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            examples=examples,
            constraints=constraints
        )
    
    def generate_variant(self, template: Template, rule: Rule) -> Template:
        """根据规则生成模板变体"""
        # 验证输入
        if not isinstance(template, Template):
            raise ValueError("Template must be an instance of Template class")
        if not isinstance(rule, Rule):
            raise ValueError("Rule must be an instance of Rule class")
        
        # 应用规则
        try:
            modifications = rule.action(template)
        except Exception as e:
            raise ValueError(f"Rule action failed: {str(e)}")
        
        # 验证规则返回结果
        if not isinstance(modifications, dict):
            raise ValueError("Rule action must return a dictionary")
        
        # 创建新模板
        new_name = f"{template.name}_variant"
        new_system_prompt = modifications.get("system_prompt", template.system_prompt)
        new_user_prompt = modifications.get("user_prompt", template.user_prompt)
        new_examples = modifications.get("examples", template.examples)
        new_constraints = modifications.get("constraints", template.constraints)
        
        # 添加默认约束
        default_constraints = self.config.get("default_constraints", [])
        if default_constraints:
            new_constraints = list(set(new_constraints + default_constraints))
        
        return Template(
            name=new_name,
            system_prompt=str(new_system_prompt),
            user_prompt=str(new_user_prompt),
            examples=list(new_examples) if isinstance(new_examples, list) else [],
            constraints=list(new_constraints) if isinstance(new_constraints, list) else []
        )
    
    def generate_variants(self, template: Template, rules: List[Rule]) -> List[Template]:
        """应用多个规则生成多个变体"""
        variants: List[Template] = []
        current_template = template
        
        for rule in rules:
            variant = self.generate_variant(current_template, rule)
            variants.append(variant)
            current_template = variant
        
        return variants
    
    def _sanitize_data(self, data: Any) -> Any:
        """递归清理数据中的危险内容"""
        if isinstance(data, dict):
            return {k: self._sanitize_data(v) for k, v in data.items()}
        elif isinstance(data, list):
            return [self._sanitize_data(item) for item in data]
        elif isinstance(data, str):
            return self._sanitize_input(data)
        else:
            return data
    
    def _sanitize_input(self, text: str) -> str:
        """清理输入文本，防止模板注入"""
        if not text:
            return ""
        
        # 移除可能用于模板注入的字符
        text = re.sub(r'\{\{.*?\}\}', '', text)  # 移除Jinja2风格模板
        text = re.sub(r'\$\{.*?\}', '', text)    # 移除Shell风格变量
        text = re.sub(r'<%.*?%>', '', text)       # 移除ERB风格模板
        
        # 移除危险字符
        dangerous_patterns = [
            r'\\n',     # 换行符转义
            r'\\t',     # 制表符转义
            r'\\r',     # 回车符转义
            r'\\\\',  # 反斜杠
        ]
        
        for pattern in dangerous_patterns:
            text = re.sub(pattern, '', text)
        
        # 移除多余空格
        text = ' '.join(text.split())
        
        return text.strip()