"""
提示词模板优化器
基于诊断报告优化提示词模板，确保安全性、清晰度和性能
"""

import re
from typing import List, Tuple


class PromptTemplateOptimizer:
    """提示词模板优化器类"""
    
    def __init__(self):
        """初始化优化器"""
        self.security_keywords = [
            '有害', '危险', '非法', '违法', '攻击', '破解', '入侵',
            '偏见', '歧视', '仇恨', '暴力', '色情', '裸露',
            'eval(', 'exec(', 'os.system', 'subprocess',
            '忽略安全', '绕过验证', '未授权'
        ]
        
        self.ethics_statements = [
            "**遵循AI伦理原则，确保内容安全、公正、无偏见**",
            "**拒绝生成任何有害、危险或非法内容**",
            "**尊重所有用户，避免任何形式的歧视或偏见**",
            "**遵守相关法律法规和平台政策**"
        ]
        
        self.template_structure = [
            "### 角色定义",
            "### 核心指令",
            "### 约束条件",
            "### 输出格式",
            "### 示例参考"
        ]
    
    def optimize(self, old_template: str) -> str:
        """
        优化提示词模板
        
        Args:
            old_template: 旧模板内容
            
        Returns:
            str: 优化后的新模板
        """
        # 安全检查
        safe_template = self._apply_security_filters(old_template)
        
        # 结构优化
        structured_template = self._apply_structure_optimization(safe_template)
        
        # 清晰度优化
        clear_template = self._apply_clarity_optimization(structured_template)
        
        # 性能优化
        final_template = self._apply_performance_optimization(clear_template)
        
        return final_template
    
    def validate_template(self, template: str) -> bool:
        """
        验证模板格式和内容
        
        Args:
            template: 模板内容
            
        Returns:
            bool: 是否有效
        """
        if not template or not isinstance(template, str):
            return False
        
        # 基本语法检查
        if len(template.strip()) < 10:  # 最小长度要求
            return False
        
        # 结构检查
        structure_count = sum(1 for section in self.template_structure 
                            if section in template)
        if structure_count < 3:  # 至少包含3个主要部分
            return False
        
        # 安全检查
        for keyword in self.security_keywords:
            if keyword in template.lower():
                return False
        
        # 指令清晰度检查
        if '###' not in template and '**' not in template:
            return False
        
        return True
    
    def _apply_security_filters(self, template: str) -> str:
        """应用安全过滤器"""
        # 移除危险关键词
        safe_text = template
        for keyword in self.security_keywords:
            pattern = re.compile(re.escape(keyword), re.IGNORECASE)
            safe_text = pattern.sub('[已过滤]', safe_text)
        
        # 添加伦理声明
        ethics_section = '\n'.join(self.ethics_statements)
        if ethics_section not in safe_text:
            safe_text = f"{ethics_section}\n\n{safe_text}"
        
        return safe_text
    
    def _apply_structure_optimization(self, template: str) -> str:
        """应用结构优化"""
        # 确保包含标准结构
        structured = []
        
        # 添加缺失的结构部分
        for section in self.template_structure:
            if section not in template:
                structured.append(f"{section}\n[请在此处填写具体内容]\n")
        
        # 保留原有内容，添加新结构
        if structured:
            return f"{'\n'.join(structured)}\n\n---\n\n{template}"
        return template
    
    def _apply_clarity_optimization(self, template: str) -> str:
        """应用清晰度优化"""
        # 标记关键指令
        lines = template.split('\n')
        enhanced_lines = []
        
        for line in lines:
            trimmed = line.strip()
            if any(keyword in trimmed.lower() for keyword in 
                   ['必须', '应当', '需要', '要求', '确保', '禁止']):
                if not trimmed.startswith('**') and not trimmed.startswith('###'):
                    enhanced_lines.append(f"**{trimmed}**")
                else:
                    enhanced_lines.append(line)
            else:
                enhanced_lines.append(line)
        
        # 添加清晰度说明
        clarity_note = "\n**请确保指令明确、具体，避免模糊或歧义表述**"
        if clarity_note not in '\n'.join(enhanced_lines):
            enhanced_lines.append(clarity_note)
        
        return '\n'.join(enhanced_lines)
    
    def _apply_performance_optimization(self, template: str) -> str:
        """应用性能优化"""
        # 移除冗余内容
        lines = template.split('\n')
        unique_lines = []
        seen_lines = set()
        
        for line in lines:
            trimmed = line.strip()
            if trimmed and trimmed not in seen_lines:
                unique_lines.append(line)
                seen_lines.add(trimmed)
            elif trimmed:
                # 保留必要的重复（如结构标记）
                if trimmed.startswith('###') or trimmed.startswith('**'):
                    unique_lines.append(line)
            else:
                unique_lines.append(line)  # 保留空行用于格式
        
        # 添加性能指导
        performance_guidance = (
            "\n**优化目标：引导生成精确、相关、简洁的输出，减少冗余**"
        )
        
        optimized = '\n'.join(unique_lines)
        if performance_guidance not in optimized:
            optimized += performance_guidance
        
        return optimized
    
    def generate_template(self, requirements: List[str]) -> str:
        """
        根据需求生成新模板
        
        Args:
            requirements: 需求描述列表
            
        Returns:
            str: 生成的模板
        """
        template_parts = []
        
        # 角色定义
        template_parts.append("### 角色定义")
        template_parts.append("**您是一个专业、准确、可靠的AI助手**")
        template_parts.append("")
        
        # 核心指令
        template_parts.append("### 核心指令")
        for req in requirements:
            template_parts.append(f"**• {req}**")
        template_parts.append("")
        
        # 约束条件
        template_parts.append("### 约束条件")
        template_parts.extend(self.ethics_statements)
        template_parts.append("**• 输出应准确、相关、简洁**")
        template_parts.append("**• 避免主观臆断，基于事实和信息**")
        template_parts.append("")
        
        # 输出格式
        template_parts.append("### 输出格式")
        template_parts.append("**请根据具体任务要求采用合适的格式（如JSON、Markdown、纯文本）**")
        template_parts.append("**确保格式规范、结构清晰、易于解析**")
        template_parts.append("")
        
        # 示例参考
        template_parts.append("### 示例参考")
        template_parts.append("```")
        template_parts.append("输入：具体任务描述")
        template_parts.append("输出：符合要求的响应示例")
        template_parts.append("```")
        
        return '\n'.join(template_parts)


if __name__ == "__main__":
    # 示例用法
    optimizer = PromptTemplateOptimizer()
    
    # 示例需求
    sample_requirements = [
        "根据用户问题提供准确信息",
        "遵循安全与伦理约束",
        "输出结构清晰、格式规范"
    ]
    
    # 生成模板
    new_template = optimizer.generate_template(sample_requirements)
    print("生成的模板：")
    print(new_template)
    print(f"\n模板验证结果：{optimizer.validate_template(new_template)}")
