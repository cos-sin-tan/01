#!/usr/bin/env python3
"""
提示词模板解析器模块

该模块提供了解析提示词模板的功能，能够提取关键组件如角色定义、
任务指令、约束条件、输出格式等，并输出结构化的JSON数据。
"""

import json
import re
import asyncio
from pathlib import Path
from typing import Dict, List, Optional, Any, Pattern
from dataclasses import dataclass, asdict


class SecurityError(Exception):
    """安全异常类"""
    pass


@dataclass
class TemplateComponent:
    """模板组件数据类"""
    category: str
    content: str
    start_pos: int
    end_pos: int
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return asdict(self)


@dataclass
class ParseResult:
    """解析结果数据类"""
    components: List[TemplateComponent]
    metadata: Dict[str, Any]
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "components": [comp.to_dict() for comp in self.components],
            "metadata": self.metadata
        }


class SecurityScanner:
    """安全扫描器"""
    
    # 危险模式正则表达式
    DANGEROUS_PATTERNS: List[Pattern] = [
        re.compile(r\.\./|\.\.\\),  # 路径遍历
        re.compile(r'<script.*?>.*?</script>', re.IGNORECASE | re.DOTALL),  # XSS
        re.compile(r'eval\s*\(|exec\s*\(|__import__\s*\('),  # 危险函数
        re.compile(r'\b(password|secret|key)\s*[:=]', re.IGNORECASE),  # 敏感信息
    ]
    
    @classmethod
    def scan(cls, content: str) -> None:
        """
        扫描内容中的安全威胁
        
        Args:
            content: 要扫描的内容
            
        Raises:
            SecurityError: 如果检测到安全威胁
        """
        for pattern in cls.DANGEROUS_PATTERNS:
            if pattern.search(content):
                raise SecurityError(f"检测到潜在安全威胁: {pattern.pattern}")


class TemplateParser:
    """提示词模板解析器"""
    
    # 组件模式定义
    COMPONENT_PATTERNS: Dict[str, Pattern] = {
        "role_definition": re.compile(r'你是一个[^。]+[。]'),
        "task_instruction": re.compile(r'请[^。]+[。]|需求描述[：:][^\n]+'),
        "constraints": re.compile(r'约束[：:][^\n]+|必须遵守[：:][^\n]+'),
        "output_format": re.compile(r'输出[：:][^\n]+|格式[：:][^\n]+'),
    }
    
    def __init__(self) -> None:
        """初始化解析器"""
        self.security_scanner = SecurityScanner()
    
    def parse(self, template: str) -> Dict[str, Any]:
        """
        解析提示词模板
        
        Args:
            template: 提示词模板文本
            
        Returns:
            包含解析结果的字典
            
        Raises:
            SecurityError: 如果模板包含安全威胁
        """
        # 安全扫描
        self.security_scanner.scan(template)
        
        components: List[TemplateComponent] = []
        
        # 提取各个组件
        for category, pattern in self.COMPONENT_PATTERNS.items():
            for match in pattern.finditer(template):
                component = TemplateComponent(
                    category=category,
                    content=match.group().strip(),
                    start_pos=match.start(),
                    end_pos=match.end()
                )
                components.append(component)
        
        # 创建解析结果
        result = ParseResult(
            components=components,
            metadata={
                "template_length": len(template),
                "component_count": len(components),
                "file_path": None
            }
        )
        
        return result.to_dict()
    
    def parse_file(self, file_path: str) -> Dict[str, Any]:
        """
        解析提示词模板文件
        
        Args:
            file_path: 模板文件路径
            
        Returns:
            包含解析结果的字典
            
        Raises:
            FileNotFoundError: 如果文件不存在
            SecurityError: 如果文件内容包含安全威胁
        """
        path = Path(file_path)
        
        if not path.exists():
            raise FileNotFoundError(f"文件不存在: {file_path}")
        
        # 读取文件内容
        try:
            content = path.read_text(encoding='utf-8')
        except UnicodeDecodeError:
            # 尝试其他编码
            content = path.read_text(encoding='gbk')
        
        # 解析内容
        result = self.parse(content)
        
        # 更新元数据
        result["metadata"]["file_path"] = str(path.absolute())
        result["metadata"]["file_size"] = path.stat().st_size
        
        return result
    
    async def parse_async(self, template: str) -> Dict[str, Any]:
        """
        异步解析提示词模板
        
        Args:
            template: 提示词模板文本
            
        Returns:
            包含解析结果的字典
        """
        # 在后台线程中执行解析
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.parse, template)
    
    async def batch_parse_async(self, templates: List[str]) -> List[Dict[str, Any]]:
        """
        批量异步解析提示词模板
        
        Args:
            templates: 提示词模板列表
            
        Returns:
            解析结果列表
        """
        tasks = [self.parse_async(template) for template in templates]
        return await asyncio.gather(*tasks)


if __name__ == "__main__":
    # 示例用法
    parser = TemplateParser()
    
    example_template = """你是一个资深软件工程师。请根据以下需求编写代码。
    需求描述：构建一个用于分析现有提示词模板结构的解析器。
    输出格式：JSON格式，包含提取出的组件及其类别。"""
    
    result = parser.parse(example_template)
    print(json.dumps(result, ensure_ascii=False, indent=2))
