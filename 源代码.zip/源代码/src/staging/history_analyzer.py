import re
import json
from pathlib import Path
from typing import List, Dict, Any, Optional
from collections import Counter
import time


class FileValidator:
    """文件路径验证器，防止路径遍历攻击"""
    
    def __init__(self) -> None:
        self.unsafe_patterns = [
            r'\.\./',  # 目录遍历
            r'/etc/',   # 系统敏感目录
            r'/root/',  # root目录
            r'/var/log/',  # 日志目录
            r'~/'        # 用户目录
        ]
    
    def is_safe_path(self, filepath: str) -> bool:
        """检查路径是否安全"""
        normalized = str(Path(filepath).resolve())
        for pattern in self.unsafe_patterns:
            if re.search(pattern, normalized):
                return False
        return True
    
    def validate_files(self, directory: str, pattern: str) -> List[Path]:
        """验证并返回安全文件列表"""
        safe_files: List[Path] = []
        dir_path = Path(directory)
        
        if not dir_path.exists() or not dir_path.is_dir():
            return safe_files
        
        for file_path in dir_path.glob(pattern):
            if self.is_safe_path(str(file_path)):
                safe_files.append(file_path)
        
        return safe_files


class SecuritySanitizer:
    """安全清洗器，移除敏感信息和危险指令"""
    
    def __init__(self) -> None:
        self.dangerous_keywords = [
            'eval', 'exec', 'os.system', 'subprocess',
            'rm -rf', 'del ', 'format ', 'drop table',
            'union select', '<script>', 'javascript:'
        ]
    
    def sanitize(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """清洗数据，移除危险内容"""
        sanitized = data.copy()
        
        # 清洗提示词
        if 'prompt' in sanitized:
            prompt = sanitized['prompt']
            for keyword in self.dangerous_keywords:
                if keyword in prompt.lower():
                    prompt = re.sub(fr'(?i){re.escape(keyword)}', 
                                  '[高危指令已移除]', prompt)
            sanitized['prompt'] = prompt
        
        # 清洗关键词
        if 'keywords' in sanitized:
            keywords = sanitized['keywords']
            sanitized['keywords'] = [
                k for k in keywords 
                if k.lower() not in self.dangerous_keywords
            ]
        
        return sanitized


class PatternExtractor:
    """模式提取器，从Markdown中提取结构化数据"""
    
    def parse_markdown(self, content: str) -> Dict[str, Any]:
        """解析Markdown内容"""
        result: Dict[str, Any] = {
            'keywords': [],
            'constraints': [],
            'success': False,
            'raw_content': content[:500]  # 限制长度
        }
        
        # 提取关键词
        keyword_match = re.search(r'关键词[:：]\s*(.+)', content)
        if keyword_match:
            keywords_str = keyword_match.group(1).strip()
            result['keywords'] = [k.strip() for k in keywords_str.split(',')]
        
        # 提取约束
        constraint_match = re.search(r'约束[:：]\s*(\[.+\])', content, re.DOTALL)
        if constraint_match:
            try:
                constraints = json.loads(constraint_match.group(1))
                result['constraints'] = constraints
            except json.JSONDecodeError:
                result['constraints'] = []
        
        # 提取成功状态
        success_match = re.search(r'成功[:：]\s*(true|false)', content, re.IGNORECASE)
        if success_match:
            result['success'] = success_match.group(1).lower() == 'true'
        
        # 提取任务描述
        task_match = re.search(r'任务[:：]\s*(.+)', content)
        if task_match:
            result['task_description'] = task_match.group(1).strip()
        
        return result


class AnalysisSummary:
    """分析摘要生成器"""
    
    def generate(self, patterns: List[Dict[str, Any]]) -> Dict[str, Any]:
        """生成分析摘要"""
        if not patterns:
            return {
                'total_tasks': 0,
                'success_rate': 0.0,
                'keyword_frequency': {},
                'constraint_distribution': {},
                'common_patterns': []
            }
        
        # 统计基本信息
        total = len(patterns)
        success_count = sum(1 for p in patterns if p.get('success', False))
        success_rate = round((success_count / total) * 100, 2)
        
        # 关键词频率
        all_keywords = []
        for pattern in patterns:
            keywords = pattern.get('keywords', [])
            all_keywords.extend(keywords)
        keyword_freq = dict(Counter(all_keywords).most_common(10))
        
        # 约束分布
        constraint_types = []
        for pattern in patterns:
            constraints = pattern.get('constraints', [])
            if isinstance(constraints, list):
                for constraint in constraints:
                    if isinstance(constraint, dict):
                        constraint_types.append(constraint.get('type', 'unknown'))
        constraint_dist = dict(Counter(constraint_types).most_common())
        
        # 常见模式
        common_patterns = []
        success_patterns = [p for p in patterns if p.get('success', False)]
        if success_patterns:
            # 找出成功模式中的共同关键词
            success_keywords = []
            for pattern in success_patterns:
                success_keywords.extend(pattern.get('keywords', []))
            common_keywords = [
                k for k, v in Counter(success_keywords).items() 
                if v >= len(success_patterns) * 0.5  # 出现在50%以上的成功任务中
            ]
            if common_keywords:
                common_patterns.append({
                    'type': 'success_keywords',
                    'keywords': common_keywords
                })
        
        return {
            'total_tasks': total,
            'success_rate': success_rate,
            'keyword_frequency': keyword_freq,
            'constraint_distribution': constraint_dist,
            'common_patterns': common_patterns
        }


class HistoryAnalyzer:
    """历史经验分析器"""
    
    def __init__(self) -> None:
        self.validator = FileValidator()
        self.extractor = PatternExtractor()
        self.sanitizer = SecuritySanitizer()
        self.summary_gen = AnalysisSummary()
    
    def analyze(self, directory: str) -> Dict[str, Any]:
        """分析历史经验文件"""
        start_time = time.time()
        
        # 验证并获取文件
        files = self.validator.validate_files(directory, "temp_search_*.md")
        
        # 提取模式
        patterns: List[Dict[str, Any]] = []
        for file_path in files:
            try:
                content = file_path.read_text(encoding='utf-8')
                pattern = self.extractor.parse_markdown(content)
                pattern['file_name'] = file_path.name
                
                # 安全清洗
                sanitized_pattern = self.sanitizer.sanitize(pattern)
                patterns.append(sanitized_pattern)
                
                # 性能检查
                if time.time() - start_time > 30:
                    break
                    
            except Exception as e:
                continue
        
        # 生成摘要
        summary = self.summary_gen.generate(patterns)
        
        return {
            'summary': summary,
            'patterns': patterns,
            'files_processed': len(files),
            'processing_time': round(time.time() - start_time, 2)
        }


if __name__ == "__main__":
    analyzer = HistoryAnalyzer()
    result = analyzer.analyze(".")
    print(json.dumps(result, ensure_ascii=False, indent=2))