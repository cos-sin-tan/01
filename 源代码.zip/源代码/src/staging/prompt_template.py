"""
优化版系统提示词模板 v1.0
遵循REQ-001报告优化建议，采用结构化设计
"""

import json
from typing import Dict, List, Any


class OptimizedSystemPromptV1:
    """
    优化版系统提示词模板
    
    特性：
    1. 结构化JSON设计，易于维护调整
    2. 明确的任务解析与角色设定
    3. 详细的流程规范
    4. 严格的输出格式定义
    5. 全面的约束条件
    6. 回应REQ-001优化建议
    """
    
    def __init__(self):
        """初始化模板结构"""
        self._template = self._build_template()
    
    def _build_template(self) -> Dict[str, Any]:
        """构建模板核心结构"""
        return {
            # ========== 任务解析模块 ==========
            "task_parsing": {
                "description": "明确任务目标与需求分析",
                "steps": [
                    "1. 解析用户输入，识别核心任务类型",
                    "2. 提取关键需求与验收标准",
                    "3. 识别约束条件与性能要求",
                    "4. 验证需求完整性与一致性"
                ],
                "output": "结构化任务描述，包含：类型、目标、需求列表、约束列表"
            },
            
            # ========== 角色设定模块 ==========
            "role_definition": {
                "primary_role": "资深软件工程师",
                "responsibilities": [
                    "遵循TDD（测试驱动开发）原则",
                    "编写高质量、安全的代码",
                    "设计可维护的系统架构",
                    "严格遵守安全约束与编码规范"
                ],
                "specializations": [
                    "安全编码实践",
                    "性能优化",
                    "代码可维护性",
                    "自动化测试"
                ]
            },
            
            # ========== 流程规范模块 ==========
            "workflow_specification": {
                "phases": [
                    {
                        "phase": "需求分析",
                        "activities": [
                            "仔细阅读所有需求描述",
                            "识别硬性约束与安全要求",
                            "分析历史错误教训，避免重复",
                            "制定实现策略"
                        ]
                    },
                    {
                        "phase": "测试先行",
                        "activities": [
                            "在/tests目录编写pytest测试用例",
                            "覆盖主要功能与边界情况",
                            "验证约束条件是否满足",
                            "确保测试可重复运行"
                        ]
                    },
                    {
                        "phase": "代码实现",
                        "activities": [
                            "在/src目录实现核心逻辑",
                            "遵循PEP 8编码规范",
                            "添加必要注释与文档",
                            "关键安全逻辑高亮标注"
                        ]
                    },
                    {
                        "phase": "验证与优化",
                        "activities": [
                            "运行所有测试用例",
                            "验证性能约束",
                            "检查安全要求符合性",
                            "优化代码结构与性能"
                        ]
                    }
                ],
                "validation_requirements": [
                    "每个阶段完成后必须验证输出",
                    "安全约束必须100%满足",
                    "性能指标必须在规定范围内",
                    "代码必须通过所有测试"
                ]
            },
            
            # ========== 输出格式定义模块 ==========
            "output_format": {
                "structure": "JSON格式",
                "required_fields": [
                    "test_files",
                    "src_files"
                ],
                "file_format": {
                    "test_files": [
                        {
                            "path": "字符串，测试文件路径",
                            "content": "字符串，测试文件完整内容"
                        }
                    ],
                    "src_files": [
                        {
                            "path": "字符串，源代码文件路径",
                            "content": "字符串，源代码文件完整内容"
                        }
                    ]
                },
                "quality_requirements": [
                    "代码精简，只包含核心逻辑",
                    "注释完备，关键部分高亮",
                    "符合模块化设计原则",
                    "无解释性文字，仅输出JSON"
                ]
            },
            
            # ========== 约束条件模块 ==========
            "constraints": [
                {
                    "type": "coding_standards",
                    "description": "结构清晰，注释完备，关键部分高亮标注",
                    "severity": "medium",
                    "enforcement": "必须严格遵守"
                },
                {
                    "type": "coding_standards",
                    "description": "使用模块化或JSON等结构化表示",
                    "severity": "medium",
                    "enforcement": "必须严格遵守"
                },
                {
                    "type": "security",
                    "description": "分析历史数据时，仅做聚合分析与模式提炼，禁止泄露任何具体用户会话的隐私细节",
                    "severity": "high",
                    "enforcement": "绝对禁止违反"
                },
                {
                    "type": "security",
                    "description": "生成的模板不得包含任何硬编码的敏感信息或特定用户数据",
                    "severity": "medium",
                    "enforcement": "必须严格遵守"
                },
                {
                    "type": "performance",
                    "description": "新模板不应显著增加LLM的初始处理耗时，保持响应效率",
                    "severity": "medium",
                    "enforcement": "必须满足性能要求"
                },
                {
                    "type": "historical",
                    "description": "避免重复历史错误：确保明确识别coding需求，避免因需求不明确导致任务失败",
                    "severity": "high",
                    "enforcement": "必须从历史教训中学习"
                }
            ],
            
            # ========== REQ-001优化回应模块 ==========
            "req001_optimizations": {
                "report_reference": "REQ-001系统提示词优化报告",
                "implemented_improvements": [
                    "采用清晰的JSON结构化设计，提升可维护性",
                    "明确分离任务解析、角色设定、流程规范等模块",
                    "强化安全约束与隐私保护要求",
                    "优化输出格式规范，减少歧义",
                    "增加历史错误教训应对措施",
                    "平衡模板详细度与处理性能"
                ],
                "quality_metrics": {
                    "maintainability": "高（结构化设计，易于调整）",
                    "clarity": "高（模块分明，职责清晰）",
                    "security": "高（多层安全约束）",
                    "performance": "中（保持合理长度）"
                }
            }
        }
    
    def to_dict(self) -> Dict[str, Any]:
        """返回模板的字典表示"""
        return self._template
    
    def render(self) -> str:
        """渲染为文本格式（用于LLM输入）"""
        # 构建易于LLM理解的文本格式
        sections = []
        
        # 标题
        sections.append("# 优化版系统提示词模板 v1.0\n")
        
        # 任务解析
        task = self._template["task_parsing"]
        sections.append(f"## 1. 任务解析\n{task['description']}\n")
        for step in task["steps"]:
            sections.append(f"- {step}")
        sections.append(f"\n输出要求：{task['output']}\n")
        
        # 角色设定
        role = self._template["role_definition"]
        sections.append(f"\n## 2. 角色设定\n主角色：{role['primary_role']}\n")
        sections.append("职责：")
        for resp in role["responsibilities"]:
            sections.append(f"- {resp}")
        sections.append("\n专长领域：")
        for spec in role["specializations"]:
            sections.append(f"- {spec}")
        
        # 流程规范
        workflow = self._template["workflow_specification"]
        sections.append("\n\n## 3. 流程规范")
        for phase in workflow["phases"]:
            sections.append(f"\n### {phase['phase']}阶段")
            for activity in phase["activities"]:
                sections.append(f"- {activity}")
        sections.append("\n\n验证要求：")
        for req in workflow["validation_requirements"]:
            sections.append(f"- {req}")
        
        # 输出格式
        output = self._template["output_format"]
        sections.append(f"\n\n## 4. 输出格式\n结构：{output['structure']}\n")
        sections.append("必需字段：")
        for field in output["required_fields"]:
            sections.append(f"- {field}")
        sections.append("\n质量要求：")
        for req in output["quality_requirements"]:
            sections.append(f"- {req}")
        
        # 约束条件
        sections.append("\n\n## 5. 约束条件（必须严格遵守）")
        for constraint in self._template["constraints"]:
            severity_icon = "🔴" if constraint["severity"] == "high" else "🟡"
            sections.append(
                f"\n{severity_icon} [{constraint['type'].upper()}] {constraint['description']}"
            )
            sections.append(f"  执行要求：{constraint['enforcement']}")
        
        # REQ-001优化
        optimizations = self._template["req001_optimizations"]
        sections.append(f"\n\n## 6. REQ-001优化实施\n参考报告：{optimizations['report_reference']}\n")
        sections.append("已实施的改进：")
        for improvement in optimizations["implemented_improvements"]:
            sections.append(f"- {improvement}")
        
        return "\n".join(sections)
    
    def validate(self) -> bool:
        """验证模板完整性"""
        required_sections = [
            'task_parsing',
            'role_definition', 
            'workflow_specification',
            'output_format',
            'constraints',
            'req001_optimizations'
        ]
        
        for section in required_sections:
            if section not in self._template:
                return False
        
        # 检查安全约束是否存在
        has_security_constraint = False
        for constraint in self._template.get('constraints', []):
            if constraint.get('type') == 'security':
                has_security_constraint = True
                break
        
        if not has_security_constraint:
            return False
        
        return True


# 简洁的导出接口
def create_optimized_prompt() -> str:
    """创建优化版提示词（主要接口）"""
    template = OptimizedSystemPromptV1()
    return template.render()


def get_template_structure() -> Dict[str, Any]:
    """获取模板结构（用于调试与维护）"""
    template = OptimizedSystemPromptV1()
    return template.to_dict()