import ast
import math
import operator


class SecurityException(Exception):
    """安全异常，当检测到不安全操作时抛出"""
    pass


class SafeCalculator:
    """安全计算器，支持基本数学运算和常见数学函数"""
    
    # 允许的运算符
    _ALLOWED_OPERATORS = {
        ast.Add: operator.add,
        ast.Sub: operator.sub,
        ast.Mult: operator.mul,
        ast.Div: operator.truediv,
        ast.Pow: operator.pow,
        ast.USub: operator.neg,
        ast.UAdd: operator.pos,
    }
    
    # 允许的函数
    _ALLOWED_FUNCTIONS = {
        'sin': math.sin,
        'cos': math.cos,
        'tan': math.tan,
        'sqrt': math.sqrt,
        'log': math.log,
        'log10': math.log10,
        'exp': math.exp,
        'abs': abs,
        'pow': pow,
    }
    
    # 允许的常量
    _ALLOWED_CONSTANTS = {
        'pi': math.pi,
        'e': math.e,
    }
    
    # 禁止的属性和方法名
    _FORBIDDEN_NAMES = {
        '__import__', 'import', 'exec', 'eval', 'open',
        '__builtins__', '__globals__', '__locals__',
        '__code__', '__closure__', '__self__',
        'system', 'os', 'subprocess', 'sys',
        'lambda', 'def', 'class', 'raise', 'try',
        'except', 'finally', 'with', 'as', 'assert',
        'yield', 'async', 'await', 'del', 'global',
        'nonlocal', 'pass', 'break', 'continue',
    }
    
    def __init__(self):
        self._node_visitor = self._SafeNodeVisitor()
    
    def evaluate(self, expression: str) -> float:
        """安全地计算数学表达式"""
        if not expression or not expression.strip():
            raise ValueError("表达式不能为空")
        
        try:
            # 解析表达式为AST
            tree = ast.parse(expression.strip(), mode='eval')
        except SyntaxError as e:
            raise SyntaxError(f"表达式语法错误: {e}")
        
        # 安全检查
        self._node_visitor.visit(tree)
        
        # 编译和执行安全的AST
        code = compile(tree, '<string>', 'eval')
        
        # 创建安全的环境
        safe_env = {
            **self._ALLOWED_FUNCTIONS,
            **self._ALLOWED_CONSTANTS,
            '__builtins__': {},  # 清空内置函数
        }
        
        try:
            result = eval(code, safe_env)
            # 确保返回的是数字类型
            if not isinstance(result, (int, float)):
                raise ValueError(f"计算结果不是数字: {type(result).__name__}")
            return float(result)
        except ZeroDivisionError:
            raise
        except Exception as e:
            raise ValueError(f"计算错误: {e}")
    
    class _SafeNodeVisitor(ast.NodeVisitor):
        """AST节点访问器，用于安全检查"""
        
        def visit_Name(self, node):
            """检查变量名是否安全"""
            if node.id in SafeCalculator._FORBIDDEN_NAMES:
                raise SecurityException(f"禁止使用名称: {node.id}")
            
            # 检查是否在允许的常量中
            if node.id not in SafeCalculator._ALLOWED_CONSTANTS:
                # 如果不是常量，检查是否是函数调用的一部分
                parent = getattr(node, 'parent', None)
                if not (isinstance(parent, ast.Call) and parent.func == node):
                    # 如果不是函数调用，也不是常量，则不允许
                    if node.id not in SafeCalculator._ALLOWED_FUNCTIONS:
                        raise SecurityException(f"未定义的名称: {node.id}")
            
            self.generic_visit(node)
        
        def visit_Call(self, node):
            """检查函数调用是否安全"""
            if not isinstance(node.func, ast.Name):
                raise SecurityException("只允许简单的函数调用")
            
            func_name = node.func.id
            if func_name not in SafeCalculator._ALLOWED_FUNCTIONS:
                raise SecurityException(f"禁止的函数调用: {func_name}")
            
            # 为参数节点设置父节点引用，便于安全检查
            for arg in node.args:
                arg.parent = node
            
            self.generic_visit(node)
        
        def visit_Attribute(self, node):
            """禁止属性访问"""
            raise SecurityException("禁止属性访问")
        
        def visit_Subscript(self, node):
            """禁止下标访问"""
            raise SecurityException("禁止下标访问")
        
        def visit_Compare(self, node):
            """禁止比较操作"""
            raise SecurityException("禁止比较操作")
        
        def visit_BoolOp(self, node):
            """禁止布尔操作"""
            raise SecurityException("禁止布尔操作")
        
        def visit_UnaryOp(self, node):
            """检查一元操作符"""
            if type(node.op) not in SafeCalculator._ALLOWED_OPERATORS:
                raise SecurityException(f"禁止的一元操作符: {type(node.op).__name__}")
            self.generic_visit(node)
        
        def visit_BinOp(self, node):
            """检查二元操作符"""
            if type(node.op) not in SafeCalculator._ALLOWED_OPERATORS:
                raise SecurityException(f"禁止的二元操作符: {type(node.op).__name__}")
            self.generic_visit(node)
        
        def visit_Constant(self, node):
            """允许常量"""
            # 只允许数字常量
            if not isinstance(node.value, (int, float)):
                raise SecurityException(f"禁止的常量类型: {type(node.value).__name__}")
            self.generic_visit(node)
        
        def generic_visit(self, node):
            """通用访问方法，设置父节点引用"""
            # 为子节点设置父节点引用
            for child in ast.iter_child_nodes(node):
                child.parent = node
            super().generic_visit(node)


# 创建全局实例
_calculator = SafeCalculator()


def safe_evaluate(expression: str) -> float:
    """安全计算表达式的便捷函数"""
    return _calculator.evaluate(expression)


if __name__ == "__main__":
    # 提供简单的命令行界面用于测试
    import sys
    
    if len(sys.argv) > 1:
        expression = " ".join(sys.argv[1:])
        try:
            result = safe_evaluate(expression)
            print(f"{expression} = {result}")
        except Exception as e:
            print(f"错误: {e}")
    else:
        print("安全计算器")
        print("用法: python safe_calculator.py <表达式>")
        print("示例: python safe_calculator.py '2 + 3 * sin(pi/2)'")
        print("\n支持的函数:", ", ".join(sorted(SafeCalculator._ALLOWED_FUNCTIONS.keys())))
        print("支持的常量:", ", ".join(sorted(SafeCalculator._ALLOWED_CONSTANTS.keys())))