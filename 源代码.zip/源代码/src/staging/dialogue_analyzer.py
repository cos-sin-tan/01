import json
from typing import List, Dict, Any, Optional
import re


class DialogueAnalyzer:
    """历史对话分析模块"""
    
    def __init__(self) -> None:
        self.common_failure_patterns = [
            "忽略关键约束",
            "格式错误",
            "信息不完整",
            "逻辑错误",
            "重复内容",
            "答非所问"
        ]
    
    def analyze(self, dialogue_history: List[Dict[str, Any]]) -> Dict[str, Any]:
        """分析对话历史"""
        
        if not isinstance(dialogue_history, list):
            raise ValueError("对话历史必须是列表格式")
        
        if not dialogue_history:
            return self._generate_empty_result()
        
        user_messages = [msg for msg in dialogue_history if msg.get("role") == "user"]
        assistant_messages = [msg for msg in dialogue_history if msg.get("role") == "assistant"]
        
        if not user_messages:
            return self._generate_empty_result()
        
        latest_user_msg = user_messages[-1]
        latest_assistant_msg = assistant_messages[-1] if assistant_messages else None
        
        target_evaluation = self._evaluate_target(latest_user_msg, latest_assistant_msg, len(dialogue_history))
        user_intent = self._identify_intent(latest_user_msg["content"])
        response_quality = self._evaluate_response_quality(latest_assistant_msg)
        information_completeness = self._evaluate_information_completeness(latest_user_msg, latest_assistant_msg)
        failure_patterns = self._identify_failure_patterns(latest_user_msg, latest_assistant_msg)
        
        return {
            "target_evaluation": target_evaluation,
            "user_intent": user_intent,
            "response_quality": response_quality,
            "information_completeness": information_completeness,
            "failure_patterns": failure_patterns
        }
    
    def _generate_empty_result(self) -> Dict[str, Any]:
        """生成空结果"""
        return {
            "target_evaluation": "无法评估：对话历史为空",
            "user_intent": "无法识别",
            "response_quality": 0.0,
            "information_completeness": 0.0,
            "failure_patterns": ["缺少对话内容"]
        }
    
    def _evaluate_target(self, user_msg: Dict[str, Any], 
                         assistant_msg: Optional[Dict[str, Any]], 
                         turn_count: int) -> str:
        """评估目标达成情况"""
        
        if not assistant_msg:
            return "目标未达成：缺少助手回复"
        
        user_content = user_msg.get("content", "")
        assistant_content = assistant_msg.get("content", "")
        
        if turn_count > 2:
            return f"多轮对话（{turn_count}轮），需综合评估"
        
        if not assistant_content.strip():
            return "目标未达成：助手回复为空"
        
        if len(assistant_content) < 10:
            return "目标部分达成：回复过于简短"
        
        return "目标基本达成：有实质性回复"
    
    def _identify_intent(self, user_content: str) -> str:
        """识别用户意图"""
        
        content_lower = user_content.lower()
        
        intent_patterns = {
            "创作": ["写", "创作", "生成", "作诗", "作文"],
            "解释": ["解释", "说明", "什么是", "如何理解"],
            "计算": ["计算", "求解", "等于多少", "结果"],
            "推荐": ["推荐", "建议", "有哪些", "什么好"],
            "代码": ["代码", "程序", "函数", "脚本", "python", "java"],
            "问答": ["为什么", "怎么", "如何", "能否"]
        }
        
        for intent, patterns in intent_patterns.items():
            for pattern in patterns:
                if pattern in content_lower:
                    return intent
        
        return "通用咨询"
    
    def _evaluate_response_quality(self, assistant_msg: Optional[Dict[str, Any]]) -> float:
        """评估回复质量（0-1）"""
        
        if not assistant_msg:
            return 0.0
        
        content = assistant_msg.get("content", "")
        
        if not content.strip():
            return 0.0
        
        score = 0.5
        
        if len(content) > 50:
            score += 0.2
        
        sentences = re.split(r'[.!?。！？]', content)
        if len(sentences) > 2:
            score += 0.1
        
        if any(keyword in content for keyword in ["首先", "其次", "另外", "例如", "比如"]):
            score += 0.1
        
        if "\n" in content:
            score += 0.1
        
        return min(score, 1.0)
    
    def _evaluate_information_completeness(self, 
                                          user_msg: Dict[str, Any], 
                                          assistant_msg: Optional[Dict[str, Any]]) -> float:
        """评估信息完整性（0-1）"""
        
        if not assistant_msg:
            return 0.0
        
        user_content = user_msg.get("content", "")
        assistant_content = assistant_msg.get("content", "")
        
        score = 0.3
        
        user_requirements = re.findall(r'要求[：:](.*?)(?=\n|$)', user_content)
        if user_requirements:
            requirements = user_requirements[0]
            requirement_count = len(re.findall(r'[0-9][.:、]', requirements))
            
            if requirement_count > 0:
                matched = 0
                for i in range(1, requirement_count + 1):
                    if f"{i}." in requirements or f"{i}:" or f"{i}、" in requirements:
                        matched += 1
                
                if matched > 0:
                    score += min(matched / requirement_count * 0.5, 0.5)
        
        question_words = ["吗", "什么", "如何", "为什么", "怎样"]
        if any(word in user_content for word in question_words):
            if any(word in assistant_content for word in ["是", "可以", "需要", "应该", "因为"]):
                score += 0.2
        
        return min(score, 1.0)
    
    def _identify_failure_patterns(self, 
                                  user_msg: Dict[str, Any], 
                                  assistant_msg: Optional[Dict[str, Any]]) -> List[str]:
        """识别失败模式"""
        
        failure_patterns = []
        
        if not assistant_msg:
            failure_patterns.append("缺少助手回复")
            return failure_patterns
        
        user_content = user_msg.get("content", "")
        assistant_content = assistant_msg.get("content", "")
        
        if "要求" in user_content and "要求" not in assistant_content:
            constraints = re.findall(r'要求[：:](.*?)(?=\n|$)', user_content)
            if constraints:
                for constraint in constraints[0].split(","):
                    if constraint.strip() and constraint.strip() not in assistant_content:
                        failure_patterns.append("忽略关键约束")
                        break
        
        format_keywords = ["json", "xml", "yaml", "表格", "列表", "markdown"]
        for keyword in format_keywords:
            if keyword in user_content.lower() and keyword not in assistant_content.lower():
                if keyword == "json" and not self._is_json_like(assistant_content):
                    failure_patterns.append("格式错误")
                elif keyword == "表格" and "|" not in assistant_content and "\t" not in assistant_content:
                    failure_patterns.append("格式错误")
                break
        
        if len(assistant_content) < 20 and len(user_content) > 50:
            failure_patterns.append("信息不完整")
        
        if assistant_content.count(" ") > len(assistant_content) * 0.3:
            failure_patterns.append("重复内容")
        
        return list(set(failure_patterns))
    
    def _is_json_like(self, text: str) -> bool:
        """检查文本是否类似JSON格式"""
        text = text.strip()
        return (text.startswith('{') and text.endswith('}')) or \
               (text.startswith('[') and text.endswith(']'))
