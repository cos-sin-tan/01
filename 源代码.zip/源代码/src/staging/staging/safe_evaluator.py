import ast
import operator


class SafeEvaluator:
    """A safe expression evaluator that only allows basic arithmetic operations."""
    
    # Allowed operators - removed Pow and Mod due to security risks
    _allowed_operators = {
        ast.Add: operator.add,
        ast.Sub: operator.sub,
        ast.Mult: operator.mul,
        ast.Div: operator.truediv,
        ast.USub: operator.neg,
    }
    
    # Allowed node types - added ast.Expr for expression root nodes
    _allowed_nodes = (
        ast.Expression,
        ast.Expr,
        ast.BinOp,
        ast.UnaryOp,
        ast.Num,
        ast.Constant,
    )
    
    def evaluate(self, expression: str):
        """Safely evaluate a mathematical expression."""
        if not expression or expression.isspace():
            raise ValueError("Expression cannot be empty or whitespace only")
        
        try:
            # Parse the expression into an AST
            tree = ast.parse(expression, mode='eval')
        except SyntaxError:
            raise ValueError("Invalid syntax in expression")
        
        # Validate the AST
        self._validate_ast(tree)
        
        # Evaluate the AST safely
        return self._eval_node(tree.body)
    
    def _validate_ast(self, node):
        """Validate that the AST only contains allowed nodes and operations."""
        # Check node type
        if not isinstance(node, self._allowed_nodes):
            raise ValueError(f"Disallowed node type: {type(node).__name__}")
        
        # Additional validation for specific node types
        if isinstance(node, ast.Constant):
            # Only allow numeric constants (int, float)
            if not isinstance(node.value, (int, float)):
                raise ValueError(f"Disallowed constant type: {type(node.value).__name__}")
        elif isinstance(node, ast.Num):
            # ast.Num is only used in Python <3.8, ensure it's numeric
            if not isinstance(node.n, (int, float)):
                raise ValueError(f"Disallowed constant type: {type(node.n).__name__}")
        elif isinstance(node, ast.BinOp):
            # Check for disallowed operators
            op_type = type(node.op)
            if op_type not in self._allowed_operators:
                raise ValueError(f"Disallowed binary operator: {op_type.__name__}")
        elif isinstance(node, ast.UnaryOp):
            # Check for disallowed unary operators
            op_type = type(node.op)
            if op_type not in self._allowed_operators:
                raise ValueError(f"Disallowed unary operator: {op_type.__name__}")
        
        # Recursively validate child nodes
        for child in ast.iter_child_nodes(node):
            self._validate_ast(child)
    
    def _eval_node(self, node):
        """Recursively evaluate an AST node."""
        if isinstance(node, ast.Num) or (isinstance(node, ast.Constant) and isinstance(node.value, (int, float))):
            # Handle both ast.Num (Python <3.8) and ast.Constant (Python >=3.8)
            if isinstance(node, ast.Num):
                return node.n
            else:
                return node.value
        elif isinstance(node, ast.UnaryOp):
            operand = self._eval_node(node.operand)
            op_type = type(node.op)
            if op_type not in self._allowed_operators:
                raise ValueError(f"Disallowed unary operator: {op_type.__name__}")
            return self._allowed_operators[op_type](operand)
        elif isinstance(node, ast.BinOp):
            left = self._eval_node(node.left)
            right = self._eval_node(node.right)
            op_type = type(node.op)
            if op_type not in self._allowed_operators:
                raise ValueError(f"Disallowed binary operator: {op_type.__name__}")
            return self._allowed_operators[op_type](left, right)
        elif isinstance(node, ast.Expr):
            # Handle ast.Expr nodes by evaluating their value attribute
            return self._eval_node(node.value)
        else:
            # This should not happen if _validate_ast is working correctly
            raise ValueError(f"Unexpected node type during evaluation: {type(node).__name__}")


# Example usage for testing
if __name__ == "__main__":
    evaluator = SafeEvaluator()
    
    # Test basic arithmetic
    print(f"2 + 3 = {evaluator.evaluate('2 + 3')}")  # Should print: 2 + 3 = 5
    print(f"10 / 2 = {evaluator.evaluate('10 / 2')}")  # Should print: 10 / 2 = 5.0
    print(f"-5 = {evaluator.evaluate('-5')}")  # Should print: -5 = -5
    
    # Test complex expression
    print(f"(2 + 3) * 4 = {evaluator.evaluate('(2 + 3) * 4')}")  # Should print: (2 + 3) * 4 = 20
    
    # Test error handling
    try:
        evaluator.evaluate("2 ** 3")
    except ValueError as e:
        print(f"Expected error for disallowed operator: {e}")
    
    try:
        evaluator.evaluate("")
    except ValueError as e:
        print(f"Expected error for empty expression: {e}")
