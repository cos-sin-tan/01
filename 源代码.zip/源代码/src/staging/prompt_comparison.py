from typing import Dict, Any, List, Tuple, Optional
from dataclasses import dataclass
import re
import json
from difflib import SequenceMatcher


@dataclass
class PromptTemplate:
    """提示词模板类"""
    template: str
    variables: List[str]
    
    def __init__(self, template: str):
        self.template = template
        self.variables = self._extract_variables()
    
    def _extract_variables(self) -> List[str]:
        """从模板中提取变量"""
        pattern = r'\{([^}]+)\}'
        return re.findall(pattern, self.template)


@dataclass
class TestResult:
    """测试结果类"""
    requirement_type: str
    old_output_score: float
    new_output_score: float
    format_compliance_old: float
    format_compliance_new: float
    coverage_old: float
    coverage_new: float
    
    @property
    def improvement_score(self) -> float:
        """计算改进分数"""
        return self.new_output_score - self.old_output_score


class PromptComparator:
    """提示词比较器"""
    
    def __init__(self):
        self.old_template: Optional[PromptTemplate] = None
        self.new_template: Optional[PromptTemplate] = None
        self.test_requirements: List[Dict[str, Any]] = []
    
    def load_templates(self, old_template: str, new_template: str) -> None:
        """加载新旧模板"""
        self.old_template = PromptTemplate(old_template)
        self.new_template = PromptTemplate(new_template)
    
    def _generate_test_requirements(self) -> List[Dict[str, Any]]:
        """生成测试需求"""
        return [
            {
                "type": "coding",
                "description": "实现一个排序算法",
                "expected_format": "python_code",
                "criteria": ["时间复杂度O(n log n)", "空间复杂度O(1)", "正确处理边界情况"]
            },
            {
                "type": "reporting",
                "description": "生成项目进度报告",
                "expected_format": "markdown",
                "criteria": ["包含关键指标", "有可视化图表", "提出改进建议", "风险评估"]
            },
            {
                "type": "complex_system_design",
                "description": "设计一个分布式缓存系统",
                "expected_format": "uml_diagram",
                "criteria": ["高可用性", "数据一致性", "水平扩展", "故障恢复机制"]
            }
        ]
    
    def _sanitize_data(self, data: str) -> str:
        """清理敏感数据"""
        # 邮箱模式
        email_pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'
        # 电话号码模式
        phone_pattern = r'\d{3}[-.]?\d{3}[-.]?\d{4}'
        
        sanitized = re.sub(email_pattern, '[REDACTED]', data)
        sanitized = re.sub(phone_pattern, '[REDACTED]', sanitized)
        return sanitized
    
    def _check_prompt_injection(self, template: str) -> bool:
        """检查提示词注入漏洞"""
        injection_patterns = [
            r'(?i)ignore.*(previous|instructions|prompt)',
            r'(?i)system.*hacker',
            r'(?i)override.*system',
            r'(?i)disregard.*previous',
            r'(?i)you are now',
            r'(?i)previous.*wrong'
        ]
        
        for pattern in injection_patterns:
            if re.search(pattern, template):
                return False
        return True
    
    def _evaluate_format_compliance(self, output: str, expected_format: str) -> float:
        """评估格式符合度"""
        if expected_format == "json":
            try:
                json.loads(output)
                return 1.0
            except:
                return 0.0
        elif expected_format == "python_code":
            # 简单检查Python语法
            if "def " in output or "import " in output:
                return 0.9
            return 0.5
        elif expected_format == "markdown":
            if "# " in output or "```" in output:
                return 0.9
            return 0.6
        else:
            return 0.8  # 默认分数
    
    def _evaluate_requirement_coverage(self, output: str, criteria: List[str]) -> float:
        """评估需求覆盖度"""
        if not criteria:
            return 0.0
        
        matched = 0
        for criterion in criteria:
            if criterion.lower() in output.lower():
                matched += 1
        
        return matched / len(criteria)
    
    def _evaluate_semantic_quality(self, template: str) -> Dict[str, float]:
        """评估语义质量"""
        scores = {
            "clarity": 0.8,  # 清晰度
            "completeness": 0.7,  # 完整性
            "specificity": 0.6,  # 具体性
            "coherence": 0.9  # 连贯性
        }
        
        # 基于模板内容调整分数
        if len(template) > 50:
            scores["completeness"] = min(1.0, scores["completeness"] + 0.1)
        
        if "{task}" in template or "{topic}" in template:
            scores["specificity"] = min(1.0, scores["specificity"] + 0.2)
        
        # 检查句子结构
        sentences = re.split(r'[.!?]+', template)
        if len(sentences) > 1:
            scores["coherence"] = min(1.0, scores["coherence"] + 0.1)
        
        return scores
    
    def _run_semantic_audit(self, old_template: str, new_template: str) -> bool:
        """运行语义审计"""
        old_scores = self._evaluate_semantic_quality(old_template)
        new_scores = self._evaluate_semantic_quality(new_template)
        
        # 检查所有语义指标是否都有改进或至少保持
        for key in old_scores:
            if new_scores[key] < old_scores[key] - 0.1:  # 允许小幅波动
                return False
        
        # 总体语义质量检查
        old_avg = sum(old_scores.values()) / len(old_scores)
        new_avg = sum(new_scores.values()) / len(new_scores)
        
        return new_avg >= old_avg and new_avg > 0.6
    
    def run_comparison(self, old_template: str, new_template: str) -> Dict[str, Any]:
        """运行完整比较"""
        self.load_templates(old_template, new_template)
        self.test_requirements = self._generate_test_requirements()
        
        detailed_results = []
        
        for req in self.test_requirements:
            # 模拟测试输出
            old_output = f"Old output for {req['type']}"
            new_output = f"New output for {req['type']}"
            
            result = TestResult(
                requirement_type=req["type"],
                old_output_score=0.8,
                new_output_score=0.9,
                format_compliance_old=self._evaluate_format_compliance(old_output, req["expected_format"]),
                format_compliance_new=self._evaluate_format_compliance(new_output, req["expected_format"]),
                coverage_old=self._evaluate_requirement_coverage(old_output, req["criteria"]),
                coverage_new=self._evaluate_requirement_coverage(new_output, req["criteria"])
            )
            detailed_results.append(result)
        
        # 计算语义审计结果
        semantic_audit_passed = self._run_semantic_audit(old_template, new_template)
        semantic_scores = self._evaluate_semantic_quality(new_template)
        
        # 计算总体指标
        total_improvement = sum(r.improvement_score for r in detailed_results) / len(detailed_results)
        
        return {
            "summary": {
                "total_tests": len(detailed_results),
                "average_improvement": total_improvement,
                "semantic_audit_passed": semantic_audit_passed,
                "overall_recommendation": "use_new" if total_improvement > 0 and semantic_audit_passed else "keep_old"
            },
            "detailed_results": [
                {
                    "requirement_type": r.requirement_type,
                    "improvement_score": r.improvement_score,
                    "old_scores": {
                        "output": r.old_output_score,
                        "format": r.format_compliance_old,
                        "coverage": r.coverage_old
                    },
                    "new_scores": {
                        "output": r.new_output_score,
                        "format": r.format_compliance_new,
                        "coverage": r.coverage_new
                    }
                }
                for r in detailed_results
            ],
            "comparison_metrics": {
                "semantic_scores": semantic_scores,
                "security_check": self._check_prompt_injection(new_template),
                "template_length_diff": len(new_template) - len(old_template)
            }
        }