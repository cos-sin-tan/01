#!/usr/bin/env python3
"""
Prompt Optimizer Module

This module provides functionality to optimize prompt templates for AI systems.
It includes security checks, performance optimizations, and follows best practices.
"""

import re
import json
from typing import Dict, List, Optional, Tuple, Any
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class PromptOptimizer:
    """
    A class to optimize prompt templates with security and performance considerations.
    """
    
    # List of high-risk functions/patterns to detect and warn about
    HIGH_RISK_PATTERNS = [
        r'\beval\s*\(',
        r'\bexec\s*\(',
        r'\b__import__\s*\(',
        r'\bopen\s*\([^)]*\b(r|w|a)\+?b?\b',
        r'\b(subprocess|os|sys)\.',
        r'\binput\s*\(',
    ]
    
    def __init__(self, template: str):
        """
        Initialize the PromptOptimizer with a template string.
        
        Args:
            template (str): The prompt template to optimize.
        """
        self.template = template
        self.optimized_template = template
        self.warnings: List[str] = []
        self.errors: List[str] = []
    
    def check_security(self) -> bool:
        """
        Perform security checks on the template.
        
        Returns:
            bool: True if no high-risk patterns are found, False otherwise.
        """
        found_issues = False
        for pattern in self.HIGH_RISK_PATTERNS:
            if re.search(pattern, self.template, re.IGNORECASE):
                self.errors.append(
                    f"High-risk pattern detected: '{pattern}' found in template. Optimization aborted."
                )
                found_issues = True
        
        # Check for excessive length which might indicate injection attempts
        if len(self.template) > 10000:
            self.warnings.append(
                "Template is unusually long. Consider breaking it down for better performance."
            )
        
        return not found_issues
    
    def optimize_performance(self) -> None:
        """
        Apply performance optimizations to the template.
        Preserves empty lines, code indentation, and Markdown formatting.
        """
        # Remove trailing whitespace from each line, but keep empty lines
        lines = self.template.split('\n')
        cleaned_lines = [line.rstrip() for line in lines]
        self.optimized_template = '\n'.join(cleaned_lines)
        
        # Do NOT replace multiple spaces/tabs with single space,
        # as this would break code indentation and Markdown tables.
        # The above rstrip() already removes trailing spaces/tabs.
    
    def validate_syntax(self) -> bool:
        """
        Validate basic template syntax.
        Supports both Python str.format and Jinja2 style templates.
        
        Returns:
            bool: True if syntax appears valid, False otherwise.
        """
        # Check for mismatched braces in both {var} and {{ var }} styles
        # Count opening and closing braces
        open_braces = len(re.findall(r'\{', self.template))
        close_braces = len(re.findall(r'\}', self.template))
        
        if open_braces != close_braces:
            self.errors.append(f"Mismatched braces: {open_braces} opening vs {close_braces} closing braces.")
            return False
        
        # Additional validation: check for unclosed Jinja2 comments or tags
        # This is a basic check; more comprehensive validation would require a full parser.
        jinja_blocks = ['{{', '}}', '{%', '%}', '{#', '#}']
        for i in range(0, len(jinja_blocks), 2):
            open_tag = jinja_blocks[i]
            close_tag = jinja_blocks[i + 1]
            open_count = self.template.count(open_tag)
            close_count = self.template.count(close_tag)
            if open_count != close_count:
                self.errors.append(f"Mismatched Jinja2 tags: {open_tag}...{close_tag}")
                return False
        
        return True
    
    def optimize(self) -> Dict[str, Any]:
        """
        Run the complete optimization pipeline.
        
        Returns:
            Dict containing optimization results and status.
        """
        logger.info("Starting prompt optimization...")
        
        # Reset optimized template to original before starting
        self.optimized_template = self.template
        
        # Step 1: Security check - if fails, abort optimization
        security_ok = self.check_security()
        if not security_ok:
            logger.warning("Security check failed. Optimization aborted.")
            return self._build_result(False)
        
        # Step 2: Syntax validation
        syntax_ok = self.validate_syntax()
        if not syntax_ok:
            logger.warning("Syntax validation failed. Optimization aborted.")
            return self._build_result(False)
        
        # Step 3: Performance optimization (only if security and syntax passed)
        self.optimize_performance()
        
        # Step 4: Calculate metrics
        original_length = len(self.template)
        optimized_length = len(self.optimized_template)
        reduction = ((original_length - optimized_length) / original_length * 100) \
            if original_length > 0 else 0
        
        return self._build_result(True, original_length, optimized_length, reduction)
    
    def _build_result(self, success: bool, 
                      original_length: int = 0, 
                      optimized_length: int = 0, 
                      reduction: float = 0.0) -> Dict[str, Any]:
        """
        Build the result dictionary.
        
        Args:
            success: Whether optimization was successful.
            original_length: Length of original template.
            optimized_length: Length of optimized template.
            reduction: Percentage reduction in length.
        
        Returns:
            Dict with optimization results.
        """
        result = {
            "success": success,
            "original_template": self.template,
            "optimized_template": self.optimized_template,
            "warnings": self.warnings,
            "errors": self.errors,
            "metrics": {
                "original_length": original_length,
                "optimized_length": optimized_length,
                "reduction_percentage": round(reduction, 2)
            }
        }
        
        logger.info(f"Optimization complete. Success: {result['success']}")
        return result


def optimize_prompt(template: str) -> Dict[str, Any]:
    """
    Convenience function to optimize a prompt template.
    
    Args:
        template (str): The prompt template to optimize.
        
    Returns:
        Dict containing optimization results.
    """
    optimizer = PromptOptimizer(template)
    return optimizer.optimize()


if __name__ == "__main__":
    # Example usage
    example_template = """
    You are a helpful AI assistant.
    
    Please help with: {user_query}
    
    Context: {context}
    """
    
    result = optimize_prompt(example_template)
    print(json.dumps(result, indent=2))