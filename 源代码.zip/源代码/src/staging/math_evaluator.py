#!/usr/bin/env python3
"""Safe mathematical expression evaluator using eval with strict input validation."""

import re
from typing import Dict, Any


def validate_expression(expression: str) -> None:
    """Validate the input expression using a whitelist approach.
    
    Args:
        expression: The input string to validate.
        
    Raises:
        ValueError: If the expression contains invalid characters or is empty.
    """
    if not expression or not expression.strip():
        raise ValueError("Empty expression")
    
    expression = expression.strip()
    
    # Whitelist of allowed characters: digits, basic operators, parentheses, decimal point, and spaces
    allowed_pattern = r'^[\d\s+\-*/%().\^]+$'
    
    # Replace ** with ^ for pattern matching, then check
    temp_expr = expression.replace('**', '^')
    
    if not re.match(allowed_pattern, temp_expr):
        raise ValueError("Invalid characters in expression. Only numbers, basic operators (+ - * / % **), parentheses, and decimal points are allowed.")
    
    # Additional safety: ensure no consecutive operators that could indicate malicious patterns
    operator_pattern = r'[+\-*/%^]{2,}'
    if re.search(operator_pattern, temp_expr):
        raise ValueError("Invalid expression: consecutive operators")


def evaluate_expression(expression: str) -> float:
    """Safely evaluate a mathematical expression.
    
    Args:
        expression: The mathematical expression to evaluate.
        
    Returns:
        The result of the evaluation as a float.
        
    Raises:
        ValueError: If the expression is invalid or contains unsafe content.
        NameError: If the expression contains variables or function calls.
        SyntaxError: If the expression has syntax errors.
    """
    validate_expression(expression)
    
    # Create a restricted namespace for eval
    safe_globals: Dict[str, Any] = {
        '__builtins__': {},
        'abs': abs,
        'round': round,
        'pow': pow,
    }
    
    safe_locals: Dict[str, Any] = {}
    
    try:
        # Replace ^ with ** for Python evaluation
        expression = expression.replace('^', '**')
        result = eval(expression, safe_globals, safe_locals)
        return float(result) if isinstance(result, (int, float)) else result
    except SyntaxError as e:
        raise ValueError(f"Invalid expression syntax: {str(e)}") from e
    except ZeroDivisionError as e:
        raise ValueError("Division by zero") from e
    except Exception as e:
        raise ValueError(f"Error evaluating expression: {str(e)}") from e


def main() -> None:
    """Main function to run the expression evaluator interactively."""
    print("Mathematical Expression Evaluator")
    print("Enter a mathematical expression or 'exit' to quit.")
    print("Allowed: numbers, +, -, *, /, %, **, ^, (), decimal points")
    print("Example: 2 + 3 * (4 - 1)")
    
    while True:
        try:
            user_input = input("\nExpression: ").strip()
            
            if user_input.lower() == 'exit':
                print("Goodbye!")
                break
            
            result = evaluate_expression(user_input)
            print(f"Result: {result}")
            
        except ValueError as e:
            print(f"Error: {e}")
        except KeyboardInterrupt:
            print("\n\nGoodbye!")
            break
        except EOFError:
            print("\n\nGoodbye!")
            break


if __name__ == "__main__":
    main()
