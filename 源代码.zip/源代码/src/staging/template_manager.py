import os
import re
from typing import Dict, List, Optional, Any
import html


class TemplateValidationError(Exception):
    """模板验证错误"""
    pass


class TemplateVersionError(Exception):
    """模板版本错误"""
    pass


class TemplateManager:
    """提示词模板管理器"""
    
    def __init__(self) -> None:
        """初始化模板管理器"""
        self.templates: Dict[str, Dict[str, str]] = {}
        self.current_versions: Dict[str, str] = {}
        self.version_history: Dict[str, List[str]] = {}
        
        # 危险模式检测
        self.dangerous_patterns = [
            r'__import__\s*\(',
            r'eval\s*\(',
            r'exec\s*\(',
            r'compile\s*\(',
            r'open\s*\(',
            r'os\.system\s*\(',
            r'subprocess\.',
            r'\bimport\s+os\b',
            r'\bfrom\s+os\b',
            r'\bimport\s+subprocess\b'
        ]
    
    def load_template(self, template_name: str, version: str, file_path: str) -> None:
        """
        加载模板文件
        
        Args:
            template_name: 模板名称
            version: 版本号
            file_path: 模板文件路径
        
        Raises:
            TemplateValidationError: 模板验证失败
        """
        # 验证输入
        if not template_name or not version or not file_path:
            raise TemplateValidationError("Invalid input parameters")
        
        # 检查文件是否存在
        if not os.path.exists(file_path):
            raise TemplateValidationError(f"Template file not found: {file_path}")
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
        except Exception as e:
            raise TemplateValidationError(f"Failed to read template file: {str(e)}")
        
        # 验证模板内容
        self._validate_template_content(content)
        
        # 存储模板
        if template_name not in self.templates:
            self.templates[template_name] = {}
            self.version_history[template_name] = []
        
        self.templates[template_name][version] = content
        
        # 更新版本历史
        if version not in self.version_history[template_name]:
            self.version_history[template_name].append(version)
        
        # 设置当前版本（如果是第一个版本）
        if template_name not in self.current_versions:
            self.current_versions[template_name] = version
    
    def apply_template(self, template_name: str, version: Optional[str] = None, 
                      data: Optional[Dict[str, Any]] = None) -> str:
        """
        应用模板生成结果
        
        Args:
            template_name: 模板名称
            version: 版本号（None则使用当前版本）
            data: 模板数据
        
        Returns:
            生成的文本
        
        Raises:
            TemplateValidationError: 模板验证失败
            TemplateVersionError: 版本错误
        """
        # 验证模板是否存在
        if template_name not in self.templates:
            raise TemplateValidationError(f"Template not found: {template_name}")
        
        # 确定使用的版本
        if version is None:
            if template_name not in self.current_versions:
                raise TemplateVersionError(f"No current version for template: {template_name}")
            version = self.current_versions[template_name]
        
        # 验证版本是否存在
        if version not in self.templates[template_name]:
            raise TemplateVersionError(f"Version {version} not found for template {template_name}")
        
        # 获取模板内容
        template = self.templates[template_name][version]
        
        # 清理输入数据
        safe_data = self._sanitize_input(data or {})
        
        # 应用模板
        try:
            result = template.format(**safe_data)
        except KeyError as e:
            # 处理缺失的占位符
            missing_key = str(e).strip("'")
            safe_data[missing_key] = ""
            result = template.format(**safe_data)
        
        return result
    
    def switch_version(self, template_name: str, version: str) -> None:
        """
        切换模板版本
        
        Args:
            template_name: 模板名称
            version: 目标版本号
        
        Raises:
            TemplateVersionError: 版本不存在
        """
        if template_name not in self.templates:
            raise TemplateValidationError(f"Template not found: {template_name}")
        
        if version not in self.templates[template_name]:
            raise TemplateVersionError(f"Version {version} not found for template {template_name}")
        
        self.current_versions[template_name] = version
    
    def rollback_version(self, template_name: str) -> None:
        """
        回退到上一个版本
        
        Args:
            template_name: 模板名称
        
        Raises:
            TemplateVersionError: 无法回退
        """
        if template_name not in self.version_history:
            raise TemplateValidationError(f"Template not found: {template_name}")
        
        history = self.version_history[template_name]
        if len(history) < 2:
            raise TemplateVersionError("No previous version to rollback to")
        
        # 获取上一个版本
        current_index = history.index(self.current_versions[template_name])
        if current_index == 0:
            raise TemplateVersionError("Already at the earliest version")
        
        previous_version = history[current_index - 1]
        self.current_versions[template_name] = previous_version
    
    def get_available_versions(self, template_name: str) -> List[str]:
        """
        获取模板的所有可用版本
        
        Args:
            template_name: 模板名称
        
        Returns:
            版本号列表
        """
        if template_name not in self.templates:
            return []
        
        return list(self.templates[template_name].keys())
    
    def _validate_template_content(self, content: str) -> bool:
        """
        验证模板内容安全性
        
        Args:
            content: 模板内容
        
        Returns:
            True if valid
        
        Raises:
            TemplateValidationError: 内容不安全
        """
        # 检查危险模式
        for pattern in self.dangerous_patterns:
            if re.search(pattern, content, re.IGNORECASE):
                raise TemplateValidationError("Dangerous content detected in template")
        
        return True
    
    def _sanitize_input(self, data: Dict[str, Any]) -> Dict[str, str]:
        """
        清理输入数据，防止注入攻击
        
        Args:
            data: 原始输入数据
        
        Returns:
            清理后的数据
        """
        sanitized = {}
        for key, value in data.items():
            if isinstance(value, str):
                # HTML转义防止XSS
                sanitized[key] = html.escape(value)
            else:
                sanitized[key] = str(value)
        
        return sanitized
