"""
历史交互数据收集、清洗和结构化模块。

该模块从指定数据源读取历史交互数据，进行清洗和脱敏处理，
输出结构化的JSON Lines格式数据集。
"""

import json
import re
import os
from datetime import datetime
from abc import ABC, abstractmethod
from typing import Iterator, Dict, Any, List


class DataSource(ABC):
    """数据源抽象基类。"""
    
    @abstractmethod
    def read(self) -> Iterator[Dict[str, Any]]:
        """从数据源读取原始数据。"""
        pass
    
    @classmethod
    def from_file(cls, filepath: str) -> 'DataSource':
        """从文件创建数据源。"""
        return FileDataSource(filepath)
    
    @classmethod
    def from_database(cls, connection: Any, query: str) -> 'DataSource':
        """从数据库创建数据源。"""
        return DatabaseDataSource(connection, query)


class FileDataSource(DataSource):
    """文件数据源。"""
    
    def __init__(self, filepath: str):
        """初始化文件数据源。
        
        Args:
            filepath: 文件路径
        """
        if not os.path.exists(filepath):
            raise FileNotFoundError(f"文件不存在: {filepath}")
        self.filepath = filepath
    
    def read(self) -> Iterator[Dict[str, Any]]:
        """从文件读取数据。"""
        with open(self.filepath, 'r', encoding='utf-8') as f:
            buffer = []
            for line in f:
                line = line.rstrip('\n')
                if line.strip() == '' and buffer:
                    yield {'raw': '\n'.join(buffer), 'source': self.filepath}
                    buffer = []
                elif line.strip() != '':
                    buffer.append(line)
            if buffer:
                yield {'raw': '\n'.join(buffer), 'source': self.filepath}


class DatabaseDataSource(DataSource):
    """数据库数据源。"""
    
    def __init__(self, connection: Any, query: str):
        """初始化数据库数据源。
        
        Args:
            connection: 数据库连接对象
            query: 查询SQL语句
        """
        self.connection = connection
        self.query = query
    
    def read(self) -> Iterator[Dict[str, Any]]:
        """从数据库读取数据。"""
        cursor = self.connection.cursor()
        cursor.execute(self.query)
        
        columns = [desc[0] for desc in cursor.description]
        for row in cursor.fetchall():
            # 将行数据拼接为字符串
            row_str = '\n'.join(str(value) for value in row)
            yield {'raw': row_str, 'source': 'database'}


class DataCleaner:
    """数据清洗器。"""
    
    def __init__(self):
        """初始化数据清洗器。"""
        # 定义敏感信息模式
        self.email_pattern = re.compile(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b')
        self.phone_pattern = re.compile(r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b')
    
    def clean(self, raw_data: Iterator[Dict[str, Any]]) -> Iterator[Dict[str, Any]]:
        """清洗数据管道。"""
        # 步骤1: 基础清洗
        cleaned_data = self._basic_clean(raw_data)
        # 步骤2: 脱敏处理
        anonymized_data = self._anonymize(cleaned_data)
        # 步骤3: 结构化
        structured_data = self._structure(anonymized_data)
        
        return structured_data
    
    def _basic_clean(self, raw_data: Iterator[Dict[str, Any]]) -> Iterator[Dict[str, Any]]:
        """基础清洗：去除多余空格和空行。"""
        for record in raw_data:
            if 'raw' in record:
                # 分割行，去除每行首尾空格，过滤空行
                lines = [line.strip() for line in record['raw'].split('\n')]
                lines = [line for line in lines if line]
                record['cleaned'] = '\n'.join(lines)
                yield record
    
    def _anonymize(self, cleaned_data: Iterator[Dict[str, Any]]) -> Iterator[Dict[str, Any]]:
        """数据脱敏：替换敏感信息。"""
        for record in cleaned_data:
            if 'cleaned' in record:
                text = record['cleaned']
                # 替换邮箱
                text = self.email_pattern.sub('[EMAIL]', text)
                # 替换电话号码
                text = self.phone_pattern.sub('[PHONE]', text)
                record['anonymized'] = text
                yield record
    
    def _structure(self, anonymized_data: Iterator[Dict[str, Any]]) -> Iterator[Dict[str, Any]]:
        """数据结构化：解析为结构化格式。"""
        for record in anonymized_data:
            if 'anonymized' in record:
                lines = record['anonymized'].split('\n')
                
                # 假设格式为：用户查询\n系统响应\n反馈
                structured = {
                    'user_query': lines[0] if len(lines) > 0 else '',
                    'system_response': lines[1] if len(lines) > 1 else '',
                    'feedback': lines[2] if len(lines) > 2 else '',
                    'source': record.get('source', 'unknown'),
                    'timestamp': datetime.utcnow().isoformat() + 'Z'
                }
                yield structured


class DataCollector:
    """数据收集器主类。"""
    
    def __init__(self):
        """初始化数据收集器。"""
        self.cleaner = DataCleaner()
    
    def process(self, input_source: Any, output_file: str) -> None:
        """处理数据：从输入源读取，清洗，输出到文件。
        
        Args:
            input_source: 输入源，可以是文件路径或数据源对象
            output_file: 输出文件路径
        """
        # 确定输入源类型
        if isinstance(input_source, str):
            data_source = DataSource.from_file(input_source)
        elif isinstance(input_source, DataSource):
            data_source = input_source
        else:
            raise ValueError("不支持的输入源类型")
        
        # 读取原始数据
        raw_data = data_source.read()
        
        # 清洗和结构化数据
        structured_data = self.cleaner.clean(raw_data)
        
        # 写入JSON Lines格式
        with open(output_file, 'w', encoding='utf-8') as f:
            for record in structured_data:
                # 安全检查：确保记录不包含危险内容
                self._security_check(record)
                f.write(json.dumps(record, ensure_ascii=False) + '\n')
    
    def _security_check(self, record: Dict[str, Any]) -> None:
        """安全检查：防止恶意指令或偏见内容。"""
        # 检查是否有潜在的危险模式
        dangerous_patterns = [
            r'\beval\s*\(',
            r'\bexec\s*\(',
            r'\bcompile\s*\(',
            r'\b__import__\s*\(',
            r'\bopen\s*\(.*,\s*["\']w["\']',
        ]
        
        for key, value in record.items():
            if isinstance(value, str):
                for pattern in dangerous_patterns:
                    if re.search(pattern, value, re.IGNORECASE):
                        raise SecurityError(f"发现潜在危险内容: {pattern} in {key}")


class SecurityError(Exception):
    """安全异常。"""
    pass


if __name__ == '__main__':
    # 示例用法
    collector = DataCollector()
    
    # 从文件处理
    collector.process('input_data.txt', 'output_data.jsonl')
