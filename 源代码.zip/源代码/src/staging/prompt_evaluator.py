import re
from typing import Dict, List, Any, Set, Tuple


class PromptEvaluator:
    """提示词模板评估器"""
    
    def __init__(self):
        # 安全关键词 - 使用单词边界匹配避免误判
        self.security_patterns = [
            r"\beval\s*\(",  # eval(
            r"\bexec\s*\(",  # exec(
            r"\bshell\b.*\btrue\b",  # shell=True
            r"\bos\.system\s*\(",  # os.system(
            r"\bsubprocess\b.*\brun\b",  # subprocess.run
        ]
        
        self.performance_keywords = ["nested", "loop", "recursive", "complex", "heavy"]
        self.maintainability_keywords = ["monolithic", "spaghetti", "duplicate", "hardcoded"]
        self.cve_keywords = ["cve", "vulnerability", "exploit", "security flaw"]
        self.payload_keywords = ["payload", "input", "data", "parameters"]
        self.reporting_keywords = ["report", "output", "result", "summary"]
        self.clarity_keywords = ["clear", "specific", "precise", "unambiguous"]
        self.structure_keywords = ["structure", "format", "section", "organization"]
        self.sensitive_keywords = ["api key", "password", "secret", "token", "credential"]
        
        # 改进的语义分析：区分模糊词汇和技术动词
        self.vague_keywords = [
            "something", "stuff", "things", "handle", "process", "manage",
            "do", "make", "perform"  # 这些在技术上下文中可能模糊
        ]
        
        # 技术动词 - 不视为模糊，除非在模糊上下文中
        self.technical_verbs = [
            "create", "generate", "execute", "extract", "analyze",
            "compare", "validate", "verify", "check", "identify", "classify"
        ]
        
        # 模糊模式 - 改进边界检查
        self.vague_patterns = [
            r"\bdo\s+something\b",
            r"\bhandle\s+the\s+data\b",
            r"\bprocess\s+it\b",
            r"\bmanage\s+.*\b",
        ]
        
        # 预编译正则表达式以提高性能
        self._compiled_security_patterns = [re.compile(p, re.IGNORECASE) for p in self.security_patterns]
        self._compiled_vague_patterns = [re.compile(p, re.IGNORECASE) for p in self.vague_patterns]
    
    def evaluate(self, template: str) -> Dict[str, Any]:
        """评估提示词模板"""
        optimization_points = []
        template_lower = template.lower()  # 缓存小写版本
        
        # 安全检查 - 使用模式匹配
        security_issues = self._check_security_issues(template)
        if security_issues:
            optimization_points.extend(security_issues)
        
        # 性能检查
        if any(keyword in template_lower for keyword in self.performance_keywords):
            optimization_points.append("Performance: Template may lead to inefficient execution")
        
        # 可维护性检查
        if any(keyword in template_lower for keyword in self.maintainability_keywords):
            optimization_points.append("Maintainability: Template structure could be improved")
        
        # CVE覆盖检查
        if any(keyword in template_lower for keyword in self.cve_keywords):
            optimization_points.append("CVE Coverage: Template mentions CVE-related content")
        
        # 负载生成检查
        if any(keyword in template_lower for keyword in self.payload_keywords):
            optimization_points.append("Payload Generation: Template includes payload handling")
        
        # 报告任务检查
        if any(keyword in template_lower for keyword in self.reporting_keywords):
            optimization_points.append("Reporting: Template includes reporting requirements")
        
        # 清晰语言检查
        if any(keyword in template_lower for keyword in self.clarity_keywords):
            optimization_points.append("Clarity: Template emphasizes clear language")
        
        # 结构一致性检查
        if any(keyword in template_lower for keyword in self.structure_keywords):
            optimization_points.append("Structure: Template mentions structural aspects")
        
        # 敏感信息检查
        if any(keyword in template_lower for keyword in self.sensitive_keywords):
            optimization_points.append("Sensitive Info: Template may contain sensitive information")
        
        # 语义审计
        semantic_issues = self._check_semantic_issues(template, template_lower)
        if semantic_issues:
            optimization_points.extend(semantic_issues)
        
        # 移除强制添加优化点的逻辑
        # 评估结果应该反映真实情况
        
        # 计算语义问题 - 基于实际的语义分析结果
        has_semantic_issues = any(
            "Semantic:" in point for point in optimization_points
        )
        
        return {
            "assessment_report": {
                "template": template,
                "optimization_count": len(optimization_points),
                "has_security_issues": any("Security:" in point for point in optimization_points),
                "has_semantic_issues": has_semantic_issues,
                "overall_score": self._calculate_score(optimization_points)
            },
            "optimization_points": optimization_points
        }
    
    def _check_security_issues(self, template: str) -> List[str]:
        """检查安全问题 - 使用模式匹配避免误判"""
        issues = []
        
        for pattern in self._compiled_security_patterns:
            if pattern.search(template):
                issues.append("Security: Template contains potentially dangerous operations")
                break  # 发现一个安全问题就足够
        
        return issues
    
    def _check_semantic_issues(self, template: str, template_lower: str) -> List[str]:
        """检查语义问题"""
        issues = []
        
        # 检查真正的模糊词汇
        vague_words_found = []
        for keyword in self.vague_keywords:
            # 使用单词边界检查避免部分匹配
            if re.search(rf"\b{keyword}\b", template_lower):
                vague_words_found.append(keyword)
        
        if vague_words_found:
            issues.append(f"Semantic: Template contains vague terms: {', '.join(vague_words_found)}")
        
        # 检查模糊模式
        for pattern in self._compiled_vague_patterns:
            if pattern.search(template_lower):
                issues.append("Semantic: Template contains vague instructions that lack specificity")
                break
        
        # 检查指令清晰度 - 修改为更宽松的逻辑
        if not self._has_clear_instructions(template_lower):
            # 只有当模板包含动作动词时才检查清晰度
            # 避免对非指令性内容（如描述、问题陈述）误判
            if self._contains_action_verb(template_lower):
                issues.append("Semantic: Template lacks clear, actionable instructions")
        
        return issues
    
    def _contains_action_verb(self, template_lower: str) -> bool:
        """检查模板是否包含动作动词"""
        action_verbs = self.technical_verbs + [
            "implement", "build", "construct", "develop", "write",
            "calculate", "compute", "transform", "convert", "parse",
            "extract", "find", "search", "locate", "identify",
            "create", "generate", "produce", "make", "build",
            "analyze", "examine", "review", "assess", "evaluate",
            "compare", "contrast", "differentiate", "distinguish",
            "validate", "verify", "confirm", "check", "test",
            "classify", "categorize", "group", "organize", "sort"
        ]
        
        return any(re.search(rf"\b{verb}\b", template_lower) for verb in action_verbs)
    
    def _has_clear_instructions(self, template_lower: str) -> bool:
        """检查模板是否有清晰的指令"""
        # 扩展的动作动词列表
        action_verbs = self.technical_verbs + [
            "implement", "build", "construct", "develop", "write",
            "calculate", "compute", "transform", "convert", "parse",
            "extract", "find", "search", "locate", "identify",
            "create", "generate", "produce", "make", "build",
            "analyze", "examine", "review", "assess", "evaluate",
            "compare", "contrast", "differentiate", "distinguish",
            "validate", "verify", "confirm", "check", "test",
            "classify", "categorize", "group", "organize", "sort",
            "remove", "delete", "add", "insert", "update",
            "modify", "change", "adjust", "fix", "correct",
            "run", "execute", "perform", "carry out", "conduct"
        ]
        
        # 检查是否包含具体的动作动词
        has_action = any(re.search(rf"\b{verb}\b", template_lower) for verb in action_verbs)
        
        # 如果没有动作动词，直接返回False（不是指令性内容）
        if not has_action:
            return False
        
        # 检查是否包含具体的输出格式
        output_formats = ["list", "table", "json", "csv", "report", "summary", "chart", "graph", "output", "result"]
        
        # 检查是否包含具体的输入要求
        input_requirements = ["input", "data", "text", "file", "parameters", "dataset", "content", "information", "text", "document"]
        
        # 检查是否包含具体的约束或条件
        constraints = ["must", "should", "require", "constraint", "condition", "limit", "only", "exactly", "precisely", "specifically"]
        
        # 检查是否包含具体的目标或对象
        targets = ["url", "email", "phone", "address", "date", "time", "number", "value", "price", "name"]
        
        has_output = any(re.search(rf"\b{fmt}\b", template_lower) for fmt in output_formats)
        has_input = any(re.search(rf"\b{req}\b", template_lower) for req in input_requirements)
        has_constraint = any(re.search(rf"\b{const}\b", template_lower) for const in constraints)
        has_target = any(re.search(rf"\b{target}\b", template_lower) for target in targets)
        
        # 清晰的指令需要：动作动词 + (输出格式 或 输入要求 或 约束条件 或 具体目标)
        # 这个逻辑更宽松，允许简洁但清晰的指令通过
        return has_action and (has_output or has_input or has_constraint or has_target)
    
    def _calculate_score(self, optimization_points: List[str]) -> int:
        """计算总体评分"""
        base_score = 10
        
        # 根据问题类型和数量扣分
        deductions = 0
        
        for point in optimization_points:
            if "Security:" in point:
                deductions += 3  # 安全问题严重扣分
            elif "Semantic:" in point:
                deductions += 2  # 语义问题中等扣分
            else:
                deductions += 1  # 其他问题轻微扣分
        
        return max(0, base_score - deductions)