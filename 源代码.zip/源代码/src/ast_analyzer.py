#!/usr/bin/env python3
"""
AST 语义分析器 - 静态提取代码摘要与危险调用检测
用于在 LLM 评估前进行预过滤，实现控制面与执行面解耦。
"""
import ast
import json
import re
from typing import Dict, List, Any, Optional

# 危险调用关键词（部分匹配函数名或属性链）
DANGEROUS_PATTERNS = [
    "os.system",
    "subprocess",
    "exec",
    "eval",
    "compile",
    "open",
    "pickle.load",
    "pickle.loads",
    "yaml.load",
    "yaml.safe_load",  # 通常安全，但仍需注意
    "marshal.load",
    "json.load",       # 一般安全，但可能存在风险
    "input",
    "raw_input",
    "__import__",
    "codecs.open",
    "shutil.rmtree",
    "shutil.copy",
    "os.remove",
    "os.unlink",
    "os.rename",
    "os.chmod",
    "os.chown",
    "sqlite3.connect",  # 虽然无害，但可能用于 SQL 注入（需结合上下文）
    "cursor.execute",
    "requests.get",     # 可能用于 SSRF
    "urllib.request.urlopen",
    "socket.create_connection",
]

def extract_semantic_summary(code_string: str) -> Dict[str, Any]:
    """
    静态分析 Python 代码，提取摘要并检测危险调用。
    
    返回字典包含：
    - has_dangerous_calls: bool
    - summary: str  # 人类可读摘要
    - dangerous_calls: List[str]  # 具体的危险调用列表
    - function_defs: List[str]  # 定义的函数名
    - imports: List[str]  # 导入的模块/符号
    - call_count: int  # 函数调用总数
    - line_count: int  # 代码行数（非空非注释）
    """
    if not code_string.strip():
        return {
            "has_dangerous_calls": False,
            "summary": "空代码",
            "dangerous_calls": [],
            "function_defs": [],
            "imports": [],
            "call_count": 0,
            "line_count": 0
        }
    
    dangerous_calls = []
    function_defs = []
    imports = []
    all_calls = []
    
    try:
        tree = ast.parse(code_string)
    except SyntaxError:
        # 如果无法解析，回退到简单正则检测
        return _fallback_summary(code_string)
    
    # 计算非空非注释行数
    lines = [line for line in code_string.split('\n') if line.strip() and not line.strip().startswith('#')]
    line_count = len(lines)
    
    class Analyzer(ast.NodeVisitor):
        def visit_Import(self, node):
            for alias in node.names:
                imports.append(alias.name)
            self.generic_visit(node)
        
        def visit_ImportFrom(self, node):
            module = node.module or ''
            for alias in node.names:
                if module:
                    imports.append(f"{module}.{alias.name}")
                else:
                    imports.append(alias.name)
            self.generic_visit(node)
        
        def visit_FunctionDef(self, node):
            function_defs.append(node.name)
            self.generic_visit(node)
        
        def visit_Call(self, node):
            # 提取调用表达式的字符串表示（近似）
            call_str = ast.unparse(node) if hasattr(ast, 'unparse') else _unparse_call(node)
            all_calls.append(call_str)
            
            # 检测危险调用
            if isinstance(node.func, ast.Name):
                func_name = node.func.id
                for pattern in DANGEROUS_PATTERNS:
                    if pattern == func_name or pattern.endswith('.' + func_name):
                        dangerous_calls.append(call_str)
            elif isinstance(node.func, ast.Attribute):
                # 处理 obj.attr 形式的调用
                try:
                    attr_chain = []
                    n = node.func
                    while isinstance(n, ast.Attribute):
                        attr_chain.append(n.attr)
                        n = n.value
                    if isinstance(n, ast.Name):
                        attr_chain.append(n.id)
                    full_name = '.'.join(reversed(attr_chain))
                    for pattern in DANGEROUS_PATTERNS:
                        if pattern in full_name:  # 部分匹配
                            dangerous_calls.append(call_str)
                except:
                    pass
            self.generic_visit(node)
    
    analyzer = Analyzer()
    analyzer.visit(tree)
    
    # 去重
    dangerous_calls = list(set(dangerous_calls))
    imports = list(set(imports))
    
    # 生成摘要
    summary_parts = []
    if function_defs:
        summary_parts.append(f"定义函数: {', '.join(function_defs)}")
    if imports:
        summary_parts.append(f"导入: {', '.join(imports)}")
    if all_calls:
        summary_parts.append(f"函数调用 {len(all_calls)} 次")
    if dangerous_calls:
        summary_parts.append(f"危险调用: {', '.join(dangerous_calls[:3])}")
    
    summary = "; ".join(summary_parts) if summary_parts else "无显著语义特征"
    
    return {
        "has_dangerous_calls": len(dangerous_calls) > 0,
        "summary": summary,
        "dangerous_calls": dangerous_calls,
        "function_defs": function_defs,
        "imports": imports,
        "call_count": len(all_calls),
        "line_count": line_count
    }

def _unparse_call(node: ast.Call) -> str:
    """简易版调用反解析，用于 Python < 3.9 或未提供 ast.unparse 的情况"""
    func_part = ""
    if isinstance(node.func, ast.Name):
        func_part = node.func.id
    elif isinstance(node.func, ast.Attribute):
        # 递归构建属性链
        parts = []
        n = node.func
        while isinstance(n, ast.Attribute):
            parts.append(n.attr)
            n = n.value
        if isinstance(n, ast.Name):
            parts.append(n.id)
        func_part = '.'.join(reversed(parts))
    else:
        func_part = "<unknown>"
    return f"{func_part}(...)"

def _fallback_summary(code_string: str) -> Dict[str, Any]:
    """当 AST 解析失败时的回退摘要（基于正则）"""
    lines = [line for line in code_string.split('\n') if line.strip() and not line.strip().startswith('#')]
    line_count = len(lines)
    
    dangerous_calls = []
    for pattern in DANGEROUS_PATTERNS:
        if re.search(r'\b' + re.escape(pattern) + r'\b', code_string):
            dangerous_calls.append(pattern)
    
    # 简单函数定义检测
    func_defs = re.findall(r'def\s+(\w+)\s*\(', code_string)
    
    # 导入检测
    imports = []
    imports.extend(re.findall(r'import\s+(\w+)', code_string))
    imports.extend(re.findall(r'from\s+(\w+)\s+import', code_string))
    
    summary_parts = []
    if func_defs:
        summary_parts.append(f"定义函数: {', '.join(func_defs)}")
    if imports:
        summary_parts.append(f"导入: {', '.join(imports)}")
    if dangerous_calls:
        summary_parts.append(f"危险调用: {', '.join(dangerous_calls[:3])}")
    
    summary = "; ".join(summary_parts) if summary_parts else "回退分析（语法可能无效）"
    
    return {
        "has_dangerous_calls": len(dangerous_calls) > 0,
        "summary": summary,
        "dangerous_calls": dangerous_calls,
        "function_defs": func_defs,
        "imports": imports,
        "call_count": 0,
        "line_count": line_count
    }

if __name__ == "__main__":
    # 简单测试
    test_code = """
import os
def foo():
    os.system('ls')
    x = 1 + 2
    print(x)
"""
    result = extract_semantic_summary(test_code)
    print(json.dumps(result, indent=2, ensure_ascii=False))
