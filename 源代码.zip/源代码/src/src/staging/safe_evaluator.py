import ast
import operator

class SafeEvaluator:
    """极简安全表达式评估器，基于 AST 解析与受限操作"""
    
    _allowed_ops = {
        ast.Add: operator.add,
        ast.Sub: operator.sub,
        ast.Mult: operator.mul,
        ast.Div: operator.truediv,
        ast.USub: operator.neg,
    }
    
    def evaluate(self, expr: str):
        """评估数学表达式，仅允许数字与基本运算符"""
        tree = ast.parse(expr, mode='eval')
        self._validate(tree.body)
        return self._eval(tree.body)
    
    def _validate(self, node):
        """验证 AST 节点是否安全"""
        if isinstance(node, ast.Constant):
            if not isinstance(node.value, (int, float)):
                raise ValueError("只允许数字常量")
        elif isinstance(node, ast.Num):
            if not isinstance(node.n, (int, float)):
                raise ValueError("只允许数字常量")
        elif isinstance(node, ast.UnaryOp):
            if type(node.op) not in self._allowed_ops:
                raise ValueError("不允许的一元运算符")
            self._validate(node.operand)
        elif isinstance(node, ast.BinOp):
            if type(node.op) not in self._allowed_ops:
                raise ValueError("不允许的二元运算符")
            self._validate(node.left)
            self._validate(node.right)
        else:
            raise ValueError("不允许的 AST 节点")
    
    def _eval(self, node):
        """递归评估安全节点"""
        if isinstance(node, ast.Constant):
            return node.value
        if isinstance(node, ast.Num):
            return node.n
        if isinstance(node, ast.UnaryOp):
            return self._allowed_ops[type(node.op)](self._eval(node.operand))
        if isinstance(node, ast.BinOp):
            left = self._eval(node.left)
            right = self._eval(node.right)
            if isinstance(node.op, ast.Div) and right == 0:
                raise ZeroDivisionError("除零错误")
            return self._allowed_ops[type(node.op)](left, right)
        raise ValueError("评估错误")

if __name__ == "__main__":
    evaluator = SafeEvaluator()
    print(evaluator.evaluate("1 + 2 * 3"))  # 输出 7
