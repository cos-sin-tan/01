import re
from typing import Union


def safe_eval_expression(expression: str) -> Union[int, float]:
    """
    安全地评估数学表达式字符串。
    
    该函数使用白名单验证和受限的执行环境来安全地评估数学表达式，
    只允许数字、基本运算符和括号。
    
    Args:
        expression (str): 要评估的数学表达式字符串。
        
    Returns:
        Union[int, float]: 表达式计算结果，可能是整数或浮点数。
        
    Raises:
        ValueError: 如果表达式为空、包含非法字符或语法错误。
        ZeroDivisionError: 如果表达式包含除零操作。
        
    Examples:
        >>> safe_eval_expression("2 + 3 * 5")
        17
        >>> safe_eval_expression("(2 + 3) * 5")
        25
        >>> safe_eval_expression("10 / 2")
        5.0
    """
    # 1. 输入验证：检查表达式是否为空或仅包含空白字符
    if not expression or not expression.strip():
        raise ValueError("表达式不能为空或仅包含空白字符")
    
    # 去除首尾空白字符
    expression = expression.strip()
    
    # 2. 白名单验证：只允许数字、基本运算符、括号、小数点和空格
    # 允许的字符：数字 0-9, 运算符 + - * / % **, 括号 ( ), 小数点 ., 空格
    allowed_pattern = r'^[\d\s\+\-\*/%\(\)\.]*$'
    
    # 检查表达式是否只包含允许的字符
    if not re.match(allowed_pattern, expression):
        raise ValueError("表达式包含非法字符，只允许数字、基本运算符(+ - * / % **)和括号()")
    
    # 3. 额外的安全验证：确保没有连续的运算符或其他可疑模式
    # 检查是否有连续的运算符（除了 ** 是合法的）
    suspicious_patterns = [
        r'\*{3,}',  # 三个或更多连续的 *
        r'/{2,}',   # 两个或更多连续的 /
        r'\+{2,}',  # 两个或更多连续的 +
        r'-{2,}',   # 两个或更多连续的 -
        r'%{2,}',   # 两个或更多连续的 %
    ]
    
    for pattern in suspicious_patterns:
        if re.search(pattern, expression):
            raise ValueError("表达式包含可疑的运算符模式")
    
    # 4. 括号匹配验证
    stack = []
    for char in expression:
        if char == '(':
            stack.append(char)
        elif char == ')':
            if not stack:
                raise ValueError("括号不匹配：多余的右括号")
            stack.pop()
    
    if stack:
        raise ValueError("括号不匹配：缺少右括号")
    
    # 5. 创建安全的执行环境
    # 完全禁用内置函数，只允许数学运算
    safe_globals = {
        '__builtins__': {},  # 禁用所有内置函数
    }
    
    # 6. 安全地评估表达式
    try:
        # 使用 eval() 但限制在安全的环境中
        result = eval(expression, safe_globals, {})
    except SyntaxError as e:
        raise ValueError(f"表达式语法错误: {str(e)}")
    except ZeroDivisionError as e:
        # 重新抛出除零错误，让调用者处理
        raise ZeroDivisionError(f"数学错误: {str(e)}")
    except Exception as e:
        # 捕获其他所有异常并转换为 ValueError
        raise ValueError(f"无法评估表达式: {str(e)}")
    
    # 7. 验证结果类型
    if not isinstance(result, (int, float)):
        raise ValueError(f"表达式结果类型无效: {type(result).__name__}")
    
    return result


if __name__ == "__main__":
    # 简单的命令行测试
    test_expressions = [
        "2 + 3",
        "10 - 4",
        "3 * 5",
        "10 / 2",
        "2 + 3 * 5",
        "(2 + 3) * 5",
        "2 ** 3",
        "10 % 3",
    ]
    
    print("测试安全表达式评估:")
    for expr in test_expressions:
        try:
            result = safe_eval_expression(expr)
            print(f"  {expr} = {result}")
        except Exception as e:
            print(f"  {expr} -> 错误: {e}")
