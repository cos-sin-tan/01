#!/usr/bin/env python3
"""
Safe Expression Evaluator

This module provides a safe way to evaluate mathematical expressions using eval().
It includes strict input validation to prevent security vulnerabilities.

WARNING: Using eval() with untrusted input is inherently dangerous.
This implementation attempts to mitigate risks by:
1. Restricting allowed characters and operations
2. Validating the expression structure
3. Using a restricted namespace
However, no solution is completely secure when using eval().
Use with extreme caution and only with trusted or properly sanitized input.
"""

import ast
import operator
from typing import Any, Dict


# Allowed operators for mathematical expressions
ALLOWED_OPERATORS: Dict[type, Any] = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.Pow: operator.pow,
    ast.USub: operator.neg,
    ast.UAdd: operator.pos,
}

# Allowed node types in the AST
ALLOWED_NODE_TYPES = (
    ast.Expression,
    ast.BinOp,
    ast.UnaryOp,
    ast.Constant,
    ast.Num,
)


def safe_eval(expression: str) -> Any:
    """
    Safely evaluate a mathematical expression.
    
    Args:
        expression: A string containing a mathematical expression.
        
    Returns:
        The result of evaluating the expression.
        
    Raises:
        ValueError: If the expression contains invalid or dangerous content.
        SyntaxError: If the expression has syntax errors.
        ZeroDivisionError: If the expression attempts division by zero.
        
    WARNING: While this function attempts to be safe, using eval() always
    carries some risk. Only use with trusted input.
    """
    # Check for empty or whitespace-only expressions
    if not expression or not expression.strip():
        raise ValueError("Expression cannot be empty or whitespace only")
    
    # Remove leading/trailing whitespace
    expression = expression.strip()
    
    try:
        # Parse the expression into an AST
        tree = ast.parse(expression, mode='eval')
    except SyntaxError as e:
        raise ValueError(f"Invalid expression syntax: {e}")
    
    # Validate the AST
    if not _validate_ast(tree):
        raise ValueError("Invalid expression: contains disallowed operations")
    
    # Compile and evaluate the expression with a restricted namespace
    compiled_expr = compile(tree, '<string>', 'eval')
    
    # Use a minimal namespace with only safe builtins
    safe_namespace = {
        '__builtins__': {},
    }
    
    return eval(compiled_expr, safe_namespace)


def _validate_ast(node: ast.AST) -> bool:
    """
    Recursively validate the AST to ensure it only contains allowed operations.
    
    Args:
        node: The AST node to validate.
        
    Returns:
        True if the AST is valid, False otherwise.
    """
    # Check node type
    if not isinstance(node, ALLOWED_NODE_TYPES):
        return False
    
    # Check for specific node types
    if isinstance(node, ast.BinOp):
        # Check if the operator is allowed
        if type(node.op) not in ALLOWED_OPERATORS:
            return False
        # Recursively validate left and right operands
        return _validate_ast(node.left) and _validate_ast(node.right)
    
    elif isinstance(node, ast.UnaryOp):
        # Check if the unary operator is allowed
        if type(node.op) not in ALLOWED_OPERATORS:
            return False
        # Recursively validate the operand
        return _validate_ast(node.operand)
    
    elif isinstance(node, (ast.Constant, ast.Num)):
        # Constants are always allowed
        return True
    
    # For Expression nodes, validate the body
    elif isinstance(node, ast.Expression):
        return _validate_ast(node.body)
    
    return False


def evaluate_expression(expression: str) -> str:
    """
    Main function to evaluate an expression with proper error handling.
    
    Args:
        expression: A string containing a mathematical expression.
        
    Returns:
        A string containing either the result or an error message.
    """
    try:
        result = safe_eval(expression)
        return str(result)
    except ValueError as e:
        return f"Error: {e}"
    except SyntaxError as e:
        return f"Error: Invalid syntax - {e}"
    except ZeroDivisionError as e:
        return f"Error: Division by zero - {e}"
    except Exception as e:
        return f"Error: Unexpected error - {type(e).__name__}: {e}"


def main() -> None:
    """
    Main function to run the expression evaluator interactively.
    """
    print("Safe Expression Evaluator")
    print("=" * 50)
    print("WARNING: This tool uses eval() which can be dangerous.")
    print("Only enter mathematical expressions you trust.\n")
    
    while True:
        try:
            user_input = input("Enter an expression (or 'quit' to exit): ").strip()
            
            if user_input.lower() in ('quit', 'exit', 'q'):
                print("Goodbye!")
                break
            
            if not user_input:
                print("Please enter an expression.")
                continue
            
            result = evaluate_expression(user_input)
            print(f"Result: {result}\n")
            
        except KeyboardInterrupt:
            print("\n\nGoodbye!")
            break
        except EOFError:
            print("\n\nGoodbye!")
            break


if __name__ == "__main__":
    main()