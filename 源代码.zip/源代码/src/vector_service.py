#!/usr/bin/env python3
"""
向量化错误知识库服务（Vector RAG）
将 .ai_knowledge/error_vault.md 中的错误条目转换为向量，提供语义检索。
"""
import os
import re
import json
from typing import List, Dict, Any, Optional
import chromadb
from chromadb.config import Settings
from chromadb.utils import embedding_functions

class VectorErrorService:
    def __init__(self, persist_directory: str = ".chroma_db", collection_name: str = "error_vault"):
        """
        初始化向量数据库客户端。
        """
        self.persist_directory = persist_directory
        self.collection_name = collection_name
        self.embedding_function = None
        self._fallback_mode = False
        
        # 在独立线程中加载嵌入模型，设置15秒超时
        import threading
        def load_embedding():
            try:
                self.embedding_function = embedding_functions.SentenceTransformerEmbeddingFunction(
                    model_name="all-MiniLM-L6-v2"
                )
            except Exception as e:
                print(f"[VectorService] 嵌入模型加载失败: {e}")
                self._fallback_mode = True
        
        thread = threading.Thread(target=load_embedding)
        thread.daemon = True
        thread.start()
        thread.join(timeout=15)  # 等待最多15秒
        
        if self.embedding_function is None:
            # 超时或加载失败，进入安全回退模式
            print("[VectorService] 嵌入模型加载超时/失败，进入安全模式（无向量检索）")
            self._fallback_mode = True
            self.client = None
            self.collection = None
            return
        
        # 创建持久化客户端
        self.client = chromadb.PersistentClient(path=persist_directory)
        
        # 获取或创建集合
        try:
            self.collection = self.client.get_collection(
                name=collection_name,
                embedding_function=self.embedding_function
            )
            print(f"[VectorService] 加载现有集合 '{collection_name}'，包含 {self.collection.count()} 条记录")
        except Exception:
            self.collection = self.client.create_collection(
                name=collection_name,
                embedding_function=self.embedding_function,
                metadata={"description": "Error vault vector store"}
            )
            print(f"[VectorService] 创建新集合 '{collection_name}'")
    
    def parse_error_vault(self, vault_path: str = ".ai_knowledge/error_vault.md") -> List[Dict[str, str]]:
        """
        解析 error_vault.md 文件，提取每个错误条目。
        返回格式：[{"id": "...", "text": "...", "metadata": {...}}]
        """
        if not os.path.exists(vault_path):
            print(f"[VectorService] 错误知识库文件不存在: {vault_path}")
            return []
        
        with open(vault_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # 按错误 ID 分割（每个错误以 "## 错误 ID:" 开头）
        # 使用正则匹配 "## 错误 ID: xxxxxxxx" 作为分隔符
        pattern = r'## 错误 ID: ([a-f0-9]+)\s*\n'
        parts = re.split(pattern, content)
        
        # 第一个部分是文件头部（如果没有错误 ID 则可能为空）
        errors = []
        for i in range(1, len(parts), 2):
            error_id = parts[i]
            error_body = parts[i+1] if i+1 < len(parts) else ""
            # 提取错误正文直到下一个 "---" 或文件结束
            # 我们简单截取前 2000 字符（避免过长）
            text = error_body.strip()
            if len(text) > 2000:
                text = text[:2000] + "..."
            
            # 提取元数据：时间、触发节点、错误类型
            time_match = re.search(r'- \*\*时间\*\*: (.+)', error_body)
            node_match = re.search(r'- \*\*触发节点\*\*: (\w+)', error_body)
            type_match = re.search(r'- \*\*错误类型\*\*: (\w+)', error_body)
            
            metadata = {
                "error_id": error_id,
                "time": time_match.group(1) if time_match else "",
                "node": node_match.group(1) if node_match else "",
                "error_type": type_match.group(1) if type_match else ""
            }
            
            errors.append({
                "id": error_id,
                "text": text,
                "metadata": metadata
            })
        
        print(f"[VectorService] 从 {vault_path} 解析出 {len(errors)} 个错误条目")
        return errors
    
    def index_errors(self, vault_path: str = ".ai_knowledge/error_vault.md", force_rebuild: bool = False, batch_size: int = 4000):
        """
        将错误知识库索引到向量数据库。
        如果集合已存在且非强制重建，则跳过。
        分批插入以避免超过 Chroma 的批量限制。
        """
        # 安全回退模式：跳过索引
        if getattr(self, '_fallback_mode', False):
            print("[VectorService] 安全模式激活，跳过向量索引")
            return
        
        # 检查是否已存在条目
        if self.collection.count() > 0 and not force_rebuild:
            print(f"[VectorService] 向量库中已有 {self.collection.count()} 条记录，跳过索引（如需重建请设置 force_rebuild=True）")
            return
        
        errors = self.parse_error_vault(vault_path)
        if not errors:
            print("[VectorService] 未解析到错误条目，索引终止")
            return
        
        # 分批处理
        total = len(errors)
        for i in range(0, total, batch_size):
            batch = errors[i:i+batch_size]
            ids = []
            documents = []
            metadatas = []
            for err in batch:
                # 组合文档：错误正文 + 元数据
                doc_text = f"错误 ID: {err['id']}\n节点: {err['metadata']['node']}\n类型: {err['metadata']['error_type']}\n{err['text']}"
                ids.append(err['id'])
                documents.append(doc_text)
                metadatas.append(err['metadata'])
            
            # 添加到集合
            self.collection.add(
                ids=ids,
                documents=documents,
                metadatas=metadatas
            )
            print(f"[VectorService] 已索引批次 {i//batch_size + 1}，共 {len(batch)} 条（总计 {min(i+batch_size, total)}/{total}）")
        
        print(f"[VectorService] 成功索引 {total} 个错误条目到集合 '{self.collection_name}'")
    
    def search_lessons(self, query: str, top_k: int = 3, filter_node: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        语义检索最相关的错误教训。
        可选的节点过滤（只检索特定节点触发的错误）。
        """
        # 强制绕过向量计算，返回空结果
        print(f"[VectorService] 向量检索已强制绕过（查询: {query[:50]}...）")
        return []
    
    def forget_stale_lessons(self, days_old: int = 7, min_score: float = 0.2):
        """
        知识遗忘机制：物理删除长时间未被检索且相关性评分极低的错误记录。
        
        参数：
            days_old: 被视为“陈旧”的天数（默认7天）
            min_score: 最低平均相似度阈值，低于此值的记录将被删除（暂未实现评分跟踪）
        """
        from datetime import datetime, timedelta
        
        # 计算截止时间戳（假设 metadata 中包含 "timestamp" 字段，ISO 格式）
        cutoff = (datetime.now() - timedelta(days=days_old)).isoformat()
        
        # 获取集合中所有记录
        try:
            # Chroma 的 get 方法返回所有记录
            results = self.collection.get()
        except Exception as e:
            print(f"[VectorService] 无法获取集合记录: {e}")
            return 0
        
        ids_to_delete = []
        if results and results.get('ids'):
            for i, metadata in enumerate(results.get('metadatas', [])):
                if not metadata:
                    continue
                # 检查时间戳
                timestamp = metadata.get('timestamp')
                if timestamp and timestamp < cutoff:
                    # 暂未实现评分检查（可扩展）
                    ids_to_delete.append(results['ids'][i])
        
        if ids_to_delete:
            print(f"[VectorService] 准备删除 {len(ids_to_delete)} 条陈旧记录")
            try:
                self.collection.delete(ids=ids_to_delete)
                print(f"[VectorService] 已物理删除 {len(ids_to_delete)} 条记录")
                return len(ids_to_delete)
            except Exception as e:
                print(f"[VectorService] 删除失败: {e}")
                return 0
        else:
            print(f"[VectorService] 未找到符合条件的陈旧记录（截止时间 {cutoff}）")
            return 0
    
    def clear_collection(self):
        """清空向量集合（用于重建）"""
        self.client.delete_collection(self.collection_name)
        self.collection = self.client.create_collection(
            name=self.collection_name,
            embedding_function=self.embedding_function
        )
        print(f"[VectorService] 集合 '{self.collection_name}' 已清空")

# 全局单例（可选）
_vector_service_instance = None

def get_vector_service() -> VectorErrorService:
    global _vector_service_instance
    if _vector_service_instance is None:
        _vector_service_instance = VectorErrorService()
    return _vector_service_instance

def search_lessons(query: str, top_k: int = 3) -> List[Dict[str, Any]]:
    """便捷函数，供其他模块调用"""
    service = get_vector_service()
    return service.search_lessons(query, top_k)

if __name__ == "__main__":
    # 命令行测试
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "index":
        service = VectorErrorService()
        service.index_errors(force_rebuild=True)
        print("索引完成")
    elif len(sys.argv) > 1 and sys.argv[1] == "search":
        service = VectorErrorService()
        query = " ".join(sys.argv[2:]) if len(sys.argv) > 2 else "JSON 解析错误"
        lessons = service.search_lessons(query, top_k=2)
        for lesson in lessons:
            print(f"相似度: {lesson['score']:.3f}")
            print(f"错误 ID: {lesson['error_id']}")
            print(f"节点: {lesson['metadata']['node']}")
            print(f"摘要: {lesson['document'][:200]}...")
            print("-" * 50)
    else:
        print("用法:")
        print("  python vector_service.py index          # 重建索引")
        print("  python vector_service.py search <查询>  # 语义检索")
        print("示例: python vector_service.py search 'Coder 节点 JSON 解析错误'")