#!/usr/bin/env python3
"""
极简 DeepSeek API 测试，验证网络出口与 API 密钥是否通畅。
不依赖 KnowledgeManager、LangGraph 等任何复杂组件。
"""
import os
import sys
import json
from pathlib import Path

# 加载 .env 中的 API 密钥
env_path = Path(__file__).parent.parent / '.env'
if env_path.exists():
    with open(env_path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if line.startswith('DEEPSEEK_API_KEY='):
                api_key = line.split('=', 1)[1].strip().strip('"\'')
                break
    if 'api_key' not in locals():
        print("[ERROR] 未在 .env 中找到 DEEPSEEK_API_KEY")
        sys.exit(1)
else:
    api_key = os.getenv('DEEPSEEK_API_KEY')
    if not api_key:
        print("[ERROR] 请设置环境变量 DEEPSEEK_API_KEY 或创建 .env 文件")
        sys.exit(1)

# 选择 HTTP 库（优先使用 httpx，否则使用 requests）
try:
    import httpx
    USE_HTTPX = True
except ImportError:
    try:
        import requests
        USE_HTTPX = False
    except ImportError:
        print("[ERROR] 请安装 httpx 或 requests: pip install httpx")
        sys.exit(1)

def simple_chat() -> bool:
    """发送一条最简单的聊天消息，确认 API 可通"""
    url = "https://api.deepseek.com/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    payload = {
        "model": "deepseek-chat",
        "messages": [
            {"role": "user", "content": "请回复 'OK' 以确认连通性。"}
        ],
        "stream": False,
        "max_tokens": 10
    }
    
    print(f"[INFO] 正在向 {url} 发送测试请求...")
    try:
        if USE_HTTPX:
            resp = httpx.post(url, headers=headers, json=payload, timeout=30.0)
        else:
            resp = requests.post(url, headers=headers, json=payload, timeout=30.0)
        resp.raise_for_status()
        result = resp.json()
        reply = result['choices'][0]['message']['content']
        print(f"[SUCCESS] 收到响应: {reply}")
        print(f"[DEBUG] 完整响应: {json.dumps(result, indent=2, ensure_ascii=False)}")
        return True
    except Exception as e:
        print(f"[FAILURE] API 调用失败: {e}")
        if 'resp' in locals():
            print(f"[DEBUG] 状态码: {resp.status_code}")
            print(f"[DEBUG] 响应体: {resp.text}")
        return False

if __name__ == "__main__":
    success = simple_chat()
    sys.exit(0 if success else 1)