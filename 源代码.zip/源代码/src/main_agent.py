#!/usr/bin/env python3
import sys, os, io
# 强制设置标准输出为 UTF-8，解决 Windows 乱码导致的死锁
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
os.environ["HF_HUB_OFFLINE"] = "1"
"""
LangGraph 智能体后台系统 - 主入口
将 .clinerules 中的 SOP 协作流程重构为独立可执行系统。
包含三个核心节点：Architect_Node、Engineer_Node、QA_Node。
支持错误折返与自动修复循环。
"""

import os
import sys
import subprocess
import json
from typing import TypedDict, List, Optional, Literal, Dict, Any
from pathlib import Path
from datetime import datetime

from dotenv import load_dotenv

# 加载环境变量（用于 DeepSeek API 密钥）
load_dotenv()


# -------------------- 状态 Schema --------------------
class AgentState(TypedDict):
    """多智能体协作工作流的状态对象（协议驱动版）"""
    # 基础字段
    task_description: str          # 用户原始任务描述
    blueprint: Optional[dict]      # Architect 生成的蓝图（JSON）（旧版兼容）
    deliverables: Dict[str, str]   # 交付物路径，key: "code", "report", "speech", "ppt"
    audit_results: Dict[str, bool] # 各子任务审计结果，key: "code", "report", "ppt"
    error_message: Optional[str]   # 错误信息（如有）
    iteration: int                 # 当前迭代次数（用于防止无限循环）
    current_node: Literal["architect", "coder", "reporter", "presenter", "auditor", "auditor_code", "auditor_report", "auditor_ppt", "reflection"]  # 当前节点标识（扩展）
    need_search: Optional[bool]        # 是否需要网络搜索
    
    # RAG 上下文
    relevant_knowledge: Optional[str]   # 检索到的知识片段
    
    # 协议字段（新增）
    system_spec: Optional[Dict[str, Any]]      # System_Spec.json
    hard_constraints: Optional[List[Dict[str, Any]]]  # Hard_Constraints.json 列表
    diagnostic_vector: Optional[Dict[str, Any]] # Diagnostic_Vector.json
    lessons_learned: Optional[List[Dict[str, Any]]]   # Lessons_Learned 列表
    current_consensus: Optional[Dict[str, Any]] # Current_Consensus.json
    token_usage: Dict[str, int]                # total_tokens, last_node_tokens


# -------------------- 工具定义 --------------------
class FileTools:
    """文件操作工具集"""
    @staticmethod
    def read_file(path: str) -> str:
        """读取文件内容"""
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return f.read()
        except FileNotFoundError:
            return f"文件不存在：{path}"
        except Exception as e:
            return f"读取文件时出错：{e}"

    @staticmethod
    def write_file(path: str, content: str) -> dict:
        """写入内容到文件，自动创建目录"""
        try:
            Path(path).parent.mkdir(parents=True, exist_ok=True)
            with open(path, 'w', encoding='utf-8') as f:
                f.write(content)
            return {"success": True, "path": path, "message": f"文件已写入：{path}"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    @staticmethod
    def list_files(path: str, recursive: bool = False) -> List[str]:
        """列出目录下的文件"""
        try:
            p = Path(path)
            if recursive:
                return [str(f) for f in p.rglob("*") if f.is_file()]
            else:
                return [str(f) for f in p.iterdir() if f.is_file()]
        except Exception:
            return []


class TerminalTools:
    """终端命令执行工具集"""
    @staticmethod
    def run_command(command: str, cwd: str = None) -> dict:
        """执行 shell 命令，返回结果字典"""
        try:
            result = subprocess.run(
                command,
                shell=True,
                cwd=cwd,
                capture_output=True,
                text=True,
                encoding='utf-8',
                timeout=30
            )
            return {
                "success": result.returncode == 0,
                "returncode": result.returncode,
                "stdout": result.stdout,
                "stderr": result.stderr,
            }
        except subprocess.TimeoutExpired:
            return {"success": False, "error": "命令执行超时"}
        except Exception as e:
            return {"success": False, "error": str(e)}


# -------------------- 模型初始化 --------------------
def get_deepseek_model(model_name: str = "deepseek-chat"):
    """获取 DeepSeek 模型实例，严格拒绝模拟模式"""
    from langchain_deepseek import ChatDeepSeek
    api_key = os.getenv("DEEPSEEK_API_KEY")
    if not api_key or api_key.strip() == "":
        raise ValueError("DEEPSEEK_API_KEY 缺失，拒绝执行。请设置有效的 API 密钥。")
    # 确保密钥有效
    if api_key.strip() == "test":
        raise ValueError("DEEPSEEK_API_KEY 为 'test'，这是无效的模拟模式，已禁止。请提供真实的 API 密钥。")
    # 正常情况：使用真实的 DeepSeek API
    return ChatDeepSeek(model=model_name, api_key=api_key, timeout=300, max_retries=3)

# 注意：实际使用时需要根据模型名称区分 R1 和 V3
# 此处为简化，使用同一个模型（可根据需要调整）
architect_model = get_deepseek_model("deepseek-reasoner")   # 假设 R1
coder_model = get_deepseek_model("deepseek-chat")           # 假设 V3
reporter_model = get_deepseek_model("deepseek-chat")        # 假设 V3
auditor_model = get_deepseek_model("deepseek-reasoner")     # 假设 R1



# -------------------- 节点函数 --------------------
def architect_node(state: AgentState) -> AgentState:
    """Architect 节点：生成 System_Spec.json（符号化需求规范）"""
    from langchain_core.messages import HumanMessage, SystemMessage
    from context_manager import get_context_manager
    import json
    import os
    # 加载系统提示词模板
    prompt_template_path = os.path.join(os.path.dirname(__file__), "prompt_templates.json")
    system_prompt = "你是一个专业的高级渗透测试架构师，擅长分析 CVE 漏洞并设计检测 Payload 逻辑。"
    if os.path.exists(prompt_template_path):
        try:
            with open(prompt_template_path, 'r', encoding='utf-8') as f:
                templates = json.load(f)
                system_prompt = templates.get("architect_system_prompt", system_prompt)
        except Exception as e:
            print(f"[Architect] 读取提示词模板失败: {e}")
    print("[CRITICAL] 进入 architect_node，越过初始化陷阱")
    print("[Architect] 开始生成 System_Spec.json...")
    cm = get_context_manager()
    km = None
    
    # 清除 need_search 标记，防止历史残留导致无限循环
    state['need_search'] = False
    
    # 1. 检索相关知识（硬切除）
    state['relevant_knowledge'] = ""
    print("[Architect] 知识库已硬切除，跳过检索")
    print("[DEBUG] Architect Node Line 160 passed: knowledge retrieval done")
    
    # 1.5 检索错误教训（向量 RAG） - 已注释掉，用于旁路测试
    print("[DEBUG] Architect Node Line 162: before vector search")
    # try:
    #     from vector_service import search_lessons
    #     error_lessons = search_lessons(state['task_description'], top_k=3)
    #     if error_lessons:
    #         lessons_text = "\n## 相关错误教训（向量检索）\n"
    #         for i, lesson in enumerate(error_lessons, 1):
    #             lessons_text += f"{i}. 相似度 {lesson['score']:.3f} | 节点：{lesson['metadata']['node']} | 错误 ID：{lesson['error_id']}\n"
    #             lessons_text += f"   摘要：{lesson['document'][:300]}...\n"
    #         # 追加到 relevant_knowledge
    #         state['relevant_knowledge'] += lessons_text
    #         print(f"[Architect] 向量检索到 {len(error_lessons)} 条相关错误教训")
    #     else:
    #         print("[Architect] 未检索到相关错误教训")
    # except Exception as e:
    #     print(f"[Architect] 向量服务检索失败（不影响流程）: {e}")
    print("[BYPASS] 向量检索已跳过")
    
    print("[DEBUG] Architect Node Line 178: after vector search")
    # 计算相关性评分
    print("[DEBUG] Architect Node Line 183: before get_relevance_score")
    # 硬编码相关性评分以旁路计算死锁
    relevance_score = 1.0
    print(f"[Architect] 知识库相关性评分: {relevance_score:.2f}")
    if relevance_score < 0.0:
        print("[Architect] 相关性评分低于阈值 0.0，触发网络搜索")
        state['need_search'] = True
        print(f"[Architect] need_search set: {state['need_search']}")
        # 保持当前节点为 architect，由 decide_next 决定下一步
        state['current_node'] = "architect"
        return state
    
    print("[DEBUG] Architect Node Line 192: threshold check passed")
    prompt = f"""
你是一个高级渗透测试架构师，负责分析 CVE 漏洞并设计检测 Payload 逻辑。

用户原始需求：
{state['task_description']}

相关历史经验（供参考）：
{state['relevant_knowledge']}

请生成一个详细的 JSON 格式系统规范，包含以下字段：
1. "task_summary": 对漏洞扫描任务的简要概括（1-2句话）
2. "symbolic_requirements": 符号化需求数组，每个需求包含：
   - "id": 需求标识符（如 "REQ-001"）
   - "type": 需求类型，只能是 "detection"（漏洞检测）、"payload"（Payload生成）、"reporting"（报告任务）或 "other"（其他）
   - "description": 需求描述
   - "priority": 优先级（"high"|"medium"|"low"）
   - "acceptance_criteria": 验收标准字符串数组
3. "constraints": 约束对象，包含：
   - "coding_standards": 编码标准列表（如 ["PEP8", "类型注解"]）
   - "security_requirements": 安全要求列表（如 ["禁止使用 eval", "输入验证"]）
   - "performance_requirements": 性能要求列表（可选）
4. "keywords": 从需求中提取的关键词列表（用于后续检索）

示例：
{{
  "task_summary": "针对 CVE-2024-12345 漏洞设计检测 Payload 与报告",
  "symbolic_requirements": [
    {{
      "id": "REQ-001",
      "type": "detection",
      "description": "编写 Python 脚本检测目标系统是否存在 CVE-2024-12345",
      "priority": "high",
      "acceptance_criteria": ["脚本可运行", "输出是否存在漏洞的布尔值"]
    }},
    {{
      "id": "REQ-002",
      "type": "payload",
      "description": "生成针对该漏洞的验证性 Payload（非攻击性）",
      "priority": "medium",
      "acceptance_criteria": ["Payload 可安全执行", "包含详细注释"]
    }},
    {{
      "id": "REQ-003",
      "type": "reporting",
      "description": "生成漏洞分析报告与组会汇报 PPT",
      "priority": "medium",
      "acceptance_criteria": ["Markdown 格式", "包含漏洞详情、影响、修复建议"]
    }}
  ],
  "constraints": {{
    "coding_standards": ["PEP8"],
    "security_requirements": ["禁止使用危险函数", "输入验证"],
    "performance_requirements": []
  }},
  "keywords": ["CVE-2024-12345", "漏洞扫描", "渗透测试", "Payload", "检测脚本"]
}}

请严格按照 JSON 格式输出，不要包含任何额外解释。
"""
    messages = [SystemMessage(content=system_prompt), HumanMessage(content=prompt)]
    from datetime import datetime
    print(f"[Architect] 发起 LLM 请求: {datetime.now().isoformat()}")
    response = architect_model.invoke(messages)
    print(f"[Architect] 接收 LLM 响应: {datetime.now().isoformat()}")
    response_text = response.content if hasattr(response, 'content') else str(response)
    
    # 估算 Token 使用量（简单近似）
    input_tokens = len(prompt) // 4
    output_tokens = len(response_text) // 4
    cm.update_token_usage("architect", input_tokens, output_tokens)
    
    # 解析 JSON
    try:
        # 暴力 JSON 提取逻辑（应对截断与标记缺失）
        cleaned = response_text.strip()
        start_idx = cleaned.find('{')
        end_idx = cleaned.rfind('}')
        if start_idx != -1 and end_idx != -1 and start_idx < end_idx:
            cleaned = cleaned[start_idx:end_idx+1]
        else:
            # 如果连括号都没有，说明彻底坏了
            raise ValueError("响应中找不到有效的 JSON 括号")
        # 额外清理可能残留的 ```json 前缀
        if cleaned.startswith('```json'):
            cleaned = cleaned[7:]
        if cleaned.startswith('```'):
            cleaned = cleaned[3:]
        if cleaned.endswith('```'):
            cleaned = cleaned[:-3]
        cleaned = cleaned.strip()
        system_spec = json.loads(cleaned)
        # 验证必要字段
        required = ["task_summary", "symbolic_requirements", "constraints", "keywords"]
        for field in required:
            if field not in system_spec:
                raise ValueError(f"缺少必要字段: {field}")
        state['system_spec'] = system_spec
        # 同时设置 blueprint 字段以保持向后兼容（将 symbolic_requirements 映射为 subtasks）
        # 简单映射：将每个 symbolic_requirement 转换为 subtask
        subtasks = []
        for req in system_spec['symbolic_requirements']:
            # 根据描述推测类型
            desc = req['description'].lower()
            if '代码' in desc or 'script' in desc or 'demo' in desc:
                task_type = "coding"
            elif '报告' in desc or '演讲' in desc or 'report' in desc:
                task_type = "reporting"
            elif 'ppt' in desc or '演示' in desc or 'presentation' in desc:
                task_type = "presentation"
            else:
                task_type = "coding"
            subtasks.append({
                "type": task_type,
                "description": req['description'],
                "acceptance_criteria": req['acceptance_criteria']
            })
        state['blueprint'] = {
            "task_summary": system_spec['task_summary'],
            "subtasks": subtasks,
            "keywords": system_spec['keywords']
        }
        state['error_message'] = None
        print(f"[Architect] System_Spec 生成成功，包含 {len(system_spec['symbolic_requirements'])} 个符号需求")
    except Exception as e:
        state['error_message'] = f"Architect 节点解析 System_Spec 失败: {e}\n原始响应:\n{response_text}"
        print(f"[Architect] 错误: {state['error_message']}")
    
    # 上下文蒸馏
    consensus = cm.distill(state)
    state['current_consensus'] = consensus
    
    state['current_node'] = "architect"
    return state


def coder_node(state: AgentState) -> AgentState:
    """Coder 节点：基于 System_Spec 与 Hard_Constraints 编写代码，并检索错误知识库"""
    from langchain_core.messages import HumanMessage, SystemMessage
    from context_manager import get_context_manager
    print("[Coder] 开始编写代码（协议驱动）...")
    cm = get_context_manager()
    
    # 优先使用 system_spec，否则回退到 blueprint
    system_spec = state.get('system_spec')
    blueprint = state.get('blueprint')
    if not system_spec and not blueprint:
        state['error_message'] = "Coder 节点：未找到系统规范或蓝图"
        state['current_node'] = "coder"
        return state
    
    # 提取 coding 子任务（优先使用 type 字段，其次描述关键词，最后兜底）
    coding_requirements = []
    if system_spec:
        # 1. 使用 type 字段精确匹配
        for req in system_spec.get('symbolic_requirements', []):
            req_type = req.get('type', '').lower()
            if req_type == 'coding':
                coding_requirements.append(req)
        
        # 2. 若未找到，使用描述关键词模糊匹配（向后兼容）
        if not coding_requirements:
            for req in system_spec.get('symbolic_requirements', []):
                desc = req['description'].lower()
                if any(keyword in desc for keyword in ['代码', 'script', 'demo', 'coding', '程序', '编程', '实现', '脚本']):
                    coding_requirements.append(req)
        
        # 3. 兜底：若仍然为空，将第一个需求视为 coding 需求（强制继续流程）
        if not coding_requirements:
            first_req = system_spec.get('symbolic_requirements', [])
            if first_req:
                coding_requirements.append(first_req[0])
                print(f"[Coder] 警告：未识别出 coding 需求，将第一个需求 '{first_req[0].get('description')}' 作为编码任务执行")
    else:
        # 从旧版 blueprint 中提取
        for subtask in blueprint['subtasks']:
            if subtask['type'] == 'coding':
                coding_requirements.append({
                    'id': f"LEGACY-{subtask['description'][:10]}",
                    'description': subtask['description'],
                    'acceptance_criteria': subtask['acceptance_criteria']
                })
    
    # 终极兜底：若 coding_requirements 仍为空，回退到原始任务描述（避免死循环）
    if not coding_requirements:
        # 将原始任务描述作为虚拟需求，确保流程继续
        coding_requirements.append({
            'id': 'FALLBACK-001',
            'description': state['task_description'],
            'acceptance_criteria': ['完成用户要求的任务']
        })
        print(f"[Coder] 严重警告：无任何 coding 需求，回退到原始任务描述进行编码")
    
    # 使用第一个 coding 需求
    req = coding_requirements[0]
    description = req['description']
    acceptance = req['acceptance_criteria']
    
    # 构建 Hard_Constraints（从 system_spec 的 constraints 字段提取）
    hard_constraints = []
    if system_spec:
        constraints = system_spec.get('constraints', [])
        if isinstance(constraints, list):
            for c in constraints:
                hard_constraints.append({
                    'type': c.get('type', 'unknown'),
                    'rule': c.get('description', ''),
                    'severity': c.get('severity', 'medium')
                })
        elif isinstance(constraints, dict):
            for key, val in constraints.items():
                if isinstance(val, list):
                    for item in val:
                        hard_constraints.append({
                            'type': key,
                            'rule': item,
                            'severity': 'high' if '禁止' in item else 'medium'
                        })
    # 存入状态供后续审计使用
    state['hard_constraints'] = hard_constraints
    
    # 检索错误知识库（相关教训）
    error_keywords = ['coding', 'security', 'bug', 'vulnerability', 'test']
    if system_spec:
        error_keywords.extend(system_spec.get('keywords', []))
    lessons = cm.get_error_vault(error_keywords)
    lessons_text = '\n'.join(lessons[:3])  # 最多三条教训
    
    # 检索相关知识
    relevant_knowledge = state.get('relevant_knowledge', '')
    
    prompt = f"""
你是一个资深软件工程师。请根据以下需求编写代码。

需求描述：{description}
验收标准：{acceptance}

硬性约束（必须遵守）：
{json.dumps(hard_constraints, ensure_ascii=False, indent=2)}

历史错误教训（请避免重复）：
{lessons_text}

相关历史经验（供参考）：
{relevant_knowledge}

【严格警告】你的输出长度极其受限！禁止写任何解释性文字，只允许输出 JSON。测试代码和源代码必须尽可能精简核心逻辑。

要求：
1. 遵循“代码红线”原则：在编写 /src 代码之前，先在 /tests 目录中编写对应的 pytest 测试用例。
2. 测试用例应覆盖主要功能与边界情况。
3. 代码应简洁、可读、符合 PEP 8 规范，并严格遵守上述硬性约束（尤其是安全约束）。
4. 输出应包含两个部分：
   - 测试文件路径与内容
   - 源代码文件路径与内容

请以 JSON 格式输出，例如：
{{
  "test_files": [
    {{"path": "tests/test_xxx.py", "content": "..."}}
  ],
  "src_files": [
    {{"path": "src/xxx.py", "content": "..."}}
  ]
}}
"""
    messages = [SystemMessage(content="你是一个遵循 TDD 的软件工程师，特别注重安全性与约束遵守。"), HumanMessage(content=prompt)]
    response = coder_model.invoke(messages)
    response_text = response.content if hasattr(response, 'content') else str(response)
    
    # 估算 Token 使用量
    input_tokens = len(prompt) // 4
    output_tokens = len(response_text) // 4
    cm.update_token_usage("coder", input_tokens, output_tokens)
    
    # 暴力 JSON 提取逻辑（应对截断与标记缺失）
    cleaned_text = response_text.strip()
    start_idx = cleaned_text.find('{')
    end_idx = cleaned_text.rfind('}')
    if start_idx != -1 and end_idx != -1 and start_idx < end_idx:
        cleaned_text = cleaned_text[start_idx:end_idx+1]
    else:
        # 如果连括号都没有，说明彻底坏了
        raise ValueError("响应中找不到有效的 JSON 括号")
    
    # 调试：打印清理后的文本长度和前200字符
    print(f"[Coder 调试] 清理后文本长度: {len(cleaned_text)}, 前200字符: {cleaned_text[:200]}")
    
    try:
        # 暴力 JSON 提取逻辑（应对截断与标记缺失）
        cleaned_text = response_text.strip()
        start_idx = cleaned_text.find('{')
        end_idx = cleaned_text.rfind('}')
        if start_idx != -1 and end_idx != -1 and start_idx < end_idx:
            cleaned_text = cleaned_text[start_idx:end_idx+1]
        else:
            # 如果连括号都没有，说明彻底坏了
            raise ValueError("响应中找不到有效的 JSON 括号")
        
        # 调试：打印清理后的文本长度和前200字符
        print(f"[Coder 调试] 清理后文本长度: {len(cleaned_text)}, 前200字符: {cleaned_text[:200]}")
        
        data = json.loads(cleaned_text)
        test_files = data.get("test_files", [])
        src_files = data.get("src_files", [])
    except (ValueError, json.JSONDecodeError) as e:
        state['error_message'] = f"Coder 节点：响应不是有效的 JSON（提取内容前500字符）\n{cleaned_text[:500]}"
        state['current_node'] = "coder"
        return state
    
    # 写入文件（沙盒机制：先写入 staging/ 目录）
    file_tools = FileTools()
    written_files = []
    import os
    for file_info in test_files + src_files:
        original_path = file_info["path"]
        # 重定向到 staging 目录
        if original_path.startswith("src/"):
            staged_path = "src/staging/" + original_path[4:]  # 移除 src/
        elif original_path.startswith("tests/"):
            staged_path = "staging/" + original_path  # 保持 tests/ 前缀
        else:
            staged_path = "staging/" + original_path
        
        # 确保目标目录存在
        os.makedirs(os.path.dirname(staged_path), exist_ok=True)
        
        result = file_tools.write_file(staged_path, file_info["content"])
        if result["success"]:
            written_files.append(original_path)  # 记录原始路径，方便审计
            print(f"[Coder] 代码已安全写入沙盒: {staged_path} (原始路径: {original_path})")
        else:
            state['error_message'] = f"Coder 节点：写入沙盒文件失败 {staged_path} (原始路径: {original_path})"
            state['current_node'] = "coder"
            return state
    
    # 记录交付物路径
    state.setdefault('deliverables', {})['code'] = written_files[0] if written_files else ""
    state['error_message'] = None
    
    # 上下文蒸馏
    consensus = cm.distill(state)
    state['current_consensus'] = consensus
    
    state['current_node'] = "coder"
    print(f"[Coder] 已编写 {len(written_files)} 个文件，并应用了 {len(hard_constraints)} 条硬性约束。")
    return state


def reporter_node(state: AgentState) -> AgentState:
    """Reporter 节点：生成技术报告与演讲稿"""
    from langchain_core.messages import HumanMessage, SystemMessage
    from context_manager import get_context_manager
    print("[Reporter] 开始生成报告...")
    # 模拟模式：跳过实际生成，直接返回成功
    if os.getenv('DEEPSEEK_API_KEY', '').strip() == 'test':
        print("[Reporter] 模拟模式：跳过报告生成，直接通过")
        # 创建模拟报告文件
        import uuid
        report_path = f"report_{uuid.uuid4().hex[:8]}.md"
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write("# 技术报告（模拟）\n\n基于 System_Spec 与 Hard_Constraints 生成的模拟技术报告。")
        state.setdefault('deliverables', {})['report'] = report_path
        state['error_message'] = None
        state['current_node'] = "reporter"
        # 更新 token 使用量
        cm = get_context_manager()
        cm.update_token_usage("reporter", 100, 0)
        # 上下文蒸馏（提取共识，不覆盖状态）
        consensus = cm.distill(state)
        state['current_consensus'] = consensus
        return state
    
    blueprint = state.get('blueprint')
    if not blueprint:
        state['error_message'] = "Reporter 节点：未找到蓝图"
        state['current_node'] = "reporter"
        return state
    
    # 查找 reporting 类型的子任务
    reporting_subtasks = [st for st in blueprint['subtasks'] if st['type'] == 'reporting']
    if not reporting_subtasks:
        state['error_message'] = "Reporter 节点：蓝图中没有 reporting 子任务"
        state['current_node'] = "reporter"
        return state
    
    subtask = reporting_subtasks[0]
    description = subtask['description']
    acceptance = subtask['acceptance_criteria']
    
    # 检索相关知识
    relevant_knowledge = state.get('relevant_knowledge', '')
    
    prompt = f"""
你是一个技术文档工程师。请根据以下子任务编写技术报告与演讲稿。

子任务描述：{description}
验收标准：{acceptance}

相关历史经验（供参考）：
{relevant_knowledge}

要求：
1. 技术报告采用 Markdown 格式，包含背景、方法、结果、结论等章节。
2. 演讲稿面向 3 分钟口头汇报，语言精炼、重点突出。
3. 输出应包含两个文件：
   - 技术报告文件（路径：docs/reports/bandit_scan_report.md）
   - 演讲稿文件（路径：docs/reports/bandit_speech.md）

请以 JSON 格式输出，例如：
{{
  "report_file": {{"path": "docs/reports/bandit_scan_report.md", "content": "..."}},
  "speech_file": {{"path": "docs/reports/bandit_speech.md", "content": "..."}}
}}
"""
    messages = [SystemMessage(content="你是一名专业的技术文档工程师。"), HumanMessage(content=prompt)]
    response = reporter_model.invoke(messages)
    response_text = response.content if hasattr(response, 'content') else str(response)
    
    try:
        # 暴力 JSON 提取逻辑（应对截断与标记缺失）
        cleaned_text = response_text.strip()
        start_idx = cleaned_text.find('{')
        end_idx = cleaned_text.rfind('}')
        if start_idx != -1 and end_idx != -1 and start_idx < end_idx:
            cleaned_text = cleaned_text[start_idx:end_idx+1]
        else:
            # 如果连括号都没有，说明彻底坏了
            raise ValueError("响应中找不到有效的 JSON 括号")
        # 额外清理可能残留的 ```json 前缀
        if cleaned_text.startswith('```json'):
            cleaned_text = cleaned_text[7:]
        if cleaned_text.startswith('```'):
            cleaned_text = cleaned_text[3:]
        if cleaned_text.endswith('```'):
            cleaned_text = cleaned_text[:-3]
        cleaned_text = cleaned_text.strip()
        
        data = json.loads(cleaned_text)
        report_file = data.get("report_file")
        speech_file = data.get("speech_file")
    except (ValueError, json.JSONDecodeError) as e:
        state['error_message'] = f"Reporter 节点：响应不是有效的 JSON（提取内容前500字符）\n{cleaned_text[:500]}"
        state['current_node'] = "reporter"
        return state
    
    # 写入文件
    file_tools = FileTools()
    deliverables = state.setdefault('deliverables', {})
    for file_info in [report_file, speech_file]:
        if not file_info:
            continue
        result = file_tools.write_file(file_info["path"], file_info["content"])
        if not result["success"]:
            state['error_message'] = f"Reporter 节点：写入文件失败 {file_info['path']}"
            state['current_node'] = "reporter"
            return state
        # 记录路径
        if "report" in file_info["path"]:
            deliverables['report'] = file_info["path"]
        else:
            deliverables['speech'] = file_info["path"]
    
    state['error_message'] = None
    state['current_node'] = "reporter"
    print("[Reporter] 报告生成完成。")
    return state


def presenter_node(state: AgentState) -> AgentState:
    """Presenter 节点：根据报告内容生成 PowerPoint 演示文稿"""
    print("[Presenter] 开始生成 PPT...")
    # 检查是否有报告文件
    deliverables = state.get('deliverables', {})
    report_path = deliverables.get('report')
    if not report_path or not os.path.exists(report_path):
        state['error_message'] = "Presenter 节点：找不到技术报告文件"
        state['current_node'] = "presenter"
        return state
    
    # 读取报告内容
    file_tools = FileTools()
    report_content = file_tools.read_file(report_path)
    
    # 动态生成 PPT 文件名（基于任务描述或时间戳）
    import time
    task_desc = state.get('task_description', 'unknown_task')
    # 提取前几个单词作为文件名
    safe_name = ''.join(c if c.isalnum() else '_' for c in task_desc[:30])
    ppt_dir = "deliverables"
    os.makedirs(ppt_dir, exist_ok=True)
    ppt_path = f"{ppt_dir}/{safe_name}_{int(time.time())}.pptx"
    
    # 尝试导入 python-pptx，如果失败则尝试安装
    try:
        from pptx import Presentation
        pptx_available = True
    except ImportError:
        pptx_available = False
        print("[Presenter] 检测到 python-pptx 未安装，尝试通过 pip 安装...")
        try:
            import subprocess
            subprocess.check_call([sys.executable, "-m", "pip", "install", "python-pptx"])
            from pptx import Presentation
            pptx_available = True
            print("[Presenter] python-pptx 安装成功。")
        except Exception as install_e:
            print(f"[Presenter] 安装 python-pptx 失败: {install_e}")
    
    # 生成 PPT
    if pptx_available:
        try:
            prs = Presentation()
            # 标题页
            title_slide = prs.slides.add_slide(prs.slide_layouts[0])
            title_slide.shapes.title.text = task_desc[:50] + " 报告"
            subtitle = title_slide.placeholders[1]
            subtitle.text = "AI 生成的技术汇报"
            # 内容页：基于报告摘要（简化）
            bullet_slide = prs.slides.add_slide(prs.slide_layouts[1])
            bullet_slide.shapes.title.text = "核心要点"
            bullet_body = bullet_slide.placeholders[1]
            tf = bullet_body.text_frame
            # 从报告内容中提取前三个要点（这里简化处理）
            tf.text = "1. 报告已生成"
            p = tf.add_paragraph()
            p.text = "2. 详细内容请查看原始报告文件"
            p = tf.add_paragraph()
            p.text = "3. 本 PPT 由天灵 AI 自动生成"
            
            # 如果存在经验教训，添加一页
            lessons = state.get('lessons_learned', [])
            if lessons:
                logic_slide = prs.slides.add_slide(prs.slide_layouts[1])
                logic_slide.shapes.title.text = "AI 学习历程"
                logic_body = logic_slide.placeholders[1]
                tf_logic = logic_body.text_frame
                tf_logic.text = "从错误中学习的经验教训："
                for lesson in lessons[:5]:
                    trigger = lesson.get('trigger_node', 'unknown')
                    cause = lesson.get('root_cause', '')[:50]
                    tf_logic.add_paragraph().text = f"• {trigger}: {cause}"
            
            prs.save(ppt_path)
            print(f"[Presenter] PPT 已生成（使用 python-pptx）：{ppt_path}")
        except Exception as e:
            print(f"[Presenter] 使用 python-pptx 生成 PPT 时出错: {e}")
            pptx_available = False  # 降级
    
    if not pptx_available:
        # 降级方案：生成一个文本文件作为基础版 PPT
        print("[Presenter] 使用基础版 PPT 生成（文本文件）")
        with open(ppt_path, 'w', encoding='utf-8') as f:
            f.write("# PowerPoint 占位文件\n\n")
            f.write(f"任务: {task_desc}\n\n")
            f.write("由于缺少 python-pptx 库，无法生成标准 PPT 文件。\n")
            f.write("请安装 python-pptx 以获得完整功能。\n\n")
            f.write("报告内容摘要:\n")
            f.write(report_content[:500] + "...\n")
        print(f"[Presenter] 基础版 PPT 已生成：{ppt_path}")
    
    deliverables['ppt'] = ppt_path
    state['error_message'] = None
    state['current_node'] = "presenter"
    return state


def search_node(state: AgentState) -> AgentState:
    """Search 节点：当知识库相关性不足时，执行网络搜索并存入临时知识库"""
    print("[Search] 开始网络搜索...")
    # 重试计数器
    retry_count = state.get('search_retry_count', 0)
    print(f"[Search] 当前重试次数: {retry_count}")
    task_desc = state.get('task_description', '')
    if not task_desc:
        state['error_message'] = "Search 节点：任务描述为空"
        state['current_node'] = "search"
        return state
    
    # 使用 ddgs 进行搜索
    try:
        from ddgs import DDGS
        ddgs = DDGS()
        # 搜索关键词：从任务描述中提取前几个词
        keywords = task_desc.split()[:5]
        query = ' '.join(keywords)
        print(f"[Search] 搜索查询: {query}")
        results = ddgs.text(query, max_results=5)
        search_texts = []
        for i, r in enumerate(results):
            title = r.get('title', '')
            snippet = r.get('body', '')
            link = r.get('href', '')
            search_texts.append(f"### {title}\n{snippet}\n来源: {link}\n")
        
        if search_texts:
            search_content = "\n\n".join(search_texts)
            # 将搜索结果存入临时知识库文件
            import time
            temp_file = f".ai_knowledge/temp_search_{int(time.time())}.md"
            os.makedirs(".ai_knowledge", exist_ok=True)
            with open(temp_file, 'w', encoding='utf-8') as f:
                f.write(f"# 网络搜索结果（任务: {task_desc}）\n\n")
                f.write(search_content)
            print(f"[Search] 搜索结果已保存到 {temp_file}")
            
            # 刷新知识管理器，使其加载新文件
            global km
            km.refresh()
            
            # 将搜索结果添加到 relevant_knowledge 字段（供后续节点使用）
            state['relevant_knowledge'] = search_content
            # 搜索成功，重置重试计数器
            retry_count = 0
        else:
            print("[Search] 未找到搜索结果")
            # 增加重试计数
            retry_count += 1
            state['search_retry_count'] = retry_count
            # 检查是否达到阈值（连续2次无结果）
            if retry_count >= 2:
                print(f"[Search] 重试次数已达上限 ({retry_count})，强制关闭搜索并转向 Architect")
                state['need_search'] = False
                state['relevant_knowledge'] = ''
                state['current_node'] = "architect"
                state['error_message'] = None
                return state
            else:
                state['relevant_knowledge'] = "网络搜索未找到相关信息。"
    except Exception as e:
        print(f"[Search] 搜索过程中出错: {e}")
        # 增加重试计数
        retry_count += 1
        state['search_retry_count'] = retry_count
        # 检查是否达到阈值
        if retry_count >= 2:
            print(f"[Search] 重试次数已达上限 ({retry_count})，强制关闭搜索并转向 Architect")
            state['need_search'] = False
            state['relevant_knowledge'] = ''
            state['current_node'] = "architect"
            state['error_message'] = None
            return state
        else:
            state['error_message'] = f"Search 节点异常: {e}"
            state['current_node'] = "search"
            return state
    
    # 保存最新的重试计数（成功时已重置，失败时已更新）
    state['search_retry_count'] = retry_count
    state['error_message'] = None
    state['need_search'] = False
    state['search_performed'] = True
    state['current_node'] = "architect"
    return state


def auditor_node(state: AgentState) -> AgentState:
    """Auditor 节点：根据协议产出 Diagnostic_Vector，集成神经符号验证闸门（Bandit）"""
    print("[Auditor] 开始审计（协议驱动版）...")
    from context_manager import get_context_manager
    cm = get_context_manager()
    
    # 模拟模式：直接通过所有审计，避免无限循环
    if os.getenv('DEEPSEEK_API_KEY', '').strip() == 'test':
        print("[Auditor] 模拟模式：跳过实际测试，审计自动通过")
        current = state.get('current_node', '')
        if current == 'coder' or current == 'auditor_code':
            state.setdefault('audit_results', {})['code'] = True
            diagnostic = {
                "errors": [],
                "warnings": [],
                "passed_checks": ["模拟模式：所有检查自动通过"],
                "verdict": "pass",
                "symbolic_scan_summary": {}
            }
            state['diagnostic_vector'] = diagnostic
        elif current == 'reporter' or current == 'auditor_report':
            state.setdefault('audit_results', {})['report'] = True
            diagnostic = {
                "errors": [],
                "warnings": [],
                "passed_checks": ["模拟模式：报告文件存在"],
                "verdict": "pass",
                "symbolic_scan_summary": {}
            }
            state['diagnostic_vector'] = diagnostic
        elif current == 'presenter' or current == 'auditor_ppt':
            state.setdefault('audit_results', {})['ppt'] = True
            diagnostic = {
                "errors": [],
                "warnings": [],
                "passed_checks": ["模拟模式：PPT文件存在"],
                "verdict": "pass",
                "symbolic_scan_summary": {}
            }
            state['diagnostic_vector'] = diagnostic
        state['error_message'] = None
        # 更新 token 使用量（模拟）
        cm.update_token_usage("auditor", 50, 0)
        # 上下文蒸馏（提取共识，不覆盖状态）
        consensus = cm.distill(state)
        state['current_consensus'] = consensus
        # 根据审计类型设置当前节点名称
        if current == 'coder' or current == 'auditor_code':
            state['current_node'] = "auditor_code"
        elif current == 'reporter' or current == 'auditor_report':
            state['current_node'] = "auditor_report"
        elif current == 'presenter' or current == 'auditor_ppt':
            state['current_node'] = "auditor_ppt"
        else:
            state['current_node'] = current
        return state
    
    # 协议驱动：不再依赖 blueprint，而是根据 current_node 决定审计类型
    current = state.get('current_node', '')
    
    # 初始化诊断向量结构
    diagnostic = {
        "errors": [],
        "warnings": [],
        "passed_checks": [],
        "verdict": "pass",
        "symbolic_scan_summary": {}
    }
    
    # 根据当前节点类型执行相应审计（coder、auditor_code、debate 均触发代码审计）
    if current in ('coder', 'auditor_code', 'debate'):
        audit_key = 'code'
        print(f"[Auditor] 代码审计（神经符号验证闸门）...")
        
        # 确定沙盒路径（优先使用 staging 目录）
        staging_dir = "staging"
        if os.path.exists(staging_dir):
            scan_cwd = staging_dir
            print(f"[Auditor] 检测到沙盒目录 {staging_dir}，将在其中执行扫描与测试")
        else:
            scan_cwd = "."
            print("[Auditor] 未检测到沙盒目录，将在根目录执行扫描与测试")
        
        # 1. 神经符号验证闸门：Bandit 静态扫描（针对沙盒目录）
        terminal_tools = TerminalTools()
        bandit_result = terminal_tools.run_command(f"bandit -r . -f json", cwd=scan_cwd)
        bandit_issues = []
        if bandit_result.get("success"):
            try:
                bandit_output = bandit_result.get("stdout", "")
                if bandit_output.strip():
                    bandit_data = json.loads(bandit_output)
                    # 提取高严重性问题
                    for issue in bandit_data.get("results", []):
                        severity = issue.get("issue_severity", "").lower()
                        if severity in ("high", "medium"):
                            bandit_issues.append({
                                "file": os.path.join(scan_cwd, issue.get("filename", "")),
                                "line": issue.get("line_number", 0),
                                "severity": severity,
                                "category": issue.get("issue_cwe", {}).get("name", "security"),
                                "message": issue.get("issue_text", "")
                            })
            except json.JSONDecodeError:
                pass
        
        if bandit_issues:
            # Bandit 发现高严重性问题 → 诊断向量标记为失败，直接打回 Coder
            diagnostic["errors"].extend(bandit_issues)
            diagnostic["verdict"] = "fail"
            diagnostic["symbolic_scan_summary"] = {
                "bandit_scan": "failed",
                "high_severity_count": len(bandit_issues)
            }
            state['error_message'] = f"Bandit 静态扫描发现 {len(bandit_issues)} 个高危/中危安全问题，禁止调用 LLM，直接返回给 Coder 修复"
            print(f"[Auditor] 神经符号验证闸门拦截：{state['error_message']}")
        else:
            # Bandit 通过，继续语义审计（可选）
            diagnostic["passed_checks"].append("Bandit 静态扫描通过，无高危/中危安全问题")
            diagnostic["symbolic_scan_summary"]["bandit_scan"] = "passed"
            
            # 2. 语义审计（原 pytest 测试）
            # 检测是否存在 tests/ 目录（在沙盒内）
            if os.path.exists(os.path.join(scan_cwd, "tests")):
                test_cmd = "pytest -v"
            else:
                # 可能在 src/staging/ 等位置，直接运行 pytest 会递归查找
                test_cmd = "pytest -v"
            test_result = terminal_tools.run_command(test_cmd, cwd=scan_cwd)
            if test_result.get("success"):
                diagnostic["passed_checks"].append("单元测试全部通过")
                diagnostic["verdict"] = "pass"
                state['error_message'] = None
                print("[Auditor] 语义审计通过：测试全部通过")
            else:
                diagnostic["errors"].append({
                    "file": f"{scan_cwd}/tests/",
                    "line": 0,
                    "severity": "medium",
                    "category": "functional",
                    "message": f"单元测试失败：{test_result.get('stderr', '')[:200]}"
                })
                diagnostic["verdict"] = "fail"
                state['error_message'] = f"语义审计失败：测试未通过\n{test_result.get('stderr', '')[:500]}"
                print("[Auditor] 语义审计失败")
        
        # 设置审计结果（向后兼容）
        state.setdefault('audit_results', {})['code'] = (diagnostic["verdict"] == "pass")
        
    elif current == 'reporter' or current == 'auditor_report':
        audit_key = 'report'
        print(f"[Auditor] 报告审计...")
        # 检查报告文件是否存在且非空
        deliverables = state.get('deliverables', {})
        report_path = deliverables.get('report')
        speech_path = deliverables.get('speech')
        if report_path and os.path.exists(report_path) and speech_path and os.path.exists(speech_path):
            diagnostic["passed_checks"].append("报告文件存在且非空")
            diagnostic["verdict"] = "pass"
            state['error_message'] = None
            print("[Auditor] 报告审计通过：文件完整")
        else:
            diagnostic["errors"].append({
                "file": report_path or speech_path or "unknown",
                "line": 0,
                "severity": "low",
                "category": "deliverable",
                "message": "报告或演讲稿文件缺失"
            })
            diagnostic["verdict"] = "fail"
            state['error_message'] = "报告审计失败：文件缺失"
            print("[Auditor] 报告审计失败：文件缺失")
        state.setdefault('audit_results', {})['report'] = (diagnostic["verdict"] == "pass")
        
    elif current == 'presenter' or current == 'auditor_ppt':
        audit_key = 'ppt'
        print(f"[Auditor] PPT 审计...")
        ppt_path = state.get('deliverables', {}).get('ppt')
        if ppt_path and os.path.exists(ppt_path):
            diagnostic["passed_checks"].append("PPT 文件存在")
            diagnostic["verdict"] = "pass"
            state['error_message'] = None
            print("[Auditor] PPT 审计通过：文件存在")
        else:
            diagnostic["errors"].append({
                "file": ppt_path or "unknown",
                "line": 0,
                "severity": "low",
                "category": "deliverable",
                "message": "PPT 文件不存在"
            })
            diagnostic["verdict"] = "fail"
            state['error_message'] = "PPT 审计失败：文件不存在"
            print("[Auditor] PPT 审计失败：文件不存在")
        state.setdefault('audit_results', {})['ppt'] = (diagnostic["verdict"] == "pass")
        
    else:
        # 未知节点类型，视为通过
        diagnostic["verdict"] = "pass"
        state['error_message'] = None
        print(f"[Auditor] 未知节点类型 {current}，视为通过")
    
    # 保存诊断向量到状态
    state['diagnostic_vector'] = diagnostic
    
    # 更新 token 使用量（估算审计过程消耗）
    token_estimate = 200  # 简单估算
    cm.update_token_usage("auditor", token_estimate, 0)
    
    # 上下文蒸馏：提取共识，丢弃冗余对话
    consensus = cm.distill(state)
    state['current_consensus'] = consensus
    
    # 保持当前节点名称不变（例如 auditor_code）
    # 根据审计类型设置当前节点名称
    if current in ('coder', 'auditor_code', 'debate'):
        state['current_node'] = "auditor_code"
    elif current in ('reporter', 'auditor_report'):
        state['current_node'] = "auditor_report"
    elif current in ('presenter', 'auditor_ppt'):
        state['current_node'] = "auditor_ppt"
    else:
        state['current_node'] = current
    return state


def reflection_node(state: AgentState) -> AgentState:
    """Reflection 节点：从诊断向量提取教训，存入错误知识库"""
    print("[Reflection] 开始反思...")
    # 强制清除错误，跳过向量检索
    state['error_message'] = None
    state['current_node'] = "reflection"
    print("[Reflection] 强制跳过，错误已清除")
    return state
    if error_msg or (diagnostic and diagnostic.get('verdict') == 'fail'):
        # 生成错误ID
        import uuid
        error_id = str(uuid.uuid4())[:8]
        from datetime import datetime
        lesson = {
            "error_id": error_id,
            "timestamp": datetime.now().isoformat(),
            "trigger_node": current_node,
            "error_type": "audit_failure",
            "code_snippet": "",
            "fix_suggestion": "根据诊断向量修复问题",
            "root_cause": error_msg or "诊断向量标记为失败",
            "prevention": "加强前置验证，优化约束"
        }
        # 如果有诊断错误细节，可以提取
        if diagnostic and diagnostic.get('errors'):
            first_error = diagnostic['errors'][0]
            lesson['code_snippet'] = f"{first_error.get('file')}:{first_error.get('line')} - {first_error.get('message')}"
            lesson['error_type'] = first_error.get('category', 'security')
        
        # 向量检索相关历史教训（Top‑3）
        try:
            from vector_service import search_lessons
            # 使用错误描述作为查询
            query = error_msg or lesson['root_cause']
            related = search_lessons(query, top_k=3)
            if related:
                lesson['related_lessons'] = [
                    {"error_id": r['error_id'], "score": r['score'], "node": r['metadata']['node']}
                    for r in related
                ]
                print(f"[Reflection] 向量检索到 {len(related)} 条相关历史教训")
                # 将相关教训摘要打印到日志
                for r in related:
                    print(f"      相似度 {r['score']:.3f} | {r['metadata']['node']} | {r['error_id']}")
            else:
                lesson['related_lessons'] = []
        except Exception as e:
            print(f"[Reflection] 向量检索失败（不影响记录）: {e}")
            lesson['related_lessons'] = []
        
        # 追加到错误库
        cm.append_error_vault(lesson)
        print(f"[Reflection] 已记录教训 {error_id} 到错误知识库")
        
        # 更新状态中的 lessons_learned 列表
        state.setdefault('lessons_learned', []).append(lesson)
    
    # 更新 token 使用量
    cm.update_token_usage("reflection", 50, 0)
    
    # 上下文蒸馏（提取共识，不覆盖状态）
    consensus = cm.distill(state)
    state['current_consensus'] = consensus
    
    # 设置当前节点为 reflection，以便 decide_next 正确处理
    state['current_node'] = "reflection"
    # 清除幽灵报错，防止状态机死循环
    state['error_message'] = None
    return state


# -------------------- 任务拆解节点 --------------------
def split_node(state: AgentState) -> AgentState:
    """
    任务拆解节点：当 Token 预算超限时，将当前任务拆分为多个子任务，
    存入 .task_state/ 目录，并将第一个子任务设为当前任务描述。
    """
    print("[Split] 开始任务拆解...")
    task_desc = state.get('task_description', '')
    if not task_desc:
        state['error_message'] = "Split 节点：任务描述为空"
        state['current_node'] = "split"
        return state
    
    # 简单的拆解策略：按句号分割，取前两个子任务（演示用）
    import re
    sentences = re.split(r'[。！？]', task_desc)
    sentences = [s.strip() for s in sentences if s.strip()]
    # 如果句子太少，按逗号分割
    if len(sentences) <= 1:
        sentences = [task_desc]
    else:
        sentences = sentences[:2]  # 仅拆为两个子任务
    
    # 创建 .task_state 目录
    import os
    os.makedirs('.task_state', exist_ok=True)
    
    # 保存子任务文件
    subtasks = []
    for i, sent in enumerate(sentences):
        subtask_file = f'.task_state/subtask_{i}.txt'
        with open(subtask_file, 'w', encoding='utf-8') as f:
            f.write(sent)
        subtasks.append(subtask_file)
        print(f"[Split] 子任务 {i} 已保存到 {subtask_file}")
    
    # 将第一个子任务设为当前任务描述
    new_task = sentences[0]
    state['task_description'] = new_task
    # 记录剩余子任务列表，供外部编排器使用
    state['remaining_subtasks'] = subtasks[1:] if len(subtasks) > 1 else []
    state['subtask_index'] = 0
    state['total_subtasks'] = len(subtasks)
    
    # 清除错误，进入 Architect 节点处理新的（更小的）任务
    state['error_message'] = None
    state['need_search'] = False
    state['current_node'] = "architect"
    print(f"[Split] 任务拆解完成，当前任务描述已更新为第一个子任务（共 {len(subtasks)} 个）")
    return state


# -------------------- MemoryGate 节点 --------------------
def memory_gate_node(state: AgentState) -> AgentState:
    """
    MemoryGate 节点：动态上下文压缩。
    将长对话历史压缩为精炼的 JSON 摘要，减少 Token 浪费。
    """
    print("[MemoryGate] 开始动态上下文压缩...")
    from context_manager import get_context_manager
    # 获取上下文管理器
    cm = get_context_manager()
    
    # 提取当前对话历史（假设存储在 state['conversation_history'] 中）
    # 如果不存在，则使用任务描述作为压缩文本
    long_text = state.get('conversation_history', state.get('task_description', ''))
    if not long_text:
        print("[MemoryGate] 没有可压缩的文本，跳过")
        state['current_node'] = "memory_gate"
        return state
    
    # 导入 MemoryGate 类（假设 memory_gate.py 已存在）
    try:
        from memory_gate import MemoryGate
    except ImportError:
        # 如果导入失败，使用简化实现
        print("[MemoryGate] 无法导入 MemoryGate 类，使用模拟压缩")
        compressed = {"summary": long_text[:200], "key_points": [], "original_length": len(long_text), "compressed_length": min(200, len(long_text))}
    else:
        mg = MemoryGate()
        compressed = mg.compress(long_text)
    
    # 将压缩后的摘要存储到状态中
    state['compressed_context'] = compressed
    # 更新 token 使用量（模拟）
    cm.update_token_usage("memory_gate", len(long_text) // 4, len(str(compressed)) // 4)
    
    print(f"[MemoryGate] 压缩完成，原始长度 {len(long_text)}，压缩后摘要长度 {len(str(compressed))}")
    state['current_node'] = "memory_gate"
    return state


# -------------------- 条件边 --------------------
def decide_next(state: AgentState) -> Literal["coder", "reporter", "presenter", "auditor_code", "auditor_report", "auditor_ppt", "reflection", "search", "split", "debate", "end"]:
    """根据当前节点和审计结果决定下一步（支持反思节点与辩论节点）"""
    from context_manager import get_context_manager
    current = state.get('current_node', '')
    error = state.get('error_message')
    audit_results = state.get('audit_results', {})
    print(f"[决策调试] current={current}, error={error}, audit_results={audit_results}")
    print(f"[TRACE] Router Input: error={error}, node={current}, need_search={state.get('need_search')}, audit_results={audit_results}")
    
    # 检查 Token 预算是否超限
    cm = get_context_manager()
    if not cm.is_within_budget(5000):
        print("[决策] Token 预算超限，触发任务拆解（split）")
        return "split"
    
    # 检查是否需要网络搜索
    need_search = state.get('need_search')
    print(f"[决策调试] need_search={need_search}")
    if need_search:
        print("[决策] 需要网络搜索，进入 Search 节点")
        return "search"

    # 审计失败特殊处理：直接触发辩论节点，跳过反思
    if current == 'auditor_code' and audit_results.get('code') is False:
        print("[决策] 审计失败，触发辩论节点")
        return "debate"
    
    # 如果存在错误，优先进入反思节点（除非已经在反思节点中）
    if error:
        if current == 'reflection':
            # 反思完成后，根据错误来源决定修复节点
            # 通过诊断向量或审计结果推断
            diagnostic = state.get('diagnostic_vector')
            if diagnostic and diagnostic.get('verdict') == 'fail':
                # 检查是哪个审计类型失败
                if audit_results.get('code') is False:
                    print("[决策] 反思完成，折返给 Coder 修复")
                    return "coder"
                elif audit_results.get('report') is False:
                    print("[决策] 反思完成，折返给 Reporter 修复")
                    return "reporter"
                elif audit_results.get('ppt') is False:
                    print("[决策] 反思完成，折返给 Presenter 修复")
                    return "presenter"
            # 默认折返给 Coder
            print("[决策] 反思完成，默认折返给 Coder")
            return "coder"
        else:
            # 未进行反思，先进入反思节点
            print("[决策] 检测到错误，进入反思节点")
            return "reflection"
    
    # 无错误，按流程前进
    if current == 'architect':
        return "coder"
    elif current == 'coder':
        return "auditor_code"
    elif current == 'auditor_code':
        if audit_results.get('code', False):
            return "reporter"
        else:
            # 审计失败，进入辩论节点
            print("[决策] 审计失败，触发辩论节点")
            return "debate"
    elif current == 'reporter':
        return "auditor_report"
    elif current == 'auditor_report' and audit_results.get('report', False):
        return "presenter"
    elif current == 'presenter':
        return "auditor_ppt"
    elif current == 'auditor_ppt' and audit_results.get('ppt', False):
        return "end"
    elif current == 'reflection':
        # 反思节点执行后应已清除错误，若仍无错误，则按正常流程前进（可能应返回 coder）
        print("[决策] 反思节点执行完毕，返回 Coder")
        return "coder"
    else:
        # 未知状态，结束
        print(f"[决策] 未知状态 {current}，结束流程")
        return "end"


# -------------------- 构建状态图 --------------------
def build_workflow():
    """构建多智能体协作状态图（支持多审计节点）"""
    from langgraph.graph import StateGraph, END
    from debate_node import debate_node
    workflow = StateGraph(AgentState)
    
    # 添加节点
    workflow.add_node("architect", architect_node)
    workflow.add_node("coder", coder_node)
    workflow.add_node("reporter", reporter_node)
    workflow.add_node("presenter", presenter_node)
    workflow.add_node("search", search_node)
    # 三个审计节点，共用 auditor_node 函数（内部根据 current_node 区分类型）
    workflow.add_node("auditor_code", auditor_node)
    workflow.add_node("auditor_report", auditor_node)
    workflow.add_node("auditor_ppt", auditor_node)
    # 反思节点
    workflow.add_node("reflection", reflection_node)
    # 任务拆解节点
    workflow.add_node("split", split_node)
    # MemoryGate 节点
    workflow.add_node("memory_gate", memory_gate_node)
    # Debate 节点
    workflow.add_node("debate", debate_node)
    
    # 设置入口点
    workflow.set_entry_point("architect")
    
    # 条件边：由 decide_next 函数决定下一步
    workflow.add_conditional_edges(
        "architect",
        decide_next,
        {
            "coder": "coder",
            "reflection": "reflection",
            "search": "search",
            "split": "split",
            "end": END,
        }
    )
    workflow.add_conditional_edges(
        "coder",
        decide_next,
        {
            "auditor_code": "auditor_code",
            "coder": "coder",
            "reflection": "reflection",
            "split": "split",
            "end": END,
        }
    )
    workflow.add_conditional_edges(
        "auditor_code",
        decide_next,
        {
            "reporter": "reporter",
            "coder": "coder",
            "reflection": "reflection",
            "split": "split",
            "debate": "debate",
            "end": END,
        }
    )
    workflow.add_conditional_edges(
        "reporter",
        decide_next,
        {
            "auditor_report": "auditor_report",
            "reporter": "reporter",
            "reflection": "reflection",
            "split": "split",
            "end": END,
        }
    )
    workflow.add_conditional_edges(
        "auditor_report",
        decide_next,
        {
            "presenter": "presenter",
            "reporter": "reporter",
            "reflection": "reflection",
            "split": "split",
            "end": END,
        }
    )
    workflow.add_conditional_edges(
        "presenter",
        decide_next,
        {
            "auditor_ppt": "auditor_ppt",
            "presenter": "presenter",
            "reflection": "reflection",
            "split": "split",
            "end": END,
        }
    )
    workflow.add_conditional_edges(
        "auditor_ppt",
        decide_next,
        {
            "end": END,
            "presenter": "presenter",
            "reflection": "reflection",
            "split": "split",
        }
    )
    
    workflow.add_conditional_edges(
        "reflection",
        decide_next,
        {
            "coder": "coder",
            "reporter": "reporter",
            "presenter": "presenter",
            "reflection": "reflection",
            "split": "split",
            "end": END,
        }
    )
    
    # 搜索节点后返回架构师节点重新生成系统规范
    workflow.add_edge("search", "architect")
    # 任务拆解节点后返回架构师节点处理新的子任务
    workflow.add_edge("split", "architect")
    # 辩论节点后重新进行代码审计
    workflow.add_edge("debate", "auditor_code")
    
    return workflow


# -------------------- 主函数 --------------------
def main():
    """命令行入口"""
    if len(sys.argv) < 2:
        # 尝试从 task_description.txt 读取任务描述
        if os.path.exists('task_description.txt'):
            with open('task_description.txt', 'r', encoding='utf-8') as f:
                task_description = f.read().strip()
            print("[信息] 从 task_description.txt 读取任务描述")
        else:
            print("用法：python main_agent.py \"任务描述\"")
            print("或创建 task_description.txt 文件包含任务描述")
            sys.exit(1)
    else:
        task_description = sys.argv[1]
    
    # 初始化状态
    print(f"[{datetime.now()}] [TRACE] 1. 开始初始化状态...")
    initial_state: AgentState = {
        "task_description": task_description,
        "blueprint": None,
        "deliverables": {},
        "audit_results": {},
        "error_message": None,
        "iteration": 0,
        "current_node": "architect",
        "relevant_knowledge": None,
        "need_search": False,
    }
    print(f"[{datetime.now()}] [TRACE] 2. 状态初始化完成，开始构建工作流...")
    
    # 构建并编译图
    print("=== LangGraph 智能体后台系统启动 ===")
    # 强制设置控制台代码页为 UTF-8 (Windows)
    if sys.platform == "win32":
        os.system('chcp 65001 >nul')
    print(f"任务：{task_description}")
    print("构建工作流...")
    print(f"[{datetime.now()}] [TRACE] 3. 开始构建工作流...")
    # 构建并编译图
    print(f"[{datetime.now()}] [TRACE] 4. 工作流构建完成，开始编译...")
    workflow = build_workflow()
    app = workflow.compile()
    
    # 执行工作流
    print(f"[{datetime.now()}] [TRACE] 5. 开始执行工作流...")
    final_state = app.invoke(initial_state)
    current_state = final_state
    
    # 输出最终结果
    print("\n=== 执行结果 ===")
    print(f"当前节点: {current_state.get('current_node')}")
    print(f"错误信息: {current_state.get('error_message')}")
    print(f"蓝图: {current_state.get('blueprint')}")
    print(f"交付物: {current_state.get('deliverables')}")
    if current_state.get('test_results'):
        res = current_state['test_results']
        print(f"测试结果：{'通过' if res.get('success') else '失败'}")
        if res.get('stderr'):
            print(f"错误输出：{res['stderr'][:500]}...")
    if current_state.get('error_message'):
        print(f"最终错误：{current_state['error_message'][:500]}...")
    
    # 更新活跃上下文（记忆红线）
    update_active_context(task_description, current_state)


def update_active_context(task: str, state: AgentState):
    """更新 /docs/active_context.md（记忆红线）"""
    file_tools = FileTools()
    context_path = "docs/active_context.md"
    existing = file_tools.read_file(context_path)
    
    new_entry = f"""
## LangGraph 智能体执行记录
- **日期**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
- **任务**: {task}
- **状态**: {'成功' if not state.get('error_message') else '失败'}
- **迭代次数**: {state['iteration']}
- **生成文件**: {state.get('code_files', [])}
- **测试结果**: {'通过' if state.get('test_results', {}).get('success') else '失败'}
"""
    updated = existing + new_entry
    file_tools.write_file(context_path, updated)
    print("[记忆红线] 已更新 active_context.md")


if __name__ == "__main__":
    import os
    os.environ["HF_HUB_OFFLINE"] = "1"
    main()