def check_syntax(file_path):
    # 模拟语法检查
    return True
