#!/usr/bin/env python3
"""
LangGraph 智能体模拟测试 - 在不依赖真实 API 的情况下验证工作流逻辑。
"""

import os
import sys
import json
from typing import TypedDict, List, Optional, Literal
from pathlib import Path
import subprocess

from langgraph.graph import StateGraph, END
from langchain_core.messages import HumanMessage, SystemMessage

# -------------------- 状态 Schema --------------------
class AgentState(TypedDict):
    task_description: str
    plan: Optional[str]
    code_files: List[str]
    test_results: Optional[dict]
    error_message: Optional[str]
    iteration: int
    current_node: Literal["architect", "engineer", "qa"]

# -------------------- 模拟模型 --------------------
class MockArchitectModel:
    def invoke(self, messages):
        class MockResponse:
            content = json.dumps({
                "plan": "模拟计划：编写一个 Python 语法检查脚本。",
                "steps": ["步骤1：分析需求", "步骤2：编写语法检查函数", "步骤3：编写测试用例"],
                "adr_summary": "使用 ast 模块进行语法分析，避免 eval 安全风险。"
            })
        return MockResponse()

class MockEngineerModel:
    def invoke(self, messages):
        class MockResponse:
            content = json.dumps({
                "test_files": [
                    {
                        "path": "tests/test_syntax_checker.py",
                        "content": "import ast\nimport pytest\nfrom src.syntax_checker import check_syntax\n\ndef test_valid_syntax():\n    assert check_syntax('print(\"hello\")') == True\n\ndef test_invalid_syntax():\n    assert check_syntax('print(') == False\n"
                    }
                ],
                "src_files": [
                    {
                        "path": "src/syntax_checker.py",
                        "content": "import ast\n\ndef check_syntax(code: str) -> bool:\n    \"\"\"检查 Python 代码语法是否正确\"\"\"\n    try:\n        ast.parse(code)\n        return True\n    except SyntaxError:\n        return False\n"
                    }
                ]
            })
        return MockResponse()

architect_model = MockArchitectModel()
engineer_model = MockEngineerModel()

# -------------------- 工具 --------------------
class FileTools:
    @staticmethod
    def read_file(path: str) -> str:
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return f.read()
        except FileNotFoundError:
            return f"文件不存在：{path}"
        except Exception as e:
            return f"读取文件时出错：{e}"

    @staticmethod
    def write_file(path: str, content: str) -> dict:
        try:
            Path(path).parent.mkdir(parents=True, exist_ok=True)
            with open(path, 'w', encoding='utf-8') as f:
                f.write(content)
            return {"success": True, "path": path, "message": f"文件已写入：{path}"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    @staticmethod
    def list_files(path: str, recursive: bool = False) -> List[str]:
        try:
            p = Path(path)
            if recursive:
                return [str(f) for f in p.rglob("*") if f.is_file()]
            else:
                return [str(f) for f in p.iterdir() if f.is_file()]
        except Exception:
            return []

class TerminalTools:
    @staticmethod
    def run_command(command: str, cwd: str = None) -> dict:
        try:
            result = subprocess.run(
                command,
                shell=True,
                cwd=cwd,
                capture_output=True,
                text=True,
                timeout=30
            )
            return {
                "success": result.returncode == 0,
                "returncode": result.returncode,
                "stdout": result.stdout,
                "stderr": result.stderr,
            }
        except subprocess.TimeoutExpired:
            return {"success": False, "error": "命令执行超时"}
        except Exception as e:
            return {"success": False, "error": str(e)}

# -------------------- 节点函数 --------------------
def architect_node(state: AgentState) -> AgentState:
    print("[Architect] 开始任务拆解（模拟）...")
    response = architect_model.invoke([])
    plan_text = response.content if hasattr(response, 'content') else str(response)
    state['plan'] = plan_text
    state['error_message'] = None
    state['current_node'] = "architect"
    print("[Architect] 任务拆解完成。")
    return state

def engineer_node(state: AgentState) -> AgentState:
    print("[Engineer] 开始编写代码（模拟）...")
    response = engineer_model.invoke([])
    response_text = response.content if hasattr(response, 'content') else str(response)
    try:
        data = json.loads(response_text)
        test_files = data.get("test_files", [])
        src_files = data.get("src_files", [])
    except json.JSONDecodeError:
        test_files = []
        src_files = []
    file_tools = FileTools()
    written_files = []
    for file_info in test_files + src_files:
        result = file_tools.write_file(file_info["path"], file_info["content"])
        if result["success"]:
            written_files.append(file_info["path"])
    state['code_files'] = written_files
    state['error_message'] = None
    state['current_node'] = "engineer"
    print(f"[Engineer] 已编写 {len(written_files)} 个文件。")
    return state

def qa_node(state: AgentState) -> AgentState:
    print("[QA] 开始执行测试（模拟）...")
    terminal_tools = TerminalTools()
    result = terminal_tools.run_command("pytest -v", cwd=".")
    state['test_results'] = result
    if result.get("success"):
        print("[QA] 所有测试通过！")
        state['error_message'] = None
    else:
        error_summary = result.get("stderr", "")[-500:] if result.get("stderr") else result.get("stdout", "")[-500:]
        state['error_message'] = error_summary
        print(f"[QA] 测试失败，错误摘要：{error_summary[:200]}...")
    state['current_node'] = "qa"
    return state

# -------------------- 条件边 --------------------
def should_retry(state: AgentState) -> Literal["engineer", "end"]:
    if state.get('error_message'):
        if state['iteration'] >= 2:
            print("[决策] 已达到最大迭代次数，终止流程。")
            return "end"
        else:
            print("[决策] 测试失败，折返给 Engineer 修复。")
            return "engineer"
    else:
        print("[决策] 测试通过，流程结束。")
        return "end"

# -------------------- 构建状态图 --------------------
def build_workflow() -> StateGraph:
    workflow = StateGraph(AgentState)
    workflow.add_node("architect", architect_node)
    workflow.add_node("engineer", engineer_node)
    workflow.add_node("qa", qa_node)
    workflow.set_entry_point("architect")
    workflow.add_edge("architect", "engineer")
    workflow.add_edge("engineer", "qa")
    workflow.add_conditional_edges(
        "qa",
        should_retry,
        {
            "engineer": "engineer",
            "end": END,
        }
    )
    return workflow

# -------------------- 主函数 --------------------
def main():
    if len(sys.argv) < 2:
        task_description = "编写一个检测 Python 语法错误的简单脚本"
    else:
        task_description = sys.argv[1]
    
    initial_state: AgentState = {
        "task_description": task_description,
        "plan": None,
        "code_files": [],
        "test_results": None,
        "error_message": None,
        "iteration": 0,
        "current_node": "architect",
    }
    
    print("=== LangGraph 智能体模拟测试 ===")
    print(f"任务：{task_description}")
    print("构建工作流...")
    workflow = build_workflow()
    app = workflow.compile()
    
    max_iterations = 3
    current_state = initial_state
    
    for i in range(max_iterations):
        print(f"\n--- 迭代 {i+1} ---")
        current_state['iteration'] = i
        current_state = app.invoke(current_state)
        
        if current_state.get('current_node') == 'qa' and not current_state.get('error_message'):
            print("任务成功完成！")
            break
        if current_state.get('error_message') and i == max_iterations - 1:
            print("达到最大迭代次数，任务失败。")
            break
    
    print("\n=== 模拟执行结果 ===")
    print(f"计划：{current_state.get('plan', '')[:200]}...")
    print(f"生成文件：{current_state.get('code_files', [])}")
    if current_state.get('test_results'):
        res = current_state['test_results']
        print(f"测试结果：{'通过' if res.get('success') else '失败'}")
        if res.get('stderr'):
            print(f"错误输出：{res['stderr'][:500]}...")
    if current_state.get('error_message'):
        print(f"最终错误：{current_state['error_message'][:500]}...")
    
    # 更新活跃上下文
    update_active_context(task_description, current_state)

def update_active_context(task: str, state: AgentState):
    from datetime import datetime
    file_tools = FileTools()
    context_path = "docs/active_context.md"
    existing = file_tools.read_file(context_path)
    new_entry = f"""
## LangGraph 智能体模拟测试记录
- **日期**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
- **任务**: {task}
- **状态**: {'成功' if not state.get('error_message') else '失败'}
- **迭代次数**: {state['iteration']}
- **生成文件**: {state.get('code_files', [])}
- **测试结果**: {'通过' if state.get('test_results', {}).get('success') else '失败'}
"""
    updated = existing + new_entry
    file_tools.write_file(context_path, updated)
    print("[记忆红线] 已更新 active_context.md")

if __name__ == "__main__":
    main()