#!/usr/bin/env python3
"""
辩论节点（Debate_Node）
当 Auditor 审计失败时，触发 Coder 与 Auditor 的多轮辩论，直至产出完美代码或达到最大轮次。
使用真实的 DeepSeek 模型调用，严禁模拟。
"""
import json
import os
import sys
import re
from typing import Dict, Any, List, Optional


class DebateNode:
    def __init__(self, max_rounds: int = 3):
        self.max_rounds = max_rounds
        # 延迟导入，避免循环依赖
        # 模型实例将在首次调用时创建
        self._coder_model = None
        self._auditor_model = None
        self._models_initialized = False
    
    def _resolve_sandbox_path(self, path: str) -> str:
        """
        将原始路径对齐到沙盒目录（与 coder_node 写入规则完全一致）
        规则：
        - 若 path 以 src/ 开头 → src/staging/...
        - 若 path 以 tests/ 开头 → staging/tests/...
        - 其他 → staging/...
        返回对齐后的路径（不保证文件存在）
        
        改进：
        1. 更精确的 staging 路径检测（避免误判）
        2. 跨平台路径分隔符处理
        3. 避免重复转换
        """
        import os
        # 首先规范化路径，统一分隔符
        normalized = os.path.normpath(path).replace('\\', '/')
        
        # 检查是否已经是 staging 路径（精确匹配）
        # 允许的 staging 路径前缀：staging/ 或 src/staging/
        if normalized.startswith(('staging/', 'src/staging/')):
            # 已经是 staging 路径，直接返回原始路径（保持原有分隔符）
            return path
        
        # 应用与 coder_node 完全相同的转换规则
        if normalized.startswith("src/"):
            resolved = "src/staging/" + normalized[4:]  # 移除 src/
        elif normalized.startswith("tests/"):
            resolved = "staging/" + normalized  # 保持 tests/ 前缀
        else:
            resolved = "staging/" + normalized
        
        # 再次规范化（去除多余的 ./ 等）
        resolved = os.path.normpath(resolved)
        return resolved

    def run_debate(self, initial_state: Dict[str, Any]) -> Dict[str, Any]:
        """
        执行多轮辩论循环。
        输入：初始状态（包含错误消息、诊断向量等）。
        输出：最终状态（可能包含修正后的代码、辩论日志等）。
        """
        state = initial_state.copy()
        debate_log = []
        
        # 保存原始错误消息（外部审计员报告的错误）
        original_error = state.get("error_message")
        state["original_error"] = original_error
        
        for round_idx in range(self.max_rounds):
            print(f"[DebateNode] 第 {round_idx + 1} 轮辩论开始")
            
            # 1. Coder 生成修正代码（基于审计反馈）
            coder_response = self._invoke_coder(state)
            if not coder_response.get("success"):
                state["error_message"] = f"辩论第 {round_idx + 1} 轮：Coder 生成失败"
                break
            
            # 更新状态中的代码交付物
            state.update(coder_response.get("updates", {}))
            
            # 2. Auditor 重新审计新代码
            auditor_response = self._invoke_auditor(state)
            if not auditor_response.get("success"):
                state["error_message"] = f"辩论第 {round_idx + 1} 轮：Auditor 审计异常"
                break
            
            # 检查审计结果
            if auditor_response.get("verdict") == "pass":
                print(f"[DebateNode] 第 {round_idx + 1} 轮辩论通过，代码合格")
                state["error_message"] = None
                state["debate_result"] = "success"
                break
            else:
                # 记录审计失败的原因，作为下一轮 Coder 的反馈
                state["error_message"] = auditor_response.get("feedback", "审计未通过")
                print(f"[DebateNode] 第 {round_idx + 1} 轮辩论未通过：{state['error_message']}")
                debate_log.append({
                    "round": round_idx + 1,
                    "coder_output": coder_response.get("summary"),
                    "auditor_feedback": state["error_message"]
                })
        else:
            # 达到最大轮次仍未通过，启动外部 pytest 作为最终裁决
            print(f"[DebateNode] 已达到最大辩论轮次 {self.max_rounds}，启动外部 pytest 作为最终裁决")
            # 获取当前代码路径
            code_path = state.get('deliverables', {}).get('code')
            if code_path:
                code_path = self._resolve_sandbox_path(code_path)
                print(f"[DebateNode] 对代码文件运行 pytest: {code_path}")
                import subprocess
                import sys
                # 运行 pytest，捕获退出码
                result = subprocess.run(
                    [sys.executable, '-m', 'pytest', code_path, '-v'],
                    capture_output=True,
                    text=True
                )
                if result.returncode == 0:
                    print("[DebateNode] pytest 全部通过，代码合格")
                    state["debate_result"] = "success"
                    state["error_message"] = None
                else:
                    print(f"[DebateNode] pytest 失败，退出码 {result.returncode}")
                    state["debate_result"] = "failed"
                    state["error_message"] = f"外部 pytest 测试失败：{result.stderr[:200]}"
            else:
                print("[DebateNode] 无代码文件，无法运行 pytest")
                state["debate_result"] = "failed"
                state["error_message"] = f"经过 {self.max_rounds} 轮辩论仍无法产出合格代码，且无代码文件可供测试"
        
        state["debate_log"] = debate_log
        return state
    
    def _invoke_coder(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """调用真实 Coder 模型生成修正代码，并物理写入沙盒"""
        # 延迟导入，避免循环依赖
        import os
        import sys
        sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        from main_agent import get_deepseek_model, FileTools
        
        task_desc = state.get("task_description", "")
        error_msg = state.get("error_message", "")
        deliverables = state.get("deliverables", {})
        # 获取当前代码文件路径（优先使用 deliverables['code']，否则回退）
        current_code_path = deliverables.get("code")
        # 重定向到 staging 目录（如果存在）
        if current_code_path:
            current_code_path = self._resolve_sandbox_path(current_code_path)
        current_code_content = ""
        if current_code_path:
            ft = FileTools()
            read_result = ft.read_file(current_code_path)
            # FileTools.read_file 返回字符串（内容或错误信息）
            # 检测常见错误前缀（包括中英文）
            error_keywords = ["文件不存在", "读取文件时出错", "错误", "Error", "error", "failed", "无法"]
            is_error = any(read_result.startswith(keyword) for keyword in error_keywords) or len(read_result.strip()) < 10 and "文件" in read_result
            if is_error:
                print(f"[DebateNode] 警告：无法读取路径 {current_code_path} 的代码（返回信息：{read_result[:100]}）")
                current_code_content = ""
                # 记录调试信息，但不视为致命错误（可能文件确实不存在）
            else:
                current_code_content = read_result
                print(f"[DebateNode] 成功读取代码文件，长度：{len(current_code_content)} 字符")
        
        # 构建提示词（注入完整上下文）
        # 使用醒目的分隔符确保 AI 能清晰看到代码
        code_block = f"""
===== 待修正的源代码开始 (路径: {current_code_path or 'unknown'}) =====
{current_code_content if current_code_content else '# 文件为空或无法读取'}
===== 待修正的源代码结束 =====
"""
        prompt = f"""
你是一位资深软件工程师（Coder）。请根据以下上下文修正代码。

原始任务描述：
{task_desc}

外部审计员反馈的错误（必须修复）：
{error_msg}

当前代码内容（位于 {current_code_path or '未知路径'}）：
{code_block}

请根据错误反馈修正代码，并确保满足所有硬性约束（如安全要求）。你只需返回一个 JSON 对象，格式如下：
{{
    "test_files": [
        {{"path": "tests/test_xxx.py", "content": "..."}}
    ],
    "src_files": [
        {{"path": "src/xxx.py", "content": "..."}}
    ]
}}
（如果测试文件不需要修改，可留空数组；如果源文件路径与当前不同，请使用正确的相对路径。）

重要：请确保修正后的代码能通过外部审计员报告的错误（如测试失败、安全漏洞等）。
"""
        messages = [{"role": "user", "content": prompt}]
        # 调试日志：确认发送给模型的内容
        print(f"[DebateNode Debug] 发送给 Coder 的提示长度: {len(prompt)} 字符")
        print(f"[DebateNode Debug] 代码块长度: {len(current_code_content)} 字符")
        try:
            coder_model = get_deepseek_model("deepseek-chat")
            response = coder_model.invoke(messages)
            # 解析响应内容
            content = response.content
            # 尝试提取 JSON 部分
            if "{" in content and "}" in content:
                start = content.find("{")
                end = content.rfind("}") + 1
                json_str = content[start:end]
                data = json.loads(json_str)
            else:
                data = {"test_files": [], "src_files": []}
            
            test_files = data.get("test_files", [])
            src_files = data.get("src_files", [])
            
            # 物理写入沙盒目录
            ft = FileTools()
            written_files = []
            for file_info in test_files + src_files:
                original_path = file_info["path"]
                # 使用统一的路径转换方法（避免重复逻辑）
                staged_path = self._resolve_sandbox_path(original_path)
                
                # 确保目标目录存在
                os.makedirs(os.path.dirname(staged_path), exist_ok=True)
                
                result = ft.write_file(staged_path, file_info["content"])
                if result["success"]:
                    written_files.append(original_path)
                    print(f"[DebateNode] 代码已安全写入沙盒: {staged_path} (原始路径: {original_path})")
                else:
                    print(f"[DebateNode] 写入沙盒文件失败 {staged_path}: {result.get('error')}")
                    return {"success": False, "error": f"写入文件失败: {staged_path}"}
            
            # 更新状态中的交付物路径（使用第一个写入的源文件作为主交付物）
            main_deliverable = None
            for file_info in src_files:
                if file_info["path"].startswith("src/"):
                    main_deliverable = file_info["path"]
                    break
            if not main_deliverable and src_files:
                main_deliverable = src_files[0]["path"]
            
            updates = {
                "deliverables": {"code": main_deliverable} if main_deliverable else {},
                "written_files": written_files
            }
            
            return {
                "success": True,
                "summary": f"已生成 {len(written_files)} 个文件",
                "updates": updates
            }
        except Exception as e:
            print(f"[DebateNode] Coder 调用失败: {e}")
            return {"success": False, "error": str(e)}
    
    def _invoke_auditor(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """调用真实 Auditor 模型进行代码审计"""
        # 延迟导入，避免循环依赖
        import os
        import sys
        sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        from main_agent import get_deepseek_model, FileTools
        
        # 优先从状态获取代码内容，如果不存在则从交付物路径读取
        code_content = state.get("code_content", "")
        if not code_content:
            # 尝试从 deliverables 中读取代码文件
            deliverables = state.get("deliverables", {})
            code_path = deliverables.get("code")
            if code_path:
                # 转换为沙盒路径
                code_path = self._resolve_sandbox_path(code_path)
                ft = FileTools()
                read_result = ft.read_file(code_path)
                # 检查是否是错误信息
                error_keywords = ["文件不存在", "读取文件时出错", "错误", "Error", "error", "failed", "无法"]
                is_error = any(read_result.startswith(keyword) for keyword in error_keywords) or len(read_result.strip()) < 10 and "文件" in read_result
                if not is_error:
                    code_content = read_result
                    print(f"[DebateNode] Auditor 从路径 {code_path} 读取代码，长度：{len(code_content)} 字符")
                else:
                    print(f"[DebateNode] Auditor 无法读取代码文件 {code_path}: {read_result[:100]}")
        
        hard_constraints = state.get("hard_constraints", [])
        # 格式化硬性约束
        if hard_constraints:
            constraints_str = "\n".join([f"- {c.get('type', 'unknown')}: {c.get('rule', '')}" for c in hard_constraints])
        else:
            constraints_str = "（无硬性约束）"
        
        # 构建提示词（注入完整上下文，聚焦外部错误）
        task_desc = state.get("task_description", "")
        # 优先使用原始错误（外部审计员报告的错误），如果不存在则使用当前错误消息
        error_msg = state.get("original_error", state.get("error_message", ""))
        
        # 使用醒目的分隔符确保 AI 能清晰看到代码
        code_block = f"""
===== 待审计的源代码开始 =====
{code_content if code_content else '# 代码内容不可用（可能文件不存在）'}
===== 待审计的源代码结束 =====
"""
        prompt = f"""
你是一位极度紧张的安全专家（Auditor）。请对以下代码进行严格审计，并特别关注外部审计员报告的错误。

原始任务描述：
{task_desc}

外部审计员报告的错误（必须修复）：
{error_msg}

待审计的代码（请仔细检查）：
{code_block}

硬性约束（必须遵守）：
{constraints_str}

安全红线：你必须检查代码中是否仍然包含高危函数（如 eval, exec, pickle, os.system 等）。如果发现任何高危函数，必须给出 verdict: "fail"。

**核心要求**：你的审计焦点应集中在修复上述外部错误（如测试失败、Bandit 漏洞）上，不要在类型注解、PEP8 风格等非致命问题上无限纠缠。如果外部错误已修复且无安全违规，则通过；否则失败。

重要提示：请勿误认为代码缺失。上面的代码块包含了完整的待审计代码。请根据外部错误报告进行针对性检查。

请返回一个 JSON 对象，格式如下：
{{
    "verdict": "pass" 或 "fail",
    "feedback": "详细的审计意见（如果通过，可留空）"
}}
"""
        messages = [{"role": "user", "content": prompt}]
        # 调试日志：确认发送给模型的内容
        print(f"[DebateNode Debug] 发送给 Auditor 的提示长度: {len(prompt)} 字符")
        print(f"[DebateNode Debug] 代码块长度: {len(code_content)} 字符")
        try:
            auditor_model = get_deepseek_model("deepseek-reasoner")
            response = auditor_model.invoke(messages)
            content = response.content
            if "{" in content and "}" in content:
                start = content.find("{")
                end = content.rfind("}") + 1
                json_str = content[start:end]
                data = json.loads(json_str)
            else:
                data = {"verdict": "fail", "feedback": "无法解析审计响应"}
            
            verdict = data.get("verdict", "fail")
            feedback = data.get("feedback", "")
            return {
                "success": True,
                "verdict": verdict,
                "feedback": feedback
            }
        except Exception as e:
            print(f"[DebateNode] Auditor 调用失败: {e}")
            return {"success": False, "verdict": "fail", "feedback": f"模型调用异常: {e}"}


# LangGraph 节点函数（兼容天灵状态图）
def debate_node(state: Dict[str, Any]) -> Dict[str, Any]:
    """
    辩论节点的 LangGraph 兼容入口。
    期望状态中包含 error_message（审计失败的原因）。
    输出状态中将包含辩论结果与可能的修正代码。
    """
    print("[DebateNode] 进入辩论节点")
    
    # 仅当存在错误且未超过最大轮次时才触发辩论
    if not state.get("error_message"):
        print("[DebateNode] 无错误消息，跳过辩论")
        return state
    
    # 初始化辩论器
    debater = DebateNode(max_rounds=3)
    new_state = debater.run_debate(state)
    
    # 将当前节点标记为 debate，以便 decide_next 正确处理
    new_state["current_node"] = "debate"
    return new_state


if __name__ == "__main__":
    # 简单测试（需要设置 DEEPSEEK_API_KEY 环境变量）
    test_state = {
        "error_message": "审计失败：代码格式不符合 PEP8",
        "diagnostic_vector": {"verdict": "fail"},
        "current_node": "auditor"
    }
    result = debate_node(test_state)
    print("辩论结果:", json.dumps(result, indent=2, ensure_ascii=False))