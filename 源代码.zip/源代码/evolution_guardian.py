#!/usr/bin/env python3
"""
天灵进化监护人脚本 (Evolution Guardian)
自动执行自举循环，监视逻辑退化，确保核心功能不丢失。
"""
import os
import sys
import subprocess
import shutil
import json
import re
from pathlib import Path

# 配置
DEBATE_NODE_PATH = "src/debate_node.py"
DEBATE_NODE_STABLE = "src/debate_node.py.stable"
EVALUATOR_GOLD = "src/evaluator.gold"
ERROR_VAULT_PATH = ".ai_knowledge/error_vault.md"
MAX_ROUNDS = 10  # 最大自举轮次
CONSECUTIVE_SUCCESSES_NEEDED = 3  # 停止条件：连续成功次数
success_count = 0

def log(msg):
    print(f"[Guardian] {msg}")

def backup_stable():
    """创建稳定基准备份"""
    if not os.path.exists(DEBATE_NODE_STABLE):
        shutil.copy2(DEBATE_NODE_PATH, DEBATE_NODE_STABLE)
        log(f"已创建稳定基准: {DEBATE_NODE_STABLE}")
    # 确保 evaluator.gold 存在（可选）
    if not os.path.exists(EVALUATOR_GOLD):
        # 尝试从 staging 复制
        staging_path = "src/staging/safe_evaluator.py"
        if os.path.exists(staging_path):
            shutil.copy2(staging_path, EVALUATOR_GOLD)
            log(f"已复制 evaluator 黄金版本: {EVALUATOR_GOLD}")
        else:
            log(f"警告: {staging_path} 不存在，跳过 evaluator 备份")

def run_bootstrap():
    """执行一次自举任务，返回退出码与输出"""
    cmd = [sys.executable, "src/main_agent.py", "自举任务：优化自身提示词模板"]
    log(f"执行自举命令: {' '.join(cmd)}")
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=300,  # 5 分钟超时
            cwd=os.getcwd()
        )
        log(f"自举退出码: {result.returncode}")
        if result.stdout:
            log(f"自举输出 (前 500 字符): {result.stdout[:500]}...")
        if result.stderr:
            log(f"自举错误 (前 500 字符): {result.stderr[:500]}...")
        return result.returncode, result.stdout, result.stderr
    except subprocess.TimeoutExpired:
        log("自举超时，强制终止")
        return -1, "", "Timeout"
    except Exception as e:
        log(f"自举执行异常: {e}")
        return -2, "", str(e)

def read_file_lines(path):
    """读取文件行列表，忽略空行和注释（粗略）"""
    if not os.path.exists(path):
        return []
    with open(path, 'r', encoding='utf-8') as f:
        lines = f.readlines()
    # 去除空白行和仅包含注释的行（以 # 开头）
    cleaned = []
    for line in lines:
        stripped = line.strip()
        if stripped and not stripped.startswith('#'):
            cleaned.append(line)
    return cleaned

def count_logic_lines(path):
    """估算核心逻辑行数（非注释、非空行）"""
    lines = read_file_lines(path)
    return len(lines)

def audit_debate_node():
    """
    审计新生成的 debate_node.py，检查是否触发熔断条件。
    返回 (pass, reason) 其中 pass=True 表示通过审计。
    """
    if not os.path.exists(DEBATE_NODE_PATH):
        return False, "文件不存在"
    
    with open(DEBATE_NODE_PATH, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 熔断条件 A: 是否删除了 pytest 仲裁逻辑？
    if 'pytest' not in content and 'subprocess.run' not in content:
        return False, "删除了 pytest 仲裁逻辑"
    
    # 熔断条件 A: 是否删除了 _resolve_sandbox_path 映射？
    if '_resolve_sandbox_path' not in content:
        return False, "删除了 _resolve_sandbox_path 路径映射"
    
    # 熔断条件 A: 是否删除了硬性安全约束（如 '硬性约束'、'安全红线'）？
    if '硬性约束' not in content and '安全红线' not in content:
        return False, "删除了硬性安全约束"
    
    # 熔断条件 B: 核心逻辑行数相比稳定版本减少超过 30%
    stable_lines = count_logic_lines(DEBATE_NODE_STABLE)
    new_lines = count_logic_lines(DEBATE_NODE_PATH)
    if stable_lines == 0:
        log("稳定版本行数为零，跳过行数检查")
    else:
        reduction = (stable_lines - new_lines) / stable_lines
        if reduction > 0.3:
            return False, f"核心逻辑行数减少 {reduction:.1%}（稳定 {stable_lines} 行，当前 {new_lines} 行）"
    
    # 额外检查：是否保留了关键函数（run_debate, _invoke_coder, _invoke_auditor）
    required_funcs = ['run_debate', '_invoke_coder', '_invoke_auditor']
    for func in required_funcs:
        if func not in content:
            return False, f"缺失关键函数 {func}"
    
    return True, "审计通过"

def revert_to_stable(reason):
    """用稳定版本恢复文件，并将失败原因写入错误知识库"""
    log(f"触发熔断，原因: {reason}")
    if os.path.exists(DEBATE_NODE_STABLE):
        shutil.copy2(DEBATE_NODE_STABLE, DEBATE_NODE_PATH)
        log(f"已恢复稳定版本: {DEBATE_NODE_PATH}")
    else:
        log("错误: 稳定备份不存在，无法恢复")
    
    # 将失败原因写入错误知识库
    os.makedirs(os.path.dirname(ERROR_VAULT_PATH), exist_ok=True)
    entry = f"""
## 进化熔断记录
- **日期**: {subprocess.check_output(['date', '/t'], text=True).strip()}
- **文件**: {DEBATE_NODE_PATH}
- **原因**: {reason}
- **处理**: 已恢复至稳定基准
"""
    with open(ERROR_VAULT_PATH, 'a', encoding='utf-8') as f:
        f.write(entry)
    log(f"已写入错误知识库: {ERROR_VAULT_PATH}")

def update_stable():
    """将当前版本提升为新的稳定基准"""
    shutil.copy2(DEBATE_NODE_PATH, DEBATE_NODE_STABLE)
    log(f"更新稳定基准: {DEBATE_NODE_STABLE}")

def run_pytest():
    """运行 pytest 测试，返回是否全部通过"""
    # 简单运行 pytest 在 tests/ 目录（假设有相关测试）
    cmd = [sys.executable, '-m', 'pytest', 'tests/', '-v', '--tb=short']
    log("运行 pytest 测试...")
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=60
        )
        if result.returncode == 0:
            log("pytest 全部通过")
            return True, result.stdout
        else:
            log(f"pytest 失败，退出码 {result.returncode}")
            return False, result.stderr
    except subprocess.TimeoutExpired:
        log("pytest 超时")
        return False, "Timeout"
    except Exception as e:
        log(f"pytest 执行异常: {e}")
        return False, str(e)

def main():
    global success_count
    log("=== 天灵进化监护人启动 ===")
    backup_stable()
    
    round_num = 1
    while round_num <= MAX_ROUNDS:
        log(f"\n--- 第 {round_num} 轮自举开始 ---")
        # 执行自举
        retcode, stdout, stderr = run_bootstrap()
        if retcode != 0:
            log(f"自举失败，退出码 {retcode}，跳过审计")
            revert_to_stable(f"自举进程退出码 {retcode}")
            round_num += 1
            continue
        
        # 审计
        audit_pass, reason = audit_debate_node()
        if not audit_pass:
            revert_to_stable(reason)
            round_num += 1
            success_count = 0
            continue
        
        # 运行测试
        test_pass, test_output = run_pytest()
        if not test_pass:
            revert_to_stable(f"pytest 测试失败: {test_output[:200]}")
            round_num += 1
            success_count = 0
            continue
        
        # 通过本轮
        log(f"第 {round_num} 轮通过审计与测试")
        update_stable()
        success_count += 1
        log(f"连续成功次数: {success_count}")
        
        if success_count >= CONSECUTIVE_SUCCESSES_NEEDED:
            log(f"达到连续 {CONSECUTIVE_SUCCESSES_NEEDED} 次成功，进化稳定，停止循环")
            break
        
        round_num += 1
    
    # 最终汇报
    log("\n=== 进化监护人完成 ===")
    if success_count >= CONSECUTIVE_SUCCESSES_NEEDED:
        log("进化成功：系统已稳定")
        # 计算最终压缩率等（简化）
        stable_size = count_logic_lines(DEBATE_NODE_STABLE)
        original_size = count_logic_lines("src/debate_node.py.original")  # 可选
        log(f"最终核心逻辑行数: {stable_size}")
        # 生成报告
        report = f"""
进化监护人最终报告
===================
- 达到连续 {CONSECUTIVE_SUCCESSES_NEEDED} 轮成功
- 最终稳定文件: {DEBATE_NODE_STABLE}
- 核心逻辑行数: {stable_size}
- 内化的安全规则: pytest 仲裁、路径映射、硬性约束、关键函数保留
- 关键失败记录: 参见 {ERROR_VAULT_PATH}
"""
        print(report)
    else:
        log(f"进化未达到稳定（最大轮次 {MAX_ROUNDS}）")

if __name__ == "__main__":
    main()