#!/usr/bin/env python3
"""
启动天灵智能体，从文件读取长任务描述，避免命令行参数长度限制。
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def main():
    # 读取任务描述文件
    with open('task_description.txt', 'r', encoding='utf-8') as f:
        task = f.read().strip()
    
    print(f"任务长度: {len(task)} 字符")
    
    # 将任务描述作为命令行参数传递给 main_agent.py
    # 直接调用 main_agent 的 main 函数
    from src.main_agent import main as agent_main
    # 临时替换 sys.argv
    sys.argv = ['main_agent.py', task]
    try:
        agent_main()
    except SystemExit:
        pass
    except Exception as e:
        print(f"启动天灵时出错: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()