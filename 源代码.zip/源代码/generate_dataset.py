#!/usr/bin/env python3
"""
生成 50 条模拟漏洞/安全样本数据集，用于 TitanVul 迷你版。
"""
import json
import os

base_samples = [
    {
        "CVE": "CVE-2021-44228",
        "cwe": "CWE-78",
        "code": "# Python 命令注入漏洞示例\nimport os\ndef vulnerable(input):\n    os.system('echo ' + input)",
        "label": "vulnerable",
        "language": "python",
        "dataset": "synthetic"
    },
    {
        "CVE": "CVE-2021-34527",
        "cwe": "CWE-89",
        "code": "# SQL 注入漏洞示例\nimport sqlite3\ndef query(user_input):\n    conn = sqlite3.connect('test.db')\n    cursor = conn.cursor()\n    cursor.execute('SELECT * FROM users WHERE name = ' + user_input)",
        "label": "vulnerable",
        "language": "python",
        "dataset": "synthetic"
    },
    {
        "CVE": "CVE-2017-5638",
        "cwe": "CWE-22",
        "code": "# 路径遍历漏洞示例\ndef read_file(filename):\n    with open(filename, 'r') as f:\n        return f.read()",
        "label": "vulnerable",
        "language": "python",
        "dataset": "synthetic"
    },
    {
        "CVE": "CVE-2020-13935",
        "cwe": "CWE-20",
        "code": "# 安全代码示例（无漏洞）\ndef safe_add(a, b):\n    return a + b",
        "label": "safe",
        "language": "python",
        "dataset": "synthetic"
    },
    {
        "CVE": "CVE-2021-26701",
        "cwe": "CWE-798",
        "code": "# 硬编码密码漏洞示例\npassword = 'admin123'",
        "label": "vulnerable",
        "language": "python",
        "dataset": "synthetic"
    }
]

# 生成 50 个样本，一半安全，一半有漏洞
samples = []
vuln_count = 0
safe_count = 0
target_vuln = 25
target_safe = 25

# 重复基础样本并修改 CVE 和代码片段以避免重复
for i in range(50):
    base = base_samples[i % len(base_samples)]
    new_sample = base.copy()
    # 修改 CVE 编号
    new_sample["CVE"] = f"CVE-2021-{10000 + i}"
    # 轻微修改代码（添加注释行）
    if "code" in new_sample:
        new_sample["code"] = new_sample["code"] + f"\n# 样本编号 {i}"
    # 确保标签分布
    if new_sample["label"] == "vulnerable" and vuln_count >= target_vuln:
        # 转换为安全
        new_sample["label"] = "safe"
        new_sample["cwe"] = "CWE-20"
        new_sample["code"] = "# 安全代码示例\ndef safe_func():\n    return 42\n# 样本编号 {}".format(i)
    elif new_sample["label"] == "safe" and safe_count >= target_safe:
        # 转换为漏洞
        new_sample["label"] = "vulnerable"
        new_sample["cwe"] = "CWE-78"
        new_sample["code"] = "# 命令注入漏洞示例\nimport os\ndef vulnerable():\n    os.system('ls')\n# 样本编号 {}".format(i)
    
    if new_sample["label"] == "vulnerable":
        vuln_count += 1
    else:
        safe_count += 1
    
    samples.append(new_sample)

# 调整数量以精确匹配目标
if vuln_count > target_vuln:
    for s in samples:
        if s["label"] == "vulnerable" and vuln_count > target_vuln:
            s["label"] = "safe"
            s["cwe"] = "CWE-20"
            vuln_count -= 1
            safe_count += 1
if safe_count > target_safe:
    for s in samples:
        if s["label"] == "safe" and safe_count > target_safe:
            s["label"] = "vulnerable"
            s["cwe"] = "CWE-78"
            safe_count -= 1
            vuln_count += 1

print(f"生成 {len(samples)} 个样本，其中漏洞 {vuln_count} 个，安全 {safe_count} 个")

# 写入文件
output_path = "src/benchmark/reposvul_mini.json"
os.makedirs(os.path.dirname(output_path), exist_ok=True)
with open(output_path, 'w', encoding='utf-8') as f:
    json.dump(samples, f, ensure_ascii=False, indent=2)
print(f"已保存数据集到 {output_path}")

# 同时更新 evolution_guardian_v3.py 中的路径（可选）
# 注意：需要手动修改 BENCH_SAMPLES_PATH 变量