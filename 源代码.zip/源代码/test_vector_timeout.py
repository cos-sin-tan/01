import sys
sys.path.insert(0, '.')
from src.vector_service import VectorErrorService
import time
print("Testing VectorErrorService with timeout...")
start = time.time()
try:
    service = VectorErrorService()
    print(f"Initialization took {time.time() - start:.2f} seconds")
    print(f"Fallback mode: {service._fallback_mode}")
except Exception as e:
    print(f"Error: {e}")
    import traceback
    traceback.print_exc()