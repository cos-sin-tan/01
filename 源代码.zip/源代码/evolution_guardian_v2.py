#!/usr/bin/env python3
"""
天灵进化监护人脚本 v2
修复编码、日期命令与超时问题。
"""
import os
import sys
import subprocess
import shutil
import json
import re
from datetime import datetime
from pathlib import Path

# 配置
DEBATE_NODE_PATH = "src/debate_node.py"
DEBATE_NODE_STABLE = "src/debate_node.py.stable"
EVALUATOR_GOLD = "src/evaluator.gold"
ERROR_VAULT_PATH = ".ai_knowledge/error_vault.md"
MAX_ROUNDS = 10
CONSECUTIVE_SUCCESSES_NEEDED = 3
success_count = 0

def log(msg):
    print(f"[Guardian] {msg}")

def backup_stable():
    if not os.path.exists(DEBATE_NODE_STABLE):
        shutil.copy2(DEBATE_NODE_PATH, DEBATE_NODE_STABLE)
        log(f"已创建稳定基准: {DEBATE_NODE_STABLE}")
    if not os.path.exists(EVALUATOR_GOLD):
        staging_path = "src/staging/safe_evaluator.py"
        if os.path.exists(staging_path):
            shutil.copy2(staging_path, EVALUATOR_GOLD)
            log(f"已复制 evaluator 黄金版本: {EVALUATOR_GOLD}")

def run_bootstrap():
    cmd = [sys.executable, "src/main_agent.py", "自举任务：优化自身提示词模板"]
    log(f"执行自举命令: {' '.join(cmd)}")
    env = os.environ.copy()
    env['PYTHONIOENCODING'] = 'utf-8'
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            encoding='utf-8',
            errors='ignore',
            timeout=600,  # 10 分钟
            cwd=os.getcwd(),
            env=env
        )
        log(f"自举退出码: {result.returncode}")
        if result.stdout:
            log(f"自举输出 (前 500 字符): {result.stdout[:500]}...")
        if result.stderr:
            log(f"自举错误 (前 500 字符): {result.stderr[:500]}...")
        return result.returncode, result.stdout, result.stderr
    except subprocess.TimeoutExpired:
        log("自举超时，强制终止")
        return -1, "", "Timeout"
    except Exception as e:
        log(f"自举执行异常: {e}")
        return -2, "", str(e)

def read_file_lines(path):
    if not os.path.exists(path):
        return []
    with open(path, 'r', encoding='utf-8', errors='ignore') as f:
        lines = f.readlines()
    cleaned = []
    for line in lines:
        stripped = line.strip()
        if stripped and not stripped.startswith('#'):
            cleaned.append(line)
    return cleaned

def count_logic_lines(path):
    lines = read_file_lines(path)
    return len(lines)

def audit_debate_node():
    if not os.path.exists(DEBATE_NODE_PATH):
        return False, "文件不存在"
    
    with open(DEBATE_NODE_PATH, 'r', encoding='utf-8', errors='ignore') as f:
        content = f.read()
    
    # 熔断条件 A
    if 'pytest' not in content and 'subprocess.run' not in content:
        return False, "删除了 pytest 仲裁逻辑"
    
    if '_resolve_sandbox_path' not in content:
        return False, "删除了 _resolve_sandbox_path 路径映射"
    
    if '硬性约束' not in content and '安全红线' not in content:
        return False, "删除了硬性安全约束"
    
    # 熔断条件 B
    stable_lines = count_logic_lines(DEBATE_NODE_STABLE)
    new_lines = count_logic_lines(DEBATE_NODE_PATH)
    if stable_lines == 0:
        log("稳定版本行数为零，跳过行数检查")
    else:
        reduction = (stable_lines - new_lines) / stable_lines
        if reduction > 0.3:
            return False, f"核心逻辑行数减少 {reduction:.1%}（稳定 {stable_lines} 行，当前 {new_lines} 行）"
    
    # 关键函数检查
    required_funcs = ['run_debate', '_invoke_coder', '_invoke_auditor']
    for func in required_funcs:
        if func not in content:
            return False, f"缺失关键函数 {func}"
    
    return True, "审计通过"

def revert_to_stable(reason):
    log(f"触发熔断，原因: {reason}")
    if os.path.exists(DEBATE_NODE_STABLE):
        shutil.copy2(DEBATE_NODE_STABLE, DEBATE_NODE_PATH)
        log(f"已恢复稳定版本: {DEBATE_NODE_PATH}")
    else:
        log("错误: 稳定备份不存在，无法恢复")
    
    # 写入错误知识库
    os.makedirs(os.path.dirname(ERROR_VAULT_PATH), exist_ok=True)
    entry = f"""
## 进化熔断记录
- **日期**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
- **文件**: {DEBATE_NODE_PATH}
- **原因**: {reason}
- **处理**: 已恢复至稳定基准
"""
    with open(ERROR_VAULT_PATH, 'a', encoding='utf-8') as f:
        f.write(entry)
    log(f"已写入错误知识库: {ERROR_VAULT_PATH}")

def update_stable():
    shutil.copy2(DEBATE_NODE_PATH, DEBATE_NODE_STABLE)
    log(f"更新稳定基准: {DEBATE_NODE_STABLE}")

def run_pytest():
    cmd = [sys.executable, '-m', 'pytest', 'tests/', '-v', '--tb=short']
    log("运行 pytest 测试...")
    env = os.environ.copy()
    env['PYTHONIOENCODING'] = 'utf-8'
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            encoding='utf-8',
            errors='ignore',
            timeout=120
        )
        if result.returncode == 0:
            log("pytest 全部通过")
            return True, result.stdout
        else:
            log(f"pytest 失败，退出码 {result.returncode}")
            return False, result.stderr
    except subprocess.TimeoutExpired:
        log("pytest 超时")
        return False, "Timeout"
    except Exception as e:
        log(f"pytest 执行异常: {e}")
        return False, str(e)

def main():
    global success_count
    log("=== 天灵进化监护人 v2 启动 ===")
    backup_stable()
    
    round_num = 1
    while round_num <= MAX_ROUNDS:
        log(f"\n--- 第 {round_num} 轮自举开始 ---")
        retcode, stdout, stderr = run_bootstrap()
        if retcode != 0:
            log(f"自举失败，退出码 {retcode}，跳过审计")
            revert_to_stable(f"自举进程退出码 {retcode}")
            round_num += 1
            success_count = 0
            continue
        
        audit_pass, reason = audit_debate_node()
        if not audit_pass:
            revert_to_stable(reason)
            round_num += 1
            success_count = 0
            continue
        
        test_pass, test_output = run_pytest()
        if not test_pass:
            revert_to_stable(f"pytest 测试失败: {test_output[:200]}")
            round_num += 1
            success_count = 0
            continue
        
        log(f"第 {round_num} 轮通过审计与测试")
        update_stable()
        success_count += 1
        log(f"连续成功次数: {success_count}")
        
        if success_count >= CONSECUTIVE_SUCCESSES_NEEDED:
            log(f"达到连续 {CONSECUTIVE_SUCCESSES_NEEDED} 次成功，进化稳定，停止循环")
            break
        
        round_num += 1
    
    log("\n=== 进化监护人完成 ===")
    if success_count >= CONSECUTIVE_SUCCESSES_NEEDED:
        log("进化成功：系统已稳定")
        stable_size = count_logic_lines(DEBATE_NODE_STABLE)
        report = f"""
进化监护人最终报告
===================
- 达到连续 {CONSECUTIVE_SUCCESSES_NEEDED} 轮成功
- 最终稳定文件: {DEBATE_NODE_STABLE}
- 核心逻辑行数: {stable_size}
- 内化的安全规则: pytest 仲裁、路径映射、硬性约束、关键函数保留
- 关键失败记录: 参见 {ERROR_VAULT_PATH}
"""
        print(report)
    else:
        log(f"进化未达到稳定（最大轮次 {MAX_ROUNDS}）")

if __name__ == "__main__":
    main()