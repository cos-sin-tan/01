#!/usr/bin/env python3
"""
天灵 AI 极简控制台界面 (Gradio)
功能：
1. 一个大输入框（输入任务）
2. 进度显示条（显示当前是哪个 Node 在工作）
3. 文件下载列表（自动展示生成的报告和 PPT）
4. 实时日志输出
"""

import gradio as gr
import sys
import os
import threading
import queue
import time
from pathlib import Path

# 将项目根目录加入路径，以便导入模块
sys.path.insert(0, str(Path(__file__).parent))

# 导入智能体主模块
try:
    from src.main_agent import main, build_workflow
    from langgraph.graph import StateGraph
except ImportError as e:
    print(f"导入错误: {e}")
    print("请确保已安装所有依赖项 (requirements.txt)")
    raise

# 全局状态
task_queue = queue.Queue()
progress_updates = queue.Queue()
output_files = []

def run_agent_task(task_description, progress_callback=None):
    """
    在后台运行智能体工作流，通过队列发送进度更新。
    """
    try:
        # 重定向标准输出以捕获日志
        import io
        import contextlib
        from src.main_agent import build_workflow
        
        # 构建工作流
        workflow = build_workflow()
        
        # 初始化状态
        from src.main_agent import AgentState
        initial_state: AgentState = {
            'task_description': task_description,
            'blueprint': None,
            'deliverables': {},
            'audit_results': {},
            'error_message': None,
            'iteration': 0,
            'current_node': 'architect',
            'relevant_knowledge': None,
            'system_spec': None,
            'hard_constraints': None,
            'diagnostic_vector': None,
            'lessons_learned': None,
            'current_consensus': None,
            'token_usage': {'total_tokens': 0, 'last_node_tokens': 0},
            'need_search': False,
            'search_performed': False,
        }
        
        # 模拟运行工作流（简化：直接调用 main 函数）
        # 这里我们直接调用 main 函数，因为它会处理整个流程。
        # 但 main 函数期望命令行参数，我们可以通过修改 sys.argv 来模拟。
        import sys
        old_argv = sys.argv
        sys.argv = ['main_agent.py', task_description]
        
        # 捕获输出
        captured_output = io.StringIO()
        with contextlib.redirect_stdout(captured_output), contextlib.redirect_stderr(captured_output):
            # 运行工作流
            # 注意：这里我们直接调用 main()，但 main() 会打印并退出。
            # 更好的方法是直接执行工作流，但为了简单，我们调用 main 并捕获输出。
            # 我们将使用 workflow 的 run 方法。
            from langgraph.graph import StateGraph
            app = workflow.compile()
            final_state = app.invoke(initial_state)
        
        sys.argv = old_argv
        
        # 从最终状态提取交付物
        deliverables = final_state.get('deliverables', {})
        report_path = deliverables.get('report')
        ppt_path = deliverables.get('ppt')
        
        # 发送进度完成信号
        if progress_callback:
            progress_callback("完成", 100)
        
        # 返回结果
        return {
            'success': True,
            'output': captured_output.getvalue(),
            'report': report_path,
            'ppt': ppt_path,
            'deliverables': deliverables
        }
    except Exception as e:
        import traceback
        error_msg = traceback.format_exc()
        return {'success': False, 'error': error_msg}

def launch_agent(task_input):
    """
    Gradio 提交函数：启动智能体任务并返回实时日志。
    """
    if not task_input.strip():
        return "错误：任务描述不能为空", "", ""
    
    # 清空文件列表
    output_files.clear()
    
    # 创建进度更新队列
    progress_queue = queue.Queue()
    
    # 启动后台线程
    def worker():
        result = run_agent_task(task_input, lambda msg, perc: progress_queue.put((msg, perc)))
        task_queue.put(result)
    
    thread = threading.Thread(target=worker, daemon=True)
    thread.start()
    
    # 返回初始消息
    return "任务已开始，请稍候...", "", ""

def update_progress():
    """
    定期检查进度更新并返回给前端。
    此函数由 Gradio 的 `gr.DataFrame` 或 `gr.Textbox` 调用。
    """
    # 简化：直接返回静态进度（实际应从队列读取）
    return "运行中...", 50

def get_output_files():
    """
    返回生成的报告和 PPT 文件列表。
    """
    # 从交付物目录扫描
    file_list = []
    deliverable_dir = Path("deliverables")
    if deliverable_dir.exists():
        for f in deliverable_dir.glob("*"):
            if f.is_file():
                file_list.append((f.name, str(f)))
    return file_list

# 构建 Gradio 界面
with gr.Blocks(title="天灵 AI 控制台", theme=gr.themes.Soft()) as demo:
    gr.Markdown("# 🧠 天灵 AI 任务执行控制台")
    gr.Markdown("输入您的任务描述，系统将自动生成技术报告与 PPT。")
    
    with gr.Row():
        with gr.Column(scale=2):
            task_input = gr.Textbox(
                label="任务描述",
                placeholder="例如：我需要一份关于‘有机化学 SN1/SN2 反应’的深度对比报告和组会 PPT...",
                lines=5,
                max_lines=10
            )
            submit_btn = gr.Button("🚀 开始执行", variant="primary")
        
        with gr.Column(scale=1):
            progress_bar = gr.Progress(label="执行进度")
            current_node = gr.Textbox(label="当前节点", value="等待开始", interactive=False)
    
    with gr.Row():
        output_log = gr.Textbox(label="执行日志", lines=15, interactive=False)
    
    with gr.Row():
        file_output = gr.File(label="生成的文件", file_count="multiple", interactive=False)
    
    # 提交按钮事件
    submit_btn.click(
        fn=launch_agent,
        inputs=task_input,
        outputs=[current_node, output_log, file_output]
    )
    
    # 定时更新进度（简化）
    # 注意：实际应使用队列和事件驱动更新，但为简单起见，我们使用轮询。
    # 这里省略，因为需要更复杂的异步处理。

if __name__ == "__main__":
    # 确保交付物目录存在
    os.makedirs("deliverables", exist_ok=True)
    os.makedirs(".ai_knowledge", exist_ok=True)
    
    # 启动 Gradio 应用
    demo.launch(
        server_name="0.0.0.0",
        server_port=7860,
        share=False,
        debug=False
    )