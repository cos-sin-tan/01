#!/usr/bin/env python3
"""
外部编排脚本（Task Splintering Orchestrator）
从 .task_state/dag.json 读取 DAG，按拓扑顺序依次执行子任务。
支持失败重试（最多3次）与并行降级（模拟结果）。
"""
import os
import sys
import subprocess
import json
import time
import shutil
from pathlib import Path
from collections import deque

def topological_sort(tasks):
    """简单的拓扑排序，返回满足依赖关系的任务顺序"""
    adj = {task['id']: [] for task in tasks}
    indegree = {task['id']: 0 for task in tasks}
    id_to_task = {task['id']: task for task in tasks}
    for task in tasks:
        for dep in task['dependencies']:
            adj[dep].append(task['id'])
            indegree[task['id']] += 1
    
    q = deque([tid for tid in indegree if indegree[tid] == 0])
    result = []
    while q:
        tid = q.popleft()
        result.append(id_to_task[tid])
        for nxt in adj[tid]:
            indegree[nxt] -= 1
            if indegree[nxt] == 0:
                q.append(nxt)
    if len(result) != len(tasks):
        print("[Orchestrator] 错误：检测到循环依赖，无法进行拓扑排序")
        sys.exit(1)
    return result


def run_task(task, output_dir, attempt_max=3):
    """运行单个任务，支持重试，失败时中止支线"""
    task_id = task['id']
    print(f"[Orchestrator] 处理任务: {task_id} - {task['action'][:80]}...")
    
    for attempt in range(attempt_max):
        # 创建临时子任务文件
        subtask_file = output_dir / f"{task_id}_attempt{attempt+1}.txt"
        with open(subtask_file, 'w', encoding='utf-8') as f:
            f.write(task['action'])
        
        # 调用 unattended_run.py，传递环境变量
        cmd = [sys.executable, 'unattended_run.py', task['action']]
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                encoding='utf-8',
                timeout=300,
                env=os.environ.copy()  # 修复环境断层
            )
            success = result.returncode == 0
            if success:
                log = {
                    "task": task_id,
                    "success": True,
                    "attempt": attempt+1,
                    "returncode": result.returncode,
                    "stdout": result.stdout[:1000],
                    "stderr": result.stderr[:1000]
                }
                print(f"[Orchestrator] 任务 {task_id} 第 {attempt+1} 次尝试成功")
                return log
            else:
                print(f"[Orchestrator] 任务 {task_id} 第 {attempt+1} 次尝试失败（返回码 {result.returncode}）")
                # 继续重试
        except subprocess.TimeoutExpired:
            print(f"[Orchestrator] 任务 {task_id} 第 {attempt+1} 次尝试超时")
    
    # 所有尝试均失败，记录真实错误并中止支线
    print(f"[Orchestrator] 任务 {task_id} 连续 {attempt_max} 次失败，中止当前 DAG 支线")
    # 返回失败结果，主循环将停止执行
    return {
        "task": task_id,
        "success": False,
        "error": "连续失败",
        "stderr": "请查看对应子任务日志"
    }

def main():
    # 确保 .task_state 目录存在
    task_state = Path(".task_state")
    if not task_state.exists():
        task_state.mkdir(parents=True)
    
    # 读取 DAG 文件
    dag_path = task_state / "dag.json"
    if not dag_path.exists():
        print("[Orchestrator] 未找到 dag.json，尝试从主任务描述生成...")
        print("[Orchestrator] 请先运行 main_agent.py 以生成 DAG")
        return
    
    with open(dag_path, 'r', encoding='utf-8') as f:
        tasks = json.load(f)
    
    print(f"[Orchestrator] 从 dag.json 读取 {len(tasks)} 个任务")
    
    # 拓扑排序
    sorted_tasks = topological_sort(tasks)
    print(f"[Orchestrator] 执行顺序: {[t['id'] for t in sorted_tasks]}")
    
    # 创建本次运行的输出目录
    run_id = int(time.time())
    output_dir = Path(f".task_state/run_{run_id}")
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # 依次执行任务
    results = []
    for task in sorted_tasks:
        # 检查依赖是否都已成功（简化：由于已排序，假定依赖已满足）
        result = run_task(task, output_dir, attempt_max=3)
        results.append(result)
        if not result.get('success'):
            # 即使失败，如果启用了模拟，则视为成功
            if result.get('mock'):
                print(f"[Orchestrator] 任务 {task['id']} 已降级为模拟成功，继续管道")
                # 视为成功，继续
            else:
                print(f"[Orchestrator] 任务 {task['id']} 失败且未降级，停止执行")
                break
        else:
            print(f"[Orchestrator] 任务 {task['id']} 完成")
    
    # 保存结果摘要
    summary = {
        "run_id": run_id,
        "timestamp": time.ctime(),
        "results": results
    }
    summary_path = output_dir / "orchestration_summary.json"
    with open(summary_path, 'w', encoding='utf-8') as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    print(f"[Orchestrator] 编排执行完成，摘要已保存至 {summary_path}")

if __name__ == '__main__':
    main()