#!/usr/bin/env python3
"""测试 DebateNode 的沙盒路径转换逻辑"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from src.debate_node import DebateNode

def test_resolve_sandbox_path():
    """测试路径转换规则"""
    debater = DebateNode()
    
    test_cases = [
        # (输入路径, 期望输出路径)
        ("src/main.py", "src/staging/main.py"),
        ("tests/test_main.py", "staging/tests/test_main.py"),
        ("config.yaml", "staging/config.yaml"),
        # 已经是 staging 路径的情况
        ("src/staging/main.py", "src/staging/main.py"),  # 应该直接返回
        ("staging/tests/test.py", "staging/tests/test.py"),
        ("src/staging/deep/nested.py", "src/staging/deep/nested.py"),
        # 带有相对路径
        ("./src/main.py", "src/staging/main.py"),
        ("../src/main.py", "staging/../src/main.py"),  # normpath 会处理
        # Windows 风格路径（应该被规范化）
        ("src\\main.py", "src/staging/main.py"),
        ("src/staging\\main.py", "src/staging/main.py"),
    ]
    
    print("测试 _resolve_sandbox_path 方法：")
    all_passed = True
    for input_path, expected in test_cases:
        result = debater._resolve_sandbox_path(input_path)
        # 规范化预期结果以便比较
        expected_norm = os.path.normpath(expected)
        result_norm = os.path.normpath(result)
        
        passed = result_norm == expected_norm
        status = "PASS" if passed else "FAIL"
        print(f"  {status:4} {input_path!r:30} -> {result_norm!r:30} (期望: {expected_norm!r})")
        if not passed:
            all_passed = False
            print(f"    差异：result={result!r}, expected={expected!r}")
    
    if all_passed:
        print("所有测试通过！")
    else:
        print("部分测试失败！")
        sys.exit(1)

if __name__ == "__main__":
    test_resolve_sandbox_path()