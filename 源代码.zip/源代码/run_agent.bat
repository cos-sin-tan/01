@echo off
chcp 65001 >nul
echo ========================================
echo   LangGraph 智能体后台系统 - 启动器
echo ========================================
echo.

setlocal

REM 检查是否提供了任务描述
if "%1"=="" (
    set /p "task=请输入任务描述: "
) else (
    set "task=%*"
)

REM 检查Python是否可用
python --version >nul 2>&1
if errorlevel 1 (
    echo 错误：未找到Python。请确保已安装Python并已添加到PATH。
    pause
    exit /b 1
)

REM 运行智能体
echo 正在启动智能体处理任务：%task%
echo.
python src/main_agent.py "%task%"

if errorlevel 1 (
    echo 智能体执行失败。
    pause
    exit /b 1
) else (
    echo 智能体执行完成。
)

pause