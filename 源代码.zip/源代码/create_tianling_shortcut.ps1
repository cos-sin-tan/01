# PowerShell script to create a desktop shortcut for "天灵"智能体
$DesktopPath = [Environment]::GetFolderPath("Desktop")
$ShortcutPath = Join-Path $DesktopPath "天灵.lnk"
$TargetPath = Join-Path $PSScriptRoot "run_agent.bat"
$WScriptShell = New-Object -ComObject WScript.Shell
$Shortcut = $WScriptShell.CreateShortcut($ShortcutPath)
$Shortcut.TargetPath = $TargetPath
$Shortcut.WorkingDirectory = $PSScriptRoot
$Shortcut.IconLocation = "C:\Windows\System32\cmd.exe,0"
$Shortcut.Description = "天灵智能体启动器 - 点击运行多智能体协作系统"
$Shortcut.Save()
Write-Output "Shortcut created: $ShortcutPath"