# PowerShell script to create a desktop shortcut for 天灵进化监视器
$DesktopPath = [Environment]::GetFolderPath("Desktop")
$ShortcutPath = Join-Path $DesktopPath "天灵进化监视器.lnk"
$TargetPath = "powershell.exe"
$ScriptPath = Join-Path $PSScriptRoot "show_evolution.ps1"
$Arguments = "-NoProfile -ExecutionPolicy Bypass -File `"$ScriptPath`""
$WScriptShell = New-Object -ComObject WScript.Shell
$Shortcut = $WScriptShell.CreateShortcut($ShortcutPath)
$Shortcut.TargetPath = $TargetPath
$Shortcut.Arguments = $Arguments
$Shortcut.WorkingDirectory = $PSScriptRoot
$Shortcut.IconLocation = "C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe,0"
$Shortcut.Description = "实时显示天灵自举进化日志"
$Shortcut.Save()
Write-Output "快捷方式创建成功: $ShortcutPath"
Write-Output "Now you can double-click the shortcut on desktop to open monitor."